/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
void daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   // check data ready and update write position
   if (st->WritePos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_IN_DATAREADY;
      st->WritePos   = 0;
      st->WPRunBack += 1;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      st->BufState |= DAQ_IN_BUF_FULL;
      if (st->WPRunBack > 1 || st->WritePos > st->ReadPos){
         st->BufState |= DAQ_IN_BUF_OVERRUN;
      }
   }
}

void daq_fai_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   unsigned      buf_state;
   unsigned long flags;

   if (faiStatus->FnState != DAQ_FN_RUNNING){
      return;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   buf_state = faiStatus->BufState;
   faiStatus->BufState = 0;
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if ((buf_state & DAQ_IN_CACHE_OVERFLOW) && (!shared->IsEvtSignaled[KdxAiCacheOverflow])) {
      shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
      daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
   }

   if ((buf_state & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun]) {
     shared->IsEvtSignaled[KdxAiOverrun] = 1;
     daq_device_signal_event(daq_dev, KdxAiOverrun);
   }

   if ((buf_state & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady]) {
     shared->IsEvtSignaled[KdxAiDataReady] = 1;
     daq_device_signal_event(daq_dev, KdxAiDataReady);
   }

   if (DAQ_IN_MUST_STOP(buf_state, faiStatus->AcqMode)) {
      daq_fai_stop_acquisition(daq_dev, 0);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared = &daq_dev->shared;
   PLX_INT_CSR plx_intcsr;
   __u32       dev_intcsr;

   dev_intcsr = AdxIoInW(shared->IoBase, DR_DEV_INTCSR);
   if (dev_intcsr & DEV_INT_OCCURRED) {

      if (dev_intcsr & DEV_INT_DMATERMCOUNT) {
         AI_TRIG_CSR trig_state;

         trig_state.Value = AdxIoInW(shared->IoBase, DR_AI_TRIGCSR);
         if (trig_state.DmaTCFlag) {
            shared->FaiStatus.DmaTCFlag = 1;
            daq_fai_stop_acquisition(daq_dev, 0);
         }
      }

      AdxIoOutW(shared->IoBase, DR_DEV_INTCLR, 0);
   }

   plx_intcsr.Value = AdxIoInD(shared->BrBase, BR_PLX_INTCSR);
   if (plx_intcsr.Dma0IntActive) {
      PLX_DMA_CSR plx_dmacsr;
      __u32       fifo_state;

      fifo_state = AdxIoInD(shared->IoBase, DR_AI_FIFOCSR);
      if (fifo_state & AI_FIFO_FULL_MASK) {
         shared->FaiStatus.BufState |= DAQ_IN_CACHE_OVERFLOW;
      }

      spin_lock(&daq_dev->fai_lock);
      daq_fai_update_status(&shared->FaiParam, &shared->FaiStatus, shared->FaiParam.SectionSize);
      spin_unlock(&daq_dev->fai_lock);

      // clear DMA interrupt.
      // Note: don't set DMA start bit here, otherwise
      // there will be an unexpected interrupt.
      // set only the bits for DMA enable and clear interrupt
      plx_dmacsr.Value = AdxIoInB( shared->BrBase, BR_PLX_DMACSR0 );
      plx_dmacsr.ClearInt = 1;
      AdxIoOutB( shared->BrBase, BR_PLX_DMACSR0, plx_dmacsr.Value );

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING) {
         tasklet_schedule(&daq_dev->fai_tasklet);
      }
   }

   return (dev_intcsr & DEV_INT_OCCURRED) || plx_intcsr.Dma0IntActive ? IRQ_RETVAL(1) : IRQ_RETVAL(0);
}
