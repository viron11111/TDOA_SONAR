/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1715
#define DEVICE_PID    BD_PCI1747
#define DEVICE_NAME   "PCI-1715"
#define DRIVER_NAME   "bio1715"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             32
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        (AI_CHL_COUNT / 2)
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)   //
#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(unsigned short)
#define AI_DATA_MASK             0xfff

#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt5To2pt5    1
#define AI_GAIN_V_Neg1pt25To1pt25  2
#define AI_GAIN_V_Neg10To10        4
#define AI_GAIN_V_0To10            16
#define AI_GAIN_V_0To5             17
#define AI_GAIN_V_0To2pt5          18
#define AI_GAIN_V_0To1pt25         19

#define AI_CLK_BASE              (10*1000*1000)       // 10MHz clock
#define AI_MAX_PACER             (500*1000)           // 500KHz
#define AI_MIN_PACER             (AI_CLK_BASE / (65535.0 * 65535.0) )
#define AI_FIFO_SIZE             1024                 // Ai fifo size in samples.

#define SAI_TIMEOUT_VAL          1000  // 1000ms time-out value for each sample reading.
#define SAI_DELAY_TIME           10    // 10us delay before reading data

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg5To5
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (100 * 100)
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE * 2)  // this size best for DMA mode
#define DEF_FAI_MODE            0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;
} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  OvrnOffset;
   __u32  OvrnCount;
} FAI_STATUS;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       BrBase;
   __u32       BrLength;
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;

   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
