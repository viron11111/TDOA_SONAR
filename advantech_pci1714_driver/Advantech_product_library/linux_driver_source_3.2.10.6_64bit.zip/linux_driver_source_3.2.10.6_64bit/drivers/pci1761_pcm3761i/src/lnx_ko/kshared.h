/*
 * kshared.h
 *
 *  Created on: July 7, 2012 
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_PID    BD_PCI1761

#define DRIVER_NAME   "bio1761"

#define DEVICE_NAME_FROM_PID(pid) deviceNameFromPid(pid)
#define DEVICE_ID_FROM_PID(pid)   deviceIdFromPid(pid)

#ifdef __cplusplus
#  define char_const char const
#else
#  define char_const char
#endif
static inline char_const * deviceNameFromPid(int pid)
{   
   char_const *name;
   switch (pid)
   {
   case BD_PCI1761:  name = "PCI-1761"; break;
   case BD_PCM3761I: name = "PCM-3761I"; break;
   case BD_MIC3761:  name = "MIC-3761"; break;
   default:          name = "unknown";   break;
   }
   return name;
}

static inline int deviceIdFromPid(int pid)
{
   int id;
   switch (pid)
   {
   case BD_PCI1761:  id = 0x1761; break;
   case BD_PCM3761I: id = 0x3761; break;
   case BD_MIC3761:  id = 0x3761; break;
   default:          id = 0xffff; break;
   }
   return id;
}
// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DI_PORT_COUNT           1
#define DI_CHL_COUNT           (DI_PORT_COUNT * 8)
#define DO_PORT_COUNT           1
#define DO_CHL_COUNT           (DO_PORT_COUNT * 8)
#define DIO_PORT_COUNT		   1
#define DIO_CHL_COUNT          (DIO_PORT_COUNT * 8)

#define KdxDiBegin            0
#define KdxDiEnd              (KdxDiBegin + 7)
#define KdxDevPropChged       (KdxDiEnd + 1) 
#define KrnlSptedEventCount   (KdxDevPropChged + 1)

#define DI_INT_SRC_COUNT      (KdxDiEnd - KdxDiBegin + 1)
#define DI_SNAP_SRC_MAX       DI_INT_SRC_COUNT


static inline __u32 GetEventKIndex(__u32 eventid)
{
   __u32 kdx = -1;
   if (eventid == EvtPropertyChanged) {
      kdx = KdxDevPropChged;
   }else 
   {
      __u32 ch = eventid - EvtDiintChannel000;
      if (ch < DI_CHL_COUNT) {
         kdx = KdxDiBegin + ch;
      }
   }

   return kdx;
}

#ifdef USE_IN_SO
#  define AdxMemInB(MemBase, Offset) (*(uint8 *) ((uint8 *)MemBase + Offset))
#  define AdxMemInW(MemBase, Offset) (*(uint16 *)((uint8 *)MemBase + Offset))
#  define AdxMemInD(MemBase, Offset) (*(uint32 *)((uint8 *)MemBase + Offset))

#  define AdxMemOutB(MemBase, Offset, Data) (*(uint8 *) ((uint8 *)MemBase + Offset) = (uint8)Data)
#  define AdxMemOutW(MemBase, Offset, Data) (*(uint16 *)((uint8 *)MemBase + Offset) = (uint16)Data)
#  define AdxMemOutD(MemBase, Offset, Data) (*(uint32 *)((uint8 *)MemBase + Offset) = (uint32)Data)
#endif

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG
{
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE
{
   __u8 State[DI_PORT_COUNT];
} DI_SNAP_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u64       MemPhyBase;
   void*       EpBase;
   __u32       EpLength;
   __u32       Irq;
   __u32       InitOnLoad;
   __u32       KerPageSize;

   // --------------------------------------------------------
   __u8        DoPortState[DO_PORT_COUNT];
   __u8        DiintTrigEdge[DI_INT_SRC_COUNT];
   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_MAX];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_MAX];

   // ---------------------------------------------------------
   __u32       DiIntState;
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
