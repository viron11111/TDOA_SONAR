/*
 * hw.h
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DR_DI_BASE        1
#define DR_DI_PORTX(x)    (DR_DI_BASE + x)

#define DR_DO_BASE        0
#define DR_DO_PORTX(x)    (DR_DO_BASE + x)

#define DR_BID            0x2

#define TRIG_EDGE_RISING   0
#define TRIG_EDGE_FALLING  1
#define DR_INT_CFG         0x4

#define DR_INT_EN          0x3
#define DR_INT_STA         0x5
#define DR_INT_CLR         DR_INT_STA

#endif /* _KERNEL_MODULE_HW_H_ */
