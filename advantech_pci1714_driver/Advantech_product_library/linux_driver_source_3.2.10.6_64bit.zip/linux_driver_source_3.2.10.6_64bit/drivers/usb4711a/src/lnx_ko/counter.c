/*
 * counter.c
 *
 *  Created on: 2013-5-30
 *      Author:
 */
#include "kdriver.h"

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   // Only Counter0 support Event Count
   if (start != 0 || count != 1){
      return -EINVAL;
   }

   cntr = &shared->CntrState[start];
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (cntr->Operation == CNTR_IDLE) {
      cntr->Operation = InstantEventCount;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   ret = daq_usb_cntr_start_event_count(daq_dev, start);
   if (ret < 0) {
      cntr->Operation = CNTR_IDLE;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_timer_pulse( daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   //only counter 1 support Timer/Pulse output
   if (start != 1 || count != 1){
      return -EINVAL;
   }

   cntr = &shared->CntrState[start];
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (cntr->Operation == CNTR_IDLE) {
      cntr->Operation = TimerPulse;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   ret = daq_usb_cntr_start_timer_pulse(daq_dev, start, shared->CntrConfig.TmrCfg[start].Context);
   if (ret < 0) {
      cntr->Operation = CNTR_IDLE;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   // Only Counter0 support Frequency measure
   if (start != 0 || count != 1){
      return -EINVAL;
   }

   cntr = &shared->CntrState[start];
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (cntr->Operation == CNTR_IDLE) {
      cntr->Operation = InstantFreqMeter;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   ret = daq_usb_cntr_start_freq_measure(daq_dev, start);
   if (ret < 0) {
      cntr->Operation = CNTR_IDLE;
   }

   return ret < 0 ? ret : 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   while (count--) {
      if (shared->CntrState[start].Operation != CNTR_IDLE) {
         shared->CntrState[start].Operation = CNTR_IDLE;
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_usb_cntr_reset(daq_dev, start);
         spin_lock_irqsave(&daq_dev->dev_lock, flags);
      }
      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void          *dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_TmrFrequencyOfCounters:
      dataPtr = &shared->CntrConfig.TmrCfg[cntr.Start];
      valLen  = sizeof(USB_TMR_CONFIG)*cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   union {
      CNTR_VALUE ecVal[CNTR_CHL_COUNT];
      BioUsbFrequencyRead_RX fmVal[CNTR_CHL_COUNT];
   }vals;

   CNTR_READ  cntr;
   __u32      outLen;
   int        ret = 0;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   if (cntr.Operation == InstantFreqMeter){
      BioUsbFrequencyRead_RX *rx = vals.fmVal;
      outLen = sizeof(BioUsbFrequencyRead_RX) * cntr.Count;
      while (cntr.Count--) {
         if (cntr.Start == 0) {
            ret = daq_usb_cntr_read_freq_measure(daq_dev, cntr.Start, rx);
         } else {
            rx->Context[0] = 0;
         }
         ++rx;
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }
   } else {
      CNTR_VALUE *val = vals.ecVal;
      outLen = sizeof(CNTR_VALUE) * cntr.Count;
      while(cntr.Count--) {
         if (cntr.Start == 0 )
         {
            ret = daq_usb_cntr_read_event_count(daq_dev, cntr.Start, &val->Value);
         } else {
            val->Value = 0;
         }
         ++val;
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }
   }

   if (ret >= 0){
      ret = copy_to_user(cntr.Value, &vals, outLen);
   }

   return ret;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
