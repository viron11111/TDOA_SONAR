/*
 * ai.c
 *
 *  Created on: 2013-5-30
 *      Author:
 */

#include "kdriver.h"
#include "hw.h"

static
int daq_ai_configure_channel(daq_device_t *daq_dev, __u32 phyStart, __u32 phyCount, __u8 *sctype, __u8 *gain)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret;

   if (unlikely(phyStart + phyCount > AI_CHL_COUNT)){
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (sctype){
      memcpy(&shared->AiChanType[phyStart], sctype, phyCount);
   }
   if (gain){
      memcpy(&shared->AiChanGain[phyStart], gain, phyCount);
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   ret = daq_usb_ai_configure_channel(daq_dev, phyStart, phyCount);

   return ret < 0 ? ret : 0;
}

//
// Must hold the lock when call this function.
static inline
void daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   // check running time status: overrun, data ready
   st->BufState = 0;

   // check data ready and update write position
   if (st->WritePos + inc_count >= st->BufLength) {
      st->BufState   =  DAQ_IN_DATAREADY;
      st->WritePos  += inc_count;
      st->WritePos  %= st->BufLength;
      st->WPRunBack += 1;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState = DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      st->BufState |= DAQ_IN_BUF_FULL;
      if (st->WPRunBack > 1 || st->WritePos > st->ReadPos){
         st->BufState |= DAQ_IN_BUF_OVERRUN;
      }
   }
}

static
int daq_fai_xfer_complete(struct urb *urb, void *context)
{
   daq_device_t  *daq_dev = (daq_device_t*)context;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   unsigned long flags;
   __u32         buf_state;

   daq_trace((KERN_INFO "recved data: %d, status: %d\n", urb->actual_length, urb->status));

   if (urb->status){
      schedule_work(&daq_dev->fai_stop_work);
      return DAQ_UR_BREAK;
   }

   if (!urb->actual_length){
      return DAQ_UR_CONTINUE;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING
      || DAQ_IN_MUST_STOP(faiStatus->BufState, faiStatus->AcqMode)) {
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
      return DAQ_UR_BREAK;
   } else {
       __u16 *src, *dest;
       __u32 total, rest, copied;

       src    = (__u16*)urb->transfer_buffer;
       dest   = (__u16*)daq_dev->fai_buffer.kaddr;
       rest   = total = urb->actual_length / 2;
       copied = min(faiStatus->BufLength - faiStatus->WritePos, rest);

       // fill the the tail of user buffer
       memcpy(&dest[faiStatus->WritePos], src, copied * AI_DATA_SIZE );
       rest -= copied;
       src  += copied;

       if (!(faiStatus->AcqMode == DAQ_ACQ_INFINITE)) {
          total = copied;
       } else {
          if (rest > faiStatus->BufLength) {
             src    += rest - faiStatus->BufLength;
             rest   %= faiStatus->BufLength;
             copied  =  faiStatus->BufLength - rest;
             memcpy(&dest[rest], src, copied * AI_DATA_SIZE);
             src    += copied;
          }
          if (rest) {
             memcpy(dest, src, rest * AI_DATA_SIZE );
          }
       }

       daq_fai_update_status(&shared->FaiParam, faiStatus, total);
       buf_state = faiStatus->BufState;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (faiStatus->AcqMode == DAQ_ACQ_INFINITE) {
      schedule_work(&daq_dev->fai_check_work);
   }

   if ((faiStatus->HwFlag & USB_FLAG_FAIOVERRUN) && !shared->IsEvtSignaled[KdxAiCacheOverflow]) {
      shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
      daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
   }

   if ((buf_state & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun]) {
      shared->IsEvtSignaled[KdxAiOverrun] = 1;
      daq_device_signal_event(daq_dev, KdxAiOverrun);
   }

   if ((buf_state & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady]) {
      shared->IsEvtSignaled[KdxAiDataReady] = 1;
      daq_device_signal_event(daq_dev, KdxAiDataReady);
   }

   if (DAQ_IN_MUST_STOP(buf_state, faiStatus->AcqMode)) {
      schedule_work(&daq_dev->fai_stop_work);
      return DAQ_UR_BREAK;
   }

   return DAQ_UR_CONTINUE;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   daq_ai_configure_channel(daq_dev, 0, AI_CHL_COUNT,
         daq_dev->shared.AiChanType, daq_dev->shared.AiChanGain);

   daq_dev->shared.AiLogChanCount = daq_ai_calc_log_chan_count(daq_dev->shared.AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (shared->FaiStatus.FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      shared->FaiStatus.FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      daq_usb_reader_stop(&daq_dev->usb_reader);
      daq_usb_fai_stop(daq_dev);

      daq_device_signal_event(daq_dev, KdxAiStopped);
      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      daq_umem_unmap(&daq_dev->fai_buffer);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      daq_dev->shared.FaiStatus.FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
}

void daq_fai_check_work_func(struct work_struct *work)
{
   daq_device_t *daq_dev = container_of(work, daq_device_t, fai_check_work);

   if (daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING){
      daq_usb_dev_get_flag(daq_dev, &daq_dev->shared.FaiStatus.HwFlag);
   }
}

void daq_fai_stop_work_func(struct work_struct *work)
{
   daq_device_t *daq_dev = container_of(work, daq_device_t, fai_stop_work);

   daq_fai_stop_acquisition(daq_dev, 0);
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u8          sctype[AI_CHL_COUNT];
   __u8          gain[AI_CHL_COUNT];
   __u8          *sctype_ptr = NULL;
   __u8          *gain_ptr = NULL;
   __u32         i, ch_count;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }

   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AI_SET_CHSCTYPE){
      sctype_ptr = sctype;
      for (i = 0; i < xbuf.PhyChanCount; ++i){
         sctype[i] = cfg[i].SCType;
      }
   }

   if (xbuf.SetWhich & AI_SET_CHGAIN){
      gain_ptr = gain;
      for (i = 0; i < xbuf.PhyChanCount; ++i){
         gain[i] = cfg[i].Gain;
      }
   }

   do{
      ch_count = min(xbuf.PhyChanCount, AI_CHL_COUNT - xbuf.PhyChanStart);
      daq_ai_configure_channel(daq_dev, xbuf.PhyChanStart, ch_count, sctype_ptr, gain_ptr);
      xbuf.PhyChanCount -= ch_count;
      xbuf.PhyChanStart = (xbuf.PhyChanStart + ch_count) & AI_CHL_MASK;
      if (sctype_ptr) sctype_ptr += ch_count;
      if (gain_ptr)   gain_ptr += ch_count;
   } while (xbuf.PhyChanCount);

   if (xbuf.SetWhich & AI_SET_CHSCTYPE) {
      shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
   }

   return 0;
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   AI_READ_SAMPLES xbuf;
   __u16           sample[AI_CHL_COUNT];
   __u32           chRange;

   if (unlikely(daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PhyChanStart &= AI_CHL_MASK;
   if (daq_dev->shared.AiChanType[xbuf.PhyChanStart] == Differential)
   {
      xbuf.PhyChanStart &= ~0x1; // start from the even channel for differential channel.
   }
   xbuf.LogChanCount =  min(xbuf.LogChanCount, (__u32)AI_CHL_COUNT);
   chRange = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT, xbuf.PhyChanStart, xbuf.LogChanCount);
   if (daq_usb_ai_read_channel(daq_dev, xbuf.PhyChanStart, xbuf.LogChanCount, chRange >> 8, sample) < 0){
      return -EIO;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u16)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      ret = daq_umem_map(arg, faiParam->SampleCount * AI_DATA_SIZE, 1, &daq_dev->fai_buffer);
      if (unlikely(ret)){
         break;
      }

      if (!is_reader_inited(&daq_dev->usb_reader)){
         ret = daq_usb_reader_init(daq_dev->udev, daq_dev->xfer_epd,
                  FAI_PACKET_SIZE, FAI_PACKET_NUM, daq_fai_xfer_complete, daq_dev, &daq_dev->usb_reader);
      }
   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fai_buffer);
      shared->FaiStatus.FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;
   int            ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do{
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);

   ret = daq_usb_reader_start(&daq_dev->usb_reader);
   if (ret){
      goto start_reader_err;
   }

   {
      BioUsbFaiIntScanStart tx;
      __u16 *ptr;
      __u32 ch_range, fwDataCount, totalFwDataCount;
      int i, phy_count;

      ch_range = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT, shared->FaiParam.PhyChanStart, shared->FaiParam.LogChanCount);

      tx.StartChannel  = shared->FaiParam.PhyChanStart;
      tx.ChannelCount  = shared->FaiParam.LogChanCount;
      tx.TriggerSource = shared->FaiParam.ConvClkSource == SigInternalClock ? 0 : 1;
      tx.PacerDivisor  = shared->FaiParam.PacerDivider;
      tx.Cyclic        = 1;
      tx.ChannelConfig = 0;
      tx.StopChannel   = ch_range >> 8;

      //kernel_fpu_begin();
      tx.SampleRate    = shared->FaiParam.ConvClkRatePerCH;
      //kernel_fpu_end();

      for (i = 0; i < AI_CHL_COUNT; i += 2) {
         if (shared->AiChanType[i] == Differential){
            tx.ChannelConfig |= 0x3 << i;
         }
      }

      phy_count = ((tx.StopChannel - tx.StartChannel) & AI_CHL_MASK) + 1;
      for (ptr = tx.Gain, i = tx.StartChannel; phy_count; ++i, ++ptr, --phy_count){
         *ptr = shared->AiChanGain[i & AI_CHL_MASK];
      }

      fwDataCount = shared->FaiParam.SectionSize * 2;

      if (shared->FirmwareVer < 0x0200010A) {
         totalFwDataCount = shared->FaiParam.SectionSize * shared->FaiParam.LogChanCount;
         while (totalFwDataCount % 10 == 0)
         {
            totalFwDataCount = totalFwDataCount / 10;
         }

         if ((shared->FaiParam.SectionSize * AI_DATA_SIZE) % FAI_PACKET_SIZE) {
           if (fwDataCount < 10) {
              fwDataCount = 10;
           } else {
              int power = -1;
              __u32 x;
              for (x = totalFwDataCount; x; x >>= 1) { ++power; }
              if (totalFwDataCount == (__u32)1 << power) {
                 fwDataCount += shared->FaiParam.LogChanCount * 2;
              }
           }
         }
      }
	   tx.DataCount = fwDataCount;
	  
      if (daq_usb_fai_start(daq_dev, &tx) < 0){
         ret = -EIO;
         goto start_hw_err;
      }

      daq_usb_fai_start_adc(daq_dev);
   }

   // add the task to wait_queue for sync read
   if (shared->FaiStatus.AcqMode == DAQ_ACQ_FINITE_SYNC){
      ret = wait_event_interruptible(daq_dev->fai_queue, shared->FaiStatus.FnState != DAQ_FN_RUNNING);
   }

   return ret;

start_hw_err:
   daq_usb_reader_stop(&daq_dev->usb_reader);

start_reader_err:
   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   shared->FaiStatus.FnState = DAQ_FN_READY;
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

