/*
 * kshared.h
 *
 *  Created on: 2013-5-30
 *      Author:
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x1809
#define DEVICE_ID     0x4711
#define DEVICE_PID    BD_USB4711A
#define DEVICE_NAME   "USB-4711A"
#define DRIVER_NAME   "bio4711a"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             16
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        (AI_CHL_COUNT / 2)

#define FAIINT_SPEED_UPLIMIT      150000     // 150K Hz
#define FAIINT_SPEED_DOWNLIMIT    1          // 1Hz
#define FAIPACER_MIN_SAMPLERATE   153        // 10000000HZ/65535

#define AI_MAX_PACER             (150*1000)           // 150KHz
#define AI_MIN_PACER             (1)

#define AI_CLK_BASE              (10*1000*1000)       // 10MHz clock
#define AI_FIFO_SIZE             1024                 // Ai fifo size in samples.
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)   //
#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(unsigned short)
#define AI_DATA_MASK             0xfff

#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt5To2pt5    1
#define AI_GAIN_V_Neg1pt25To1pt25  2
#define AI_GAIN_mV_Neg625To625     3
#define AI_GAIN_V_Neg10To10        4
#define AI_GAIN_V_0To10            16
#define AI_GAIN_V_0To5             17
#define AI_GAIN_V_0To2pt5          18
#define AI_GAIN_V_0To1pt25         19

//////////////////////////////////////////////////////////////////////////
//AO
#define AO_CHL_COUNT                2
#define AO_CHL_MASK                 (AO_CHL_COUNT - 1)   // 0x1 for 2 channel AO.
#define AO_RES_IN_BIT               12
#define AO_DATA_SIZE                sizeof(__u16)
#define AO_DATA_MASK                0xfff

#define AO_GAIN_V_0To5              0
#define AO_GAIN_V_0To10             1
#define AO_GAIN_V_Neg5To5           3
#define AO_GAIN_V_Neg10To10         4

//////////////////////////////////////////////////////////////////////////
//DIO
#define DIO_PORT_COUNT           1
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

//////////////////////////////////////////////////////////////////////////
//Counter
#define CNTR_CHL_COUNT           2
#define CNTR_RES_IN_BIT          32
#define CNTR_DATA_SIZE           sizeof(__u32)
#define CNTR_IDLE                0
#define CNTR_CLK_BASE            (24*1000*1000)       // MHz clock

#define FREQHI                   0
#define FREQLO                   1

#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// macros the usbcommon.h needed
// -----------------------------------------------------
#define  AI_CHANNEL_CONFIG
#define  MAX_AI_CHANNELS         AI_CHL_COUNT
#define  MAX_COUNTER_PARA        3

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg5To5
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (100 * 100)
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE / 2)
#define DEF_FAI_MODE            0

// AO default values
#define DEF_AO_GAIN             AO_GAIN_V_0To5
#define DEF_AO_STATE            0

// DIO default values
#define DEF_DO_STATE            0

// Counter
#define DEF_TMR_FREQ            10
#define DEF_TMR_CFG_C0          36
#define DEF_TMR_CFG_C1          32462
#define DEF_TMR_CFG_C2          64865

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   __u32  ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;
} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  HwFlag;
} FAI_STATUS;

typedef struct _USB_TMR_CONFIG
{
   __u32  Context[3];
} USB_TMR_CONFIG;

typedef struct _CNTR_CONFIG
{
   double          TmrFreq[CNTR_CHL_COUNT];
   USB_TMR_CONFIG  TmrCfg[CNTR_CHL_COUNT];
} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32  Operation;
} CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       FirmwareVer;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;
   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u16       AoChanState[AO_CHL_COUNT];

   // ---------------------------------------------------------
   __u8        DoPortState[DIO_PORT_COUNT];

   // ---------------------------------------------------------
   __u32       CntrBaseClk;
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
