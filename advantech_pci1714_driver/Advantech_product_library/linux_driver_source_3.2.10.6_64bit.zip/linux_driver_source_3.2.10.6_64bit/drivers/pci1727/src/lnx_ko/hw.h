/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AO
#define DR_AO_DATA_BASE   0x0
#define DR_AO_CHAN_HI(ch) (DR_AO_DATA_BASE + ch * 2)
#define DR_AO_CHAN_LO(ch) (DR_AO_DATA_BASE + ch * 2 + 1)

#define DR_AO_SYNC_CTL    0x1c
#define DR_AO_SYNC_STROBE 0x1d

#define DR_AO_TYPE_HIGH   0x24
#define DR_AO_TYPE_LOW    0x25

// device register : AO
#define DR_DI_BASE        0x1b
#define DR_DI_PORTX(x)    (DR_DI_BASE - x)
#define DR_DO_BASE        0x19
#define DR_DO_PORTX(x)    (DR_DO_BASE - x)

// device register : BID
#define DR_BID            0x23


#endif /* _KERNEL_MODULE_HW_H_ */
