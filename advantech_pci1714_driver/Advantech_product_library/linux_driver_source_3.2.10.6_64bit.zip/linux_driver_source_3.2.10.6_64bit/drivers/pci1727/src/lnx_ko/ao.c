/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   __u16         ao_type;
   int           i, mask;

   // get H/W set value and it can not be modify by software
   ao_type = AdxIoInB(shared->IoBase, DR_AO_TYPE_HIGH);
   ao_type = (ao_type << 8 ) | AdxIoInB(shared->IoBase, DR_AO_TYPE_LOW);
   for (i = 0, mask = 1; i < AO_CHL_COUNT; ++i, mask <<= 1) {
      shared->AoChanGain[i] = (ao_type & mask) ? mA_0To20 : V_Neg10To10;
   }

   // enable synchronized output
   AdxIoOutB(shared->IoBase, DR_AO_SYNC_CTL, 0x1);

   // set channel initial state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         AdxIoOutB(shared->IoBase, DR_AO_CHAN_HI(i), shared->AoChanState[i] >> 8);
         AdxIoOutB(shared->IoBase, DR_AO_CHAN_LO(i), (__u8)shared->AoChanState[i]);
      }
      AdxIoOutB(shared->IoBase, DR_AO_SYNC_STROBE, 0);
   }
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }


   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   for(i = 0; i < xbuf.ChanCount; ++i) {
      ch = (xbuf.ChanStart + i) % AO_CHL_COUNT;

      AdxIoOutB(shared->IoBase, DR_AO_CHAN_HI(ch), data[i] >> 8);
      AdxIoOutB(shared->IoBase, DR_AO_CHAN_LO(ch), (__u8)data[i]);
   }

   AdxIoOutB(shared->IoBase, DR_AO_SYNC_STROBE, 0);
   
   return 0;
}


