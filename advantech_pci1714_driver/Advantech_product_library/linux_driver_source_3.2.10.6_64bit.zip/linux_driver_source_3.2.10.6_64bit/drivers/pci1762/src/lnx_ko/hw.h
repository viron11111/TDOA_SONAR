/*
 * hw.h
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DR_DI_BASE        2
#define DR_DI_PORTX(x)    (DR_DI_BASE + x)

#define DR_DO_BASE        0
#define DR_DO_PORTX(x)    (DR_DO_BASE + x)

#define DR_BID            0x4

#define TRIG_EDGE_RISING   0
#define TRIG_EDGE_FALLING  1

typedef union _DI_INT_REG{
   __u8 Value;
   struct{
      __u8 Flag    : 1; //Interrupt flag, Read : 0: No interrupt, 1: Interrupt occurred
                        //                Write: 0: Don't care, 1: Clear the interrupt
      __u8 Enable  : 1; //Enable or not
      __u8 Edge    : 1; //Trigger edge: 0: Rising edge, 1: falling edge
      __u8 Reserved: 5;
   };
}DI_INT_REG;
#define DR_IntBase  0x6

#endif /* _KERNEL_MODULE_HW_H_ */
