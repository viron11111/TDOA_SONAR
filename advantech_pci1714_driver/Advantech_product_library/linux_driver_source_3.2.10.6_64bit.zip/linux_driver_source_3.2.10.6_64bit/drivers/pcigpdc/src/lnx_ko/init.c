/*
 * init.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include "kdriver.h"
#include "hw.h"

// device supported
static
struct pci_device_id daq_device_ids[] = {
   { PCI_DEVICE(ADVANTECH_VID, 0xe730) },
   { PCI_DEVICE(ADVANTECH_VID, 0xe751) },
   { PCI_DEVICE(ADVANTECH_VID, 0xe752) },
   { PCI_DEVICE(ADVANTECH_VID, 0xe754) },
   { PCI_DEVICE(ADVANTECH_VID, 0xe756) },
   { PCI_DEVICE(ADVANTECH_VID, 0xe760) },
   { 0, }
};
MODULE_DEVICE_TABLE(pci, daq_device_ids);

/************************************************************************
* DEVICE FEATURE
************************************************************************/
DEVICE_FEATURE const PCIe1753_Feature = 
{
   //-----------------------------------------------
   "PCIE-1753", 4,
   //-----------------------------------------------
   12, 0, 12, 12, 12, 12, 12, {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff},
   //-----------------------------------------------
   0, {0x00},
   //-----------------------------------------------
   3, {0x00EE0000, 0x00EEEEEE, 0x0000EEEE}, 
   {  
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, KdxDicosPort0, KdxDipmPort0, -1, KdxDiintChan0 + 1, KdxDicosPort0 + 1, KdxDipmPort0 + 1, -1,
      KdxCntOneShot0, -1, -1, -1, KdxCntOneShot0 + 1, -1, -1, -1,

      KdxDiintChan0 + 2, KdxDicosPort0 + 2, KdxDipmPort0 + 2, -1, KdxDiintChan0 + 3, KdxDicosPort0 + 3, KdxDipmPort0 + 3, -1,
      KdxDiintChan0 + 4, KdxDicosPort0 + 4, KdxDipmPort0 + 4, -1, KdxDiintChan0 + 5, KdxDicosPort0 + 5, KdxDipmPort0 + 5, -1,
      KdxDiintChan0 + 6, KdxDicosPort0 + 6, KdxDipmPort0 + 6, -1, KdxDiintChan0 + 7, KdxDicosPort0 + 7, KdxDipmPort0 + 7, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,

      KdxDiintChan0 + 8, KdxDicosPort0 + 8, KdxDipmPort0 + 8, -1, KdxDiintChan0 + 9, KdxDicosPort0 + 9, KdxDipmPort0 + 9, -1,
      KdxDiintChan0 + 10, KdxDicosPort0 + 10, KdxDipmPort0 + 10, -1, KdxDiintChan0 + 11, KdxDicosPort0 + 11, KdxDipmPort0 + 11, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
   },
};

DEVICE_FEATURE const PCIe1751_Feature = 
{
   //-----------------------------------------------
   "PCIE-1751",  4,
   //-----------------------------------------------
   6, 0, 6, 6, 6, 6, 6, {0xff,0xff,0xff,0xff,0xff,0xff},
   //-----------------------------------------------
   3, {0x01,0x01,0x01},
   //-----------------------------------------------
   2, {0}, 
   { 
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, KdxDicosPort0, KdxDipmPort0, -1, KdxDiintChan0 + 1, KdxDicosPort0 + 1, KdxDipmPort0 + 1, -1,
      KdxCntOneShot0, -1, -1, -1, KdxCntOneShot0 + 1, -1, -1, -1,

      KdxDiintChan0 + 2, KdxDicosPort0 + 2, KdxDipmPort0 + 2, -1, KdxDiintChan0 + 3, KdxDicosPort0 + 3, KdxDipmPort0 + 3, -1,
      KdxDiintChan0 + 4, KdxDicosPort0 + 4, KdxDipmPort0 + 4, -1, KdxDiintChan0 + 5, KdxDicosPort0 + 5, KdxDipmPort0 + 5, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxCntOneShot0 + 2, -1, -1, -1, -1, -1, -1, -1,
   },
};

DEVICE_FEATURE const PCIe1730_Feature = 
{
   //-----------------------------------------------
   "PCIE-1730",  4,
   //-----------------------------------------------
   4, 0, 4, 4, 0, 0, 0, {0x00},
   //-----------------------------------------------
   0, {0x00},
   //-----------------------------------------------
   2, {0x00110000, 0x00000011},
   { 
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, -1, -1, -1, KdxDiintChan0 + 1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,

      KdxDiintChan0 + 2, -1, -1, -1, KdxDiintChan0 + 3, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
   },
};

DEVICE_FEATURE const PCIe1756_Feature = 
{
   //-----------------------------------------------
   "PCIE-1756",  4,
   //-----------------------------------------------
   4, 1, 4, 4, 0, 0, 0, {0x00},
   //-----------------------------------------------
   0, {0x00},
   //-----------------------------------------------
   2, {0x00110000, 0x00000011}, 
   { 
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, -1, -1, -1, KdxDiintChan0 + 1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,

      KdxDiintChan0 + 2, -1, -1, -1, KdxDiintChan0 + 3, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
   },
};

DEVICE_FEATURE const PCIe1754_Feature = 
{
   //-----------------------------------------------
   "PCIE-1754",  4,
   //-----------------------------------------------
   0,0, 8, 8, 0, 0, 0, {0x00},
   //-----------------------------------------------
   0, {0x00},
   //-----------------------------------------------
   2, {0x00110000, 0x00111111},
   { 
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, -1, -1, -1, KdxDiintChan0 + 1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,

      KdxDiintChan0 + 2, -1, -1, -1, KdxDiintChan0 + 3, -1, -1, -1,
      KdxDiintChan0 + 4, -1, -1, -1, KdxDiintChan0 + 5, -1, -1, -1,
      KdxDiintChan0 + 6, -1, -1, -1, KdxDiintChan0 + 7, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
   },
};

DEVICE_FEATURE const PCIe1752_Feature = 
{
   //-----------------------------------------------
   "PCIE-1752",  4,
   //-----------------------------------------------
   8, 1, 0, 0, 0, 0, 0, {0x00},
   //-----------------------------------------------
   0, {0x00},
   //-----------------------------------------------
   0, {0x00000000}, {0x00},
};

DEVICE_FEATURE const PCIe1760_Feature = 
{
   //-----------------------------------------------
   "PCIE-1760", 4,
   //-----------------------------------------------
   1, 0, 1, 1, 1, 1, 1, {0xff},
   //-----------------------------------------------
   2, {0x00},
   //-----------------------------------------------
   1, {0x00000000},
   { 
      -1, -1, -1, -1, -1, -1, -1, -1,
      -1, -1, -1, -1, -1, -1, -1, -1,
      KdxDiintChan0, KdxDicosPort0, KdxDipmPort0, -1, -1, -1, -1, -1,
      KdxCntOneShot0, -1, -1, -1, KdxCntOneShot0 + 1, -1, -1, -1,
   },
};

/************************************************************************
* FILE OPERATIONS
************************************************************************/
static
struct file_operations daq_fops = {
   .owner    = THIS_MODULE,
   .open     = daq_file_open,
   .release  = daq_file_close,
   .mmap     = daq_file_mmap,
   .unlocked_ioctl = daq_file_ioctl,
};

/************************************************************************
* device settings
************************************************************************/
static
void daq_device_load_setting(daq_device_t  *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   // DIO
   shared->DoFrzEnabled = 0;
   for (i = 0; i < DIO_PORT_COUNT_MAX; ++i) {
      shared->DioPortDir[i] = DEF_DIO_DIR;
      shared->DoPortState[i]= DEF_DO_STATE;
      shared->DiOpenState[i] = pullLowAllPort;
   }
   for (i = 0; i < DI_INT_SRC_COUNT_MAX; ++i){
      shared->DiintTrigEdge[i] = DEF_DIINT_TRIGEDGE;
   }
   shared->DiFltTime = 1;

   // Counter
   // Init counter
   for (i = 0; i < CNTR_CHL_COUNT_MAX; ++i)
   {
      //EventCount
      shared->CntrConfig.EcClkPolarity[i]  = Positive;
      shared->CntrConfig.EcGatePolarity[i] = Positive;
      shared->CntrConfig.EcGateEnabled[i]  = 0;

      // One-shot
      shared->CntrConfig.OsClkSource[i]   = SigCntClk0 + i;
      shared->CntrConfig.OsGateSource[i]  = SigCntGate0 + i;
      shared->CntrConfig.OsClkPolarity[i] = Positive;
      shared->CntrConfig.OsGatePolarity[i]= Positive;
      shared->CntrConfig.OsOutSigType[i]  = PositivePulse;
      shared->CntrConfig.OsDelayCount[i]  = 1000; 

      // Timer/Pulse
      shared->CntrConfig.TmrDivisor[i]      = CNTR_TMR_DIV_MAX;   // default frequency is 0.005Hz
      shared->CntrConfig.TmrOutSigType[i]   = PositivePulse;
      shared->CntrConfig.TmrGatePolarity[i] = Positive;
      shared->CntrConfig.TmrGateEnabled[i]  = 0;

      // Frequency measurement

      // PwmOut
      shared->CntrConfig.PoHiPeriod[i]   = 160;           // default is 0.08s
      shared->CntrConfig.PoLoPeriod[i]   =  40;           // default is 0.02s
      shared->CntrConfig.PoSignalType[i] = PositivePulse; // default is toggle from high
      // PwmIn
   }
}

/************************************************************************
* sysfs support routines
************************************************************************/
#include <biosysfshelper.h>

// ------------------------------------------------------------------
// Device initialize/de-initailize
// ------------------------------------------------------------------
static
int __devinit daq_device_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
   dev_t         devid;
   daq_device_t  *daq_dev;
   DEVICE_SHARED *shared;
   struct device *sysfs_dev;
   size_t        mem_size;
   int           ret, i;

#define CHK_RESULT(_ok_, err, err_label)   if (!(_ok_)) { ret = err; goto err_label; }

   if ((ret = pci_enable_device(dev)) != 0) {
      daq_trace((KERN_ERR": pci_enable_device failed\n"));
      return ret;
   }
   pci_set_master(dev);   /* enable bus-master */

   // allocate private data structure
   mem_size = (sizeof(daq_device_t) + PAGE_SIZE - 1) & PAGE_MASK;
   daq_dev  = (daq_device_t*)kzalloc(mem_size, GFP_KERNEL);
   CHK_RESULT(daq_dev, -ENOMEM, err_alloc_dev)

   // initialize the private data in the device
   shared               = &daq_dev->shared;
   shared->Size         = sizeof(*shared);
   shared->DeviceNumber = -1; // unknown
   shared->BusNumber    = dev->bus->number;
   shared->SlotNumber   = PCI_SLOT(dev->devfn);
   shared->Irq          = dev->irq;

   switch (id->device)
   {
   case 0xE730:
      shared->ProductId = BD_PCIE1730;
      shared->Feature   = PCIe1730_Feature;
      break;
   case 0xE751:
      shared->ProductId = BD_PCIE1751;
      shared->Feature   = PCIe1751_Feature;
      break;
   case 0xE752:
      shared->ProductId = BD_PCIE1752;
      shared->Feature   = PCIe1752_Feature;
      break;
   case 0xE754:
      shared->ProductId = BD_PCIE1754;
      shared->Feature   = PCIe1754_Feature;
      break;
   case 0xE756:
      shared->ProductId = BD_PCIE1756;
      shared->Feature   = PCIe1756_Feature;
      break;
   case 0xE753:
      shared->ProductId = BD_PCIE1753;
      shared->Feature   = PCIe1753_Feature;
      break;
   case 0xE760:
      shared->ProductId = BD_PCIE1760;
      shared->Feature   = PCIe1760_Feature;
      break;
   default:
      shared->ProductId = -1;
      break;
   }

   shared->DoDataBase = REG_Dio_Base;
   shared->DoCtlBase = REG_Dio_Base + 0x20;
   if(  !shared->Feature.DoPortCount 
      || shared->ProductId == BD_PCIE1751 
      || shared->ProductId == BD_PCIE1753) {
      shared->DiDataBase = shared->DoDataBase;
      shared->DiCtlBase = shared->DoCtlBase;
   } else if(shared->Feature.DoPortCount < 4) {
      shared->DiDataBase = shared->DoDataBase + 0x04;
      shared->DiCtlBase = shared->DoCtlBase + 4 * DEV_CTL_PORT_OFFSET;
   } else {
      shared->DiDataBase = shared->DoDataBase + shared->Feature.DoPortCount;
      shared->DiCtlBase = shared->DoCtlBase + shared->Feature.DoPortCount * DEV_CTL_PORT_OFFSET;
   }

   // retrieve the I/O resources
   for (i = 0; i < shared->Feature.PciBarCount; ++i) {
      shared->PhysBase[i]= dev->resource[i].start & ~1UL;
      shared->PhysLength[i] = dev->resource[i].end - shared->PhysBase[i] + 1;

      /* request I/O regions */
      CHK_RESULT(\
         request_mem_region(shared->PhysBase[i], shared->PhysLength[i], DEVICE_NAME_FROM_PID(shared->ProductId)),\
         -EBUSY, err_no_res_device);

      /* mapping I/O to memory */
      daq_dev->virt_base[i] = ioremap(shared->PhysBase[i], shared->PhysLength[i]);
      CHK_RESULT(daq_dev->virt_base[i], -EBUSY, err_no_res_device);
   }

   /* request irq */
   ret = request_irq(shared->Irq, (daq_irq_handler_t)daq_irq_handler, IRQF_SHARED, DRIVER_NAME, daq_dev);
   CHK_RESULT(ret == 0, ret, err_irq);

   spin_lock_init(&daq_dev->dev_lock);
   tasklet_init(&daq_dev->int_tasklet, daq_int_tasklet_func, (unsigned long)daq_dev);
   INIT_LIST_HEAD(&daq_dev->file_ctx_list);
   daq_dev->file_ctx_pool_size = (mem_size - sizeof(daq_device_t)) / sizeof(daq_file_ctx_t);
   if (daq_dev->file_ctx_pool_size){
      daq_dev->file_ctx_pool = (daq_file_ctx_t *)(daq_dev + 1);
   } else {
      daq_dev->file_ctx_pool = NULL;
   }

   // Get other information such as board ID (dip switch number) 
   shared->BoardId = AdxMemInB(daq_dev->virt_base[0], REG_BAR_INDICATOR) & 0xF;
   shared->PcbVer  = AdxMemInD(daq_dev->virt_base[0], REG_PCB_VER) & 0x00FFFFFF;
   shared->PldVer  = AdxMemInD(daq_dev->virt_base[0], REG_PLD_VER);
   shared->FwVer   = AdxMemInB(daq_dev->virt_base[0], REG_FW_VER);
   shared->InitOnLoad = !(AdxMemInB(daq_dev->virt_base[1], REG_CARDSETTING_BASE) & 0x1);

   /*Get dynamic device number*/
   devid = daq_devid_alloc();
   CHK_RESULT(devid > (dev_t)0, -ENOSPC, err_no_devid)

   /*register our device into kernel*/
   cdev_init(&daq_dev->cdev, &daq_fops);
   daq_dev->cdev.owner = THIS_MODULE;
   ret = cdev_add(&daq_dev->cdev, devid, 1);
   CHK_RESULT(ret == 0, ret, err_cdev_add)

   /* register our own device in sysfs, and this will cause udev to create corresponding device node */
   sysfs_dev = DAQ_SYSFS_INITIALIZE(devid, daq_dev);
   CHK_RESULT(!IS_ERR(sysfs_dev), PTR_ERR(sysfs_dev), err_sysfs_reg)

   // link the info into the other structures
   pci_set_drvdata(dev, daq_dev);
   SetPageReserved(virt_to_page((unsigned long)daq_dev));

   // initialize the device
   daq_device_load_setting(daq_dev);
   daq_dio_initialize_hw(daq_dev);

   // Winning horn
   daq_trace((KERN_INFO "Add %s: major:%d, minor:%d\n", DEVICE_NAME, MAJOR(devid), MINOR(devid)));
   daq_trace((KERN_INFO "dev base addr:[0x%x, %d], bid:%d\n",\
       shared->IoBase, shared->IoLength, shared->BoardId));

   return 0;

err_sysfs_reg:
   cdev_del(&daq_dev->cdev);

err_cdev_add:
   daq_devid_free(devid);

err_no_devid:
   free_irq(shared->Irq, daq_dev);

err_irq:
err_no_res_device:
   for (i = 0; i < shared->Feature.PciBarCount; ++i) {
      if (shared->PhysBase[i]) {
         if (daq_dev->virt_base[i]) {
            iounmap(daq_dev->virt_base[i]);
         }
         release_mem_region(shared->PhysBase[i], shared->PhysLength[i]);
      }
   }
   kfree(daq_dev);

err_alloc_dev:
   pci_disable_device(dev);

   daq_trace((KERN_ERR "Add %s failed. error = %d\n", DEVICE_NAME, ret));
   return ret;
}

void daq_device_cleanup(daq_device_t * daq_dev)
{
   // Delete device node under /dev
   cdev_del(&daq_dev->cdev);
   daq_devid_free(daq_dev->cdev.dev);
   device_destroy(daq_class_get(), daq_dev->cdev.dev);

   // Free the device information structure
   ClearPageReserved(virt_to_page((unsigned long)daq_dev));
   kfree(daq_dev);
}

static
void __devexit daq_device_remove(struct pci_dev *dev)
{
   daq_device_t *daq_dev = pci_get_drvdata(dev);
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   daq_trace((KERN_INFO"Device removed!\n"));

   for (i = 0; i < shared->Feature.PciBarCount; ++i) {
      iounmap(daq_dev->virt_base[i]);
      release_mem_region(shared->PhysBase[i], shared->PhysLength[i]);
   }

   free_irq(shared->Irq, daq_dev);

   pci_set_drvdata(dev, NULL);
   pci_disable_device(dev);
   {
      unsigned long flags;
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (list_empty(&daq_dev->file_ctx_list)){
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_device_cleanup(daq_dev);
      } else {
         daq_dev->remove_pending = 1;
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      }
   }
}

// ------------------------------------------------------------------
// Driver initialize/de-initailize
// ------------------------------------------------------------------
static
struct pci_driver pci_driver = {
   .name      = DRIVER_NAME,
   .probe     = daq_device_probe,
   .remove    = __devexit_p(daq_device_remove),
   .id_table  = daq_device_ids,
};

static
int __init daq_driver_init(void)
{
   return pci_register_driver(&pci_driver);
}

static
void __exit daq_driver_exit(void)
{
   pci_unregister_driver(&pci_driver);
}

module_init(daq_driver_init);
module_exit(daq_driver_exit);

MODULE_LICENSE("GPL");
