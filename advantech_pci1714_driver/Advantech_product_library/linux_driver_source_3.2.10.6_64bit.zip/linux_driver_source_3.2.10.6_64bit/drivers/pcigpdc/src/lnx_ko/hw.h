/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define FLASH_DELAY_TIME_UNIT_IN_2us     1

//
//################################################################

#define REG_BAR_INDICATOR        0x00
#define REG_PCB_VER              0x04
#define REG_PLD_VER              0x08
#define REG_FW_VER               0x0C
#define REG_FPGA_BOOT_CODE       0x10
#define REG_FPGA_BKUP_CODE       0x14
#define REG_FPGA_FLASH_SIZE      0x18

//
//################################################################
#define INT_SECT_LEN          4
#define INT_SECT_LEN_UNO      8
#define REG_INT_BASE          0x00
#define REG_IntCSR(x)         (REG_INT_BASE + ((x) * INT_SECT_LEN))
#define REG_CARDSETTING_BASE  0x40

// Dio Data Register : Port x data
#define REG_Dio_Base                 0x100
#define REG_DioPortX(base, x)      (base + x)

// Control Register : Port x data
#define DEV_DOCTL_LEN                     4
#define DEV_CTL_PORT_OFFSET               0x10
#define DEV_CTL_DW_SECT_OFFSET            0x04
#define REG_DOCTL_PortX(base, port, sect) ((base) + (port) * DEV_CTL_PORT_OFFSET + (sect) * DEV_CTL_DW_SECT_OFFSET)

#define DEV_DICTL_LEN                     8
#define REG_DICTL_PortX(base, port, sect) ((base) + (port) * DEV_CTL_PORT_OFFSET + (sect) * DEV_CTL_DW_SECT_OFFSET)

#define CtrlSection0  0
#define CtrlSection1  1
#define CtrlSection2  2
#define CtrlSection3  3

//
//################################################################
#define PORTDIR_OUT   0
#define PORTDIR_IN    1
#define PULL_DOWN     0
#define PULL_UP       1

typedef union _DIO_CTL_REG{
   __u8 Value;
   struct{
      __u8 PCLowDir  : 1;  
      __u8 DiLowPUD  : 1;
      __u8 Reserved0 : 2;
      __u8 PCHighDir : 1;  
      __u8 DiHigPUD  : 1;
      __u8 Reserved1 : 2;
   };
}DIO_CTL_REG;

typedef union _DIO_CTL_REG0{
   __u32 Value;
   struct{
      __u32 PCLowDir    : 1;  
      __u32 DiPDHLow    : 1;
      __u32 Reserved0   : 2;
      __u32 PCHighDir   : 1;  
      __u32 DiPDHHig    : 1;
      __u32 Reserved1   : 2;

      __u32 DiIntEn     : 1; 
      __u32 DiCSEn      : 1; 
      __u32 DiPmEn      : 1; 
      __u32 Reserved2   : 5;

      __u32 LatchPortEn : 1; 
      __u32 EDG         : 1; 
      __u32 Reserved3   : 6;
      __u32 ChFrzAct    : 1; 
      __u32 ChFrzSta    : 1; 
      __u32 Reserved4   : 6;
   };

}DIO_CTL_REG0;

#define TRIG_EDGE_RISING   0  
#define TRIG_EDGE_FALLING  1  

typedef union _DIO_CTL_REG1{
   __u32 Value;
   struct{
      __u32 PatternValue : 8; 
      __u32 PatternMatchEn : 8; 
      __u32 ChangeStatusEn : 8; 
      __u32 DigitalFilterEn : 8;  
   };
}DIO_CTL_REG1;

typedef union _DIO_CTL_REG2{
   __u32 Value;
   struct{
      __u32 LatchData : 8; 
      __u32 Reserved : 24;
   };
}DIO_CTL_REG2;

typedef union _DIO_CTL_REG3{
   __u32 Value;
   struct{
      __u32 DigitalFilterSampleNum : 8; 
      __u32 Reserved : 24;
   };

}DIO_CTL_REG3;

// DIO control value
#define DIO_CS_DISABLE         0       
#define DIO_CS_ENABLE          1       
#define DIO_PM_DISABLE         0       
#define DIO_PM_ENABLE          1       
#define DIO_LAT_DISABLE        0       
#define DIO_LAT_ENABLE         1       

//
//################################################################
#define REG_CNTR_STEP          0x100   
#define REG_CNTRCTL_BASE       0x200
#define REG_CNTRCFG_BASE1      0x204
#define REG_CNTRCFG_BASE2      0x220
#define REG_CNTRCFG_BASE3      0x240
#define REG_CNTRVAL_BASE1      0x228
#define REG_CNTRVAL_BASE2      0x22C
#define REG_CNTR_REP_BASE      0x230
#define REG_CNTR_LOAD_BASE     0x234
#define REG_CNTR_FMTS_BASE     0x244
#define REG_CNTR_FMHP_BASE     0x248
#define REG_CNTR_FMLP_BASE     0x24C
#define REG_CNTR_POCL_BASE     0x234
#define REG_CNTR_POCLL_BASE    0x238

#define REG_CNTRFLG_STEP       0x004
#define REG_CNTRFLG_BASE       0x003

typedef union _CNTR_CTL_REG{
   __u32 Value;
   struct{
      __u32 CTR       : 1; 
      __u32 ARM       : 1; 
      __u32 Reserved1 : 6;
      __u32 CDFE      : 1;
      __u32 Reserved2 : 7;
      __u32 CDF       : 8;
      __u32 Reserved3 : 8;
   };

}CNTR_CTL_REG;

typedef union _CNTR_CFG_REG1{
   __u32 Value;
   struct{
      __u32 ClkSrc      : 3;
      __u32 Reserved5   : 4;
      __u32 ClkPolarity : 1;
      __u32 Reserved6   : 24;
   };

}CNTR_CFG_REG1;

typedef union _CNTR_CFG_REG2{
   __u32 Value;
   struct{
      __u32 GateSrc   : 3;
      __u32 Reserved1 : 1;
      __u32 GM        : 2;
      __u32 Reserved2 : 1;
      __u32 GP        : 1;
      __u32 COS       : 2;
      __u32 Reserved3 : 2;
      __u32 COM       : 2;
      __u32 Reserved4 : 2;
      __u32 CRPWM     : 1;
      __u32 Reserved5 : 7;
      __u32 INTE      : 1;
      __u32 Reserved6 : 3;
      __u32 CRI       : 1;
      __u32 Reserved7 : 2;
      __u32 COE       : 1;
   };

}CNTR_CFG_REG2;

#define REG_CNTRCTL_X(base, cntr)   ((base) + (cntr) * REG_CNTR_STEP)
#define REG_CNTRCFG_X(base, cntr)   ((base) + (cntr) * REG_CNTR_STEP)
#define REG_CNTRVAL_X(base, cntr)   ((base) + (cntr) * REG_CNTR_STEP)
#define REG_CNTRFLG_X(cntr)         (1 << ((cntr) * REG_CNTRFLG_STEP))

// Counter control value
#define CNTR_ARM_STOP          0
#define CNTR_ARM_START         1
#define CNTR_CTR_KEEP          0
#define CNTR_CTR_RESET         1
#define CNTR_CS_EXNTERNAL      0
#define CNTR_CS_20MHZ          4
#define CNTR_CS_2MHz           5
#define CNTR_CS_200KHZ         6
#define CNTR_CS_20KHZ          7
#define CNTR_CP_RISING         0
#define CNTR_CP_FALLING        1
#define CNTR_INTE_DISABLE      0
#define CNTR_INTE_ENABLE       1
#define CNTR_CRI_DISABLE       0
#define CNTR_CRI_ENABLE        1
#define CNTR_COE_DISABLE       0
#define CNTR_COE_ENABLE        1
#define CNTR_GS_EXNTERNAL      0
#define CNTR_GS_2KHZ           4
#define CNTR_GS_200HZ          5
#define CNTR_GS_20HZ           6
#define CNTR_GS_2HZ            7
#define CNTR_COM_ACTIVEHIGH    0
#define CNTR_COM_ACTIVELOW     1
#define CNTR_COM_TOGGLELOW     2
#define CNTR_COM_TOGGLEHIGH    3
#define CNTR_CRPWM_ENALBE      1
#define CNTR_CRPWM_DISABLE     0
#define CNTR_GM_NOGATE         0
#define CNTR_GM_LAVELMODE      1
#define CNTR_GM_EDGEMODE       2
#define CNTR_GM_RETRIGGER      3
#define CNTR_GP_RISING         0
#define CNTR_GP_FALLING        1
#define CNTR_COFE_ENABLE       1
#define CNTR_COFE_DISABLE      1


#endif /* _KERNEL_MODULE_HW_H_ */
