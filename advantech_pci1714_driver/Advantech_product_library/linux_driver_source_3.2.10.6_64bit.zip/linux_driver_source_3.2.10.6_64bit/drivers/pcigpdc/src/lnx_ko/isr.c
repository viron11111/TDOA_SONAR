/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
static inline
void daq_int_snap_di_ports(daq_device_t *daq_dev, DI_SNAP *snap)
{
   unsigned i;
   __u8     *ptr = &snap->State[snap->Start];

   for (i = snap->Start; i < snap->Start + snap->Count; ++i, ++ptr) {
      *ptr = AdxMemInB(daq_dev->virt_base[1], REG_DioPortX(daq_dev->shared.DiDataBase, i));
   }
}

void daq_int_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   unsigned long flags;
   __u32         intr_csr[INT_SECT_COUNT_MAX];
   __u32         sect, byteIdx, bitIdx, csr, event_kdx;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   for (sect = 0; sect < shared->Feature.IntSectCount; ++sect) {
      intr_csr[sect] = shared->IntState[sect];
      shared->IntState[sect] = 0;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   for (sect = 0; sect < shared->Feature.IntSectCount; ++sect) {

      if (!intr_csr[sect]) {
         continue;
      }

      for (byteIdx = 0; byteIdx < 4; ++byteIdx) {

         csr = (intr_csr[sect] >> (byteIdx * 8)) & 0xff;

         for (bitIdx = 0; csr; csr >>= 1, ++bitIdx) {

            if (!(csr & 0x1)) {
               continue;
            }

            event_kdx = shared->Feature.IntSectMap[sect * INT_FLAG_PER_SECT + byteIdx * 8 + bitIdx];
            if (event_kdx == -1) {
               continue;
            }

            if (event_kdx >= KdxDiBegin && event_kdx <= KdxDiEnd) {
               daq_int_snap_di_ports(daq_dev, &shared->DiSnap[event_kdx - KdxDiBegin]);
            } 

            if (!shared->IsEvtSignaled[event_kdx]) {
               shared->IsEvtSignaled[event_kdx] = 1;
               daq_device_signal_event(daq_dev, event_kdx);
            }
         }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u32 intr_csr[INT_SECT_COUNT_MAX], intr_active = 0;
   __u32 i;

   for (i = 0; i < shared->Feature.IntSectCount; ++i) {
      intr_csr[i] = AdxMemInD(daq_dev->virt_base[1], REG_IntCSR(i));
      if (intr_csr[i]) {
         intr_active = 1;
         AdxMemOutD(daq_dev->virt_base[1], REG_IntCSR(i),intr_csr[i]); 
      }
   }

   if (!intr_active) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   for (i = 0; i < shared->Feature.IntSectCount; ++i) {
      shared->IntState[i] |= intr_csr[i];
   }
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->int_tasklet);

   return IRQ_RETVAL(1);
}

