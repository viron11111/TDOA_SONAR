/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DRIVER_NAME   "biogpdc"

#define PCIBAR_COUNT  5

#define DEVICE_NAME_FROM_PID(pid) deviceNameFromPid(pid)
#define DEVICE_ID_FROM_PID(pid)   deviceIdFromPid(pid)

#ifdef __cplusplus
#  define char_const char const
#else
#  define char_const char
#endif
static inline char_const * deviceNameFromPid(int pid)
{   
   char_const *name;
   switch (pid)
   {
   case BD_PCIE1730: name = "PCIe-1730"; break;
   case BD_PCIE1751: name = "PCIe-1751"; break;
   case BD_PCIE1752: name = "PCIe-1752"; break;
   case BD_PCIE1754: name = "PCIe-1754"; break;
   case BD_PCIE1756: name = "PCIe-1756"; break;
   case BD_PCIE1753: name = "PCIe-1753"; break;
   case BD_PCIE1760: name = "PCIe-1760"; break;
   default:          name = "unknown";   break;
   }
   return name;
}

static inline int deviceIdFromPid(int pid)
{
   int id;
   switch (pid)
   {
   case BD_PCIE1730: id = 0xe730; break;
   case BD_PCIE1751: id = 0xe751; break;
   case BD_PCIE1752: id = 0xe752; break;
   case BD_PCIE1754: id = 0xe754; break;
   case BD_PCIE1756: id = 0xe756; break;
   case BD_PCIE1753: id = 0xe753; break;
   case BD_PCIE1760: id = 0xe760; break;
   default:          id = 0xffff; break;
   }
   return id;
}
// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
//DIO 
#define DIO_PORT_COUNT_MAX           16
#define DIO_CHL_COUNT_MAX            (DIO_PORT_COUNT_MAX * 8)
#define DI_INT_SRC_COUNT_MAX         DIO_PORT_COUNT_MAX 
#define DI_COS_SRC_COUNT_MAX         DIO_PORT_COUNT_MAX  
#define DI_PM_SRC_COUNT_MAX          DIO_PORT_COUNT_MAX
#define DI_SNAP_SRC_COUNT_MAX        (DI_INT_SRC_COUNT_MAX + DI_COS_SRC_COUNT_MAX  + DI_PM_SRC_COUNT_MAX)
#define DI_SNAP_SRC_COUNT(feat)      (feat.DiIntSrcCount + feat.DiPmSrcCount + feat.DiCosSrcCount)

#define DI_FLT_SRC_COUNT_MAX         DIO_PORT_COUNT_MAX
#define DI_FLT_SMPL_INTVL_US         1                                              // Di filter sampling interval: 1us
#define DI_FLT_SMPL_INTVL_MS         0.001                                          // Di filter sampling interval: 0.001ms

#define DI_FLT_TIME_RANGE_MIN        1
#define DI_FLT_TIME_RANGE_MIN_1760   60
#define DI_FLT_TIME_RANGE_MAX        255

#define CNTR_FLT_SRC_COUNT_MAX       8
#define CNTR_FLT_SMPL_INTVL          1  
#define CNTR_FLT_TIME_RANGE_MIN      1
#define CNTR_FLT_TIME_RANGE_MAX      255

//----------------------------------------------------------------------
//COUNTER
#define CNTR_CHL_COUNT_MAX          8
#define CNTR_RES_IN_BIT             32
#define CNTR_MIN_VAL                0
#define CNTR_MAX_VAL                0xffffffff
#define CNTR_CLK_BASE               (20 * 1000 * 1000)

#define CNTR_OS_DELAY_MIN           1
#define CNTR_OS_DELAY_MAX           0xffffffff

#define CNTR_TMR_FREQ_MIN           0.005
#define CNTR_TMR_FREQ_MAX           (5 * 1000 * 1000)
#define CNTR_TMR_FREQ_MAX_1760      1000 
#define CNTR_TMR_DIV_MAX            0xee6b2800
#define CNTR_TMR_DIV_MIN            0x4

#define CNTR_PWMO_RESOLUTION        (50 * 0.001 * 0.001 * 0.001)        // 50ns
#define CNTR_PWMO_BIN_MIN           0x1                                 // 2
#define CNTR_PWMO_BIN_MIN_1760      0x2
#define CNTR_PWMO_BIN_MAX           0xffffffff

#define CNTR_PWMO_MIN_VAL           (CNTR_PWMO_BIN_MIN * CNTR_PWMO_RESOLUTION * 2)  // 0.0000001
#define CNTR_PWMO_MIN_VAL_1760      0.0001                                          // isolated component
#define CNTR_PWMO_MAX_VAL           (CNTR_PWMO_BIN_MAX * CNTR_PWMO_RESOLUTION)      // 214.748364750//2^32 - 1   
#define CNTR_PWMO_MAX_VAL_1760      200                                             // isolated component

#define CNTR_OP_IDLE                0x00000000
#define CNTR_OP_EVENTCOUNT          0x00000001
#define CNTR_OP_ONESHOT             0x00000002
#define CNTR_OP_TIMERPULSE          0x00000004
#define CNTR_OP_FREQMETER           0x00000008
#define CNTR_OP_PWMIN               0x00000010
#define CNTR_OP_PWMOUT              0x00000020

//----------------------------------------------------------------------
// Others
#define INT_SECT_COUNT_MAX        3
#define INT_FLAG_PER_SECT         32

#define KdxDiBegin                0
#define KdxDiintChan0             (KdxDiBegin + 0)
#define KdxDicosPort0             (KdxDiintChan0 + DI_INT_SRC_COUNT_MAX)
#define KdxDipmPort0              (KdxDicosPort0 + DI_COS_SRC_COUNT_MAX)
#define KdxDiEnd                  (KdxDipmPort0  + DI_PM_SRC_COUNT_MAX - 1)

#define KdxCntBegin               (KdxDiEnd + 1)
#define KdxCntOneShot0            (KdxCntBegin + 0)
#define KdxCntTimer0              (KdxCntOneShot0 + CNTR_CHL_COUNT_MAX)
#define KdxCntEnd                 (KdxCntTimer0 + CNTR_CHL_COUNT_MAX - 1)

#define KdxDevPropChged           (KdxCntEnd + 1)
#define KrnlSptedEventCount       (KdxDevPropChged + 1) 

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx = -1;
   if (eventType == EvtPropertyChanged) {
      kdx = KdxDevPropChged;
   } else if (eventType >= EvtDiintChannel000 && eventType <= EvtDiintChannel120) {
      kdx = KdxDiintChan0 + (eventType - EvtDiintChannel000) / 8;
   } else if (eventType >= EvtDiCosintPort000 && eventType <= EvtDiCosintPort015) {
      kdx = KdxDicosPort0 + eventType - EvtDiCosintPort000;
   } else if (eventType >= EvtDiPmintPort000 && eventType <= EvtDiPmintPort015) {
      kdx = KdxDipmPort0 + eventType - EvtDiPmintPort000;
   } else if (eventType >= EvtCntTimer0 && eventType <= EvtCntTimer7) {
      kdx = KdxCntTimer0 + eventType - EvtCntTimer0;
   } else if (eventType >= EvtCntOneShot0 && eventType <= EvtCntOneShot7) {
      kdx = KdxCntOneShot0 + eventType - EvtCntOneShot0;
   }
   
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DIO_DIR             0
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP
{
   __u8 Start;
   __u8 Count;
   __u8 State[DIO_PORT_COUNT_MAX];
} DI_SNAP;

typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------
   __u32  ClkFltEnabled[CNTR_CHL_COUNT_MAX];
   __u32  ClkFltTime[CNTR_CHL_COUNT_MAX];

   // --------------------------------------------------------
   __u32  EcClkPolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  EcGatePolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  EcGateEnabled[ CNTR_CHL_COUNT_MAX ];

   // --------------------------------------------------------
   __u32  OsClkSource[ CNTR_CHL_COUNT_MAX ];
   __u32  OsGateSource[ CNTR_CHL_COUNT_MAX ];
   __u32  OsDelayCount[ CNTR_CHL_COUNT_MAX ];
   __u32  OsClkPolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  OsGatePolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  OsOutSigType[ CNTR_CHL_COUNT_MAX ];

   // --------------------------------------------------------
   __u32  TmrDivisor[CNTR_CHL_COUNT_MAX];
   __u32  TmrGatePolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  TmrGateEnabled[ CNTR_CHL_COUNT_MAX ];
   __u32  TmrOutSigType[ CNTR_CHL_COUNT_MAX ];

   // --------------------------------------------------------

   // --------------------------------------------------------
   __u32  PiClkSource[ CNTR_CHL_COUNT_MAX ]; 

   // --------------------------------------------------------
   __u32  PoHiPeriod[ CNTR_CHL_COUNT_MAX ]; 
   __u32  PoLoPeriod[ CNTR_CHL_COUNT_MAX ]; 
   __u32  PoGatePolarity[ CNTR_CHL_COUNT_MAX ];
   __u32  PoGateEnabled[ CNTR_CHL_COUNT_MAX ];
   __u32  PoSignalType[CNTR_CHL_COUNT_MAX ];

} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     CntrCtrl;

} CNTR_STATE;

typedef struct _DEVICE_FEATURE{
   // ----------------------------------
   char  * DeviceName;
   __u32   PciBarCount;
   // ----------------------------------
   // ----------------------------------
   // ----------------------------------
   __u32   DoPortCount;
   __u32   DoFrzSpted;
   __u32   DiPortCount;
   __u32   DiIntSrcCount; 
   __u32   DiPmSrcCount;
   __u32   DiCosSrcCount;
   __u32   DiFltSrcCount;
   __u8    DiFltMask[DI_FLT_SRC_COUNT_MAX];
   // ----------------------------------
   __u32   CntrChanCount;
   __u8    CntrFltMask [CNTR_FLT_SRC_COUNT_MAX];
   // ----------------------------------
   __u32   IntSectCount;
   __u32   IntSectMask[INT_SECT_COUNT_MAX];
   __u32   IntSectMap[INT_SECT_COUNT_MAX * INT_FLAG_PER_SECT];
} DEVICE_FEATURE;

typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number

   // HW Information
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   PcbVer;         // PCB Version
   __u32   PldVer;         // Programmable Logic Device Version
   __u32   FwVer;          // Firmware version

   __u64   PhysBase[PCIBAR_COUNT];
   __u32   PhysLength[PCIBAR_COUNT];
   __u32   Irq;
   __u32   InitOnLoad;

   DEVICE_FEATURE Feature;

   // --------------------------------------------------------
   __u32   DoDataBase;
   __u32   DoCtlBase;
   __u32   DiCtlBase;
   __u32   DiDataBase;

   __u8    DioPortDir[DIO_PORT_COUNT_MAX]; 
   __u8    DiOpenState[DIO_PORT_COUNT_MAX];
   __u8    DiintTrigEdge[DI_INT_SRC_COUNT_MAX];
   __u8    DiCosEnabled[DI_COS_SRC_COUNT_MAX];
   __u8    DiPmEnabled[DI_PM_SRC_COUNT_MAX]; 
   __u8    DiPmPortValue[DI_PM_SRC_COUNT_MAX]; 
   __u8    DiFltEnabled[DI_FLT_SRC_COUNT_MAX];
   __u32   DiFltTime;   

   __u32   DoFrzEnabled;                 
   __u8    DoPortState[DIO_PORT_COUNT_MAX ];

   DI_SNAP DiSnap[DI_SNAP_SRC_COUNT_MAX];

   // --------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT_MAX];

   // ---------------------------------------------------------
   __u32   IntState[INT_SECT_COUNT_MAX];
   __u32   IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
