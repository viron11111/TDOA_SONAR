/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1720
#define DRIVER_NAME   "bio1720"
#define DEVICE_NAME   "PCI-1720"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AO_CHL_COUNT             4
#define AO_CHL_MASK             (AO_CHL_COUNT - 1)   // 0x3 for 4 channel AO.
#define AO_RES_IN_BIT            12
#define AO_DATA_SIZE             sizeof(__u16)
#define AO_DATA_MASK             0xfff

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AO default values
#define DEF_AO_GAIN             V_Neg10To10
#define DEF_AO_INIT_STATE       0


typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       InitOnLoad;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u32       AoChanState[AO_CHL_COUNT];

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
