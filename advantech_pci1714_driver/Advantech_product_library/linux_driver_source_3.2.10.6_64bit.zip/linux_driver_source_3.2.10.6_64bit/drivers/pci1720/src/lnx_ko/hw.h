/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AO
#define DR_AO_DATA_BASE   0x0

typedef union _AO_CHL_CSR{
   __u8 Value;
   __u8 CHx_Gain;
}AO_CHL_CSR;

#define DR_AO_CHCSR       0x8

#define DR_AO_SYNC_STROBE 0x9
#define DR_AO_SYNC_CTL    0xf

// device register : BID
#define DR_BID            0x14


#endif /* _KERNEL_MODULE_HW_H_ */
