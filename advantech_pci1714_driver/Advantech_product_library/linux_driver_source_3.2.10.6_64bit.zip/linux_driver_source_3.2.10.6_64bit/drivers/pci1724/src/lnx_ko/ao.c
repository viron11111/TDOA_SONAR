/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

#define AO_TO_VOUT(ch)  (((ch) >> 3) * 10 + ((ch) & 7)) // see AD5379 for detail about the map.

static
void daq_ao_write_dac(DEVICE_SHARED *shared, unsigned chan, unsigned mode, unsigned data)
{
   DAC_CTRL_REG reg;

   // wait DAC ready
   __u32 dacState;
   do {
      dacState = AdxIoInD(shared->IoBase, DR_DEV_STAT) & DAC_STAT_MASK;
   } while (dacState != DAC_STAT_READY);

   reg.DacData = data;
   reg.DacMode = mode;
   reg.Channel = chan & 0x7;
   reg.Group   = 1 << (chan >> 3);
   AdxIoOutD(shared->IoBase, DR_DAC_CTL, reg.Value);
   printk("write adc: 0x%x\n", reg.Value);
}

static
void daq_ao_config_chan(DEVICE_SHARED *shared)
{
   int i,j;

   // configure AO GROUPs
   for (i = 0; i < AO_CHL_COUNT; i += 8) {
      __u32 grp_cfg = 0;

      for (j = 0; j < 8; ++j) {
         grp_cfg |= shared->AoChanGain[i + j] << (j * 2);
      }
      eep_verify_write(shared->IoBase, EEP_USER, AO_GRP_ADDR(i / 8), grp_cfg);
   }

   // configure AO channel
   for (i = 0; i < AO_CHL_COUNT; ++i)
   {
      __u32 eep_start = AO_TO_VOUT(i) * 6 + shared->AoChanGain[i] * 2;

      // set DAC according to the selected gain.
      // SPAN / GAIN:
      __u32 data = eep_verify_read(shared->IoBase, EEP_USER, eep_start + CALI_SPAN);
      daq_ao_write_dac(shared, i, DAC_MODE_GAIN, data);

      //ZERO/OFFSET
      data = eep_verify_read(shared->IoBase, EEP_USER, eep_start + CALI_ZERO);
      daq_ao_write_dac(shared, i, DAC_MODE_OFFSET, data);
   }
}
//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   daq_ao_config_chan(shared);

   // enable synchronized output
   AdxIoOutD(shared->IoBase, DR_DAC_SYNC_CTL, DAC_SYNC_OUT);

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
    	  daq_ao_write_dac(shared, i, DAC_MODE_NORMAL, shared->AoChanState[i]);
      }

      // strobe the synchronized output
      AdxIoOutD(shared->IoBase, DR_DAC_SYNC_STROBE, 0);
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      __u32  i, ch, gains[AO_CHL_COUNT];

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
      }
      daq_ao_config_chan(shared);
   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }

   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   for(i = 0; i < xbuf.ChanCount; ++i) {
      ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
      daq_ao_write_dac(shared, ch, DAC_MODE_NORMAL, data[i]);
   }

   //Bug 16954: add a wait for last DAC output ready.
   __u32 dacState;
   do {
      dacState = AdxIoInD(shared->IoBase, DR_DEV_STAT) & DAC_STAT_MASK;
   } while (dacState != DAC_STAT_READY);

   // strobe the synchronized output
   AdxIoOutD(shared->IoBase, DR_DAC_SYNC_STROBE, 0);

   return 0;
}
