/*
 * eeprom.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

#define EEP_SDO_STAT(ioBase)    (AdxIoInD(ioBase, DR_EEP_CSR) & EEP_SDO)
#define EEP_RDY_STAT(ioBase)    (AdxIoInD(ioBase, DR_EEP_CSR) & EEP_RDY)
#define WAIT_EEP_READY(ioBase)    do{;}while(!EEP_RDY_STAT(ioBase))

void eep_cs_high (__u32 ioBase, __u32 eep_no)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data | (EEP_CS_BASE << eep_no));
	WAIT_EEP_READY(ioBase);
}

void eep_cs_low (__u32 ioBase, __u32 eep_no)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data & (~(EEP_CS_BASE << eep_no)));
	WAIT_EEP_READY(ioBase);
}

void eep_sdi_high (__u32 ioBase)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data | EEP_SDI);
	WAIT_EEP_READY(ioBase);
}

void eep_sdi_low (__u32 ioBase)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data & (~EEP_SDI));
	WAIT_EEP_READY(ioBase);
}

void eep_sclk_high (__u32 ioBase)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data | EEP_SCLK);
	WAIT_EEP_READY(ioBase);
}

void eep_sclk_low (__u32 ioBase)
{
   __u32 data = AdxIoInD(ioBase, DR_EEP_CSR);
   AdxIoOutD(ioBase, DR_EEP_CSR, data & (~EEP_SCLK));
	WAIT_EEP_READY(ioBase);
}

void eep_wr_clk (__u32 ioBase, __u32 EEP_W_Bit)
{
   // For stable writing clock
   if (EEP_W_Bit) { 
      eep_sdi_high(ioBase); 
   } else { 
      eep_sdi_low(ioBase); 
   }

   eep_sclk_low(ioBase);
   eep_sclk_low(ioBase);
   eep_sclk_low(ioBase);
   eep_sclk_high(ioBase);
   eep_sclk_high(ioBase);
   eep_sclk_high(ioBase);
}

void eep_rd_clk (__u32 ioBase)
{
   eep_sclk_low(ioBase);
   eep_sclk_high(ioBase);
}

void eep_start (__u32 ioBase, __u32 eep_no)
{
   eep_cs_low(ioBase, eep_no);  
   eep_sclk_low(ioBase);
   eep_sdi_low(ioBase);
	
   eep_cs_high(ioBase, eep_no);
   eep_sdi_high(ioBase);
   eep_sclk_high(ioBase);
}

/*********************************************************************
	93LC66 : EWEN
				   SB  OP Code  Address
					1  00       11XXXXXX
*********************************************************************/
void eep_ewen (__u32 ioBase, __u32 eep_no)
{
   int ignoreBit;
   
   eep_start(ioBase, eep_no);
   eep_wr_clk(ioBase,0);
   eep_wr_clk(ioBase,0);
   eep_wr_clk(ioBase,1);
   eep_wr_clk(ioBase,1);

   ignoreBit = EEP_IGNOREBIT;
   for (; ignoreBit > 0; ignoreBit--) { 
      eep_wr_clk(ioBase,0); 
   }

   eep_cs_low(ioBase, eep_no); 
}

/*********************************************************************
	93LC66 : EWDS
				   SB  OP Code  Address
					1  00       00XXXXXX
*********************************************************************/
void eep_ewds (__u32 ioBase, __u32 eep_no)
{
   int ignoreBit;

   eep_start(ioBase, eep_no); 
   eep_wr_clk(ioBase,0);
   eep_wr_clk(ioBase,0);
   eep_wr_clk(ioBase,0);
   eep_wr_clk(ioBase,0);

   ignoreBit = EEP_IGNOREBIT;
   for (; ignoreBit > 0; ignoreBit--) { 
      eep_wr_clk(ioBase,0); 
   }

   eep_cs_low(ioBase, eep_no); 
}

/*********************************************************************
	93LC66 : READ
				   SB  OP Code  Address      Data
					1  10       8-Bit        16-Bit
*********************************************************************/
__u32 eep_read (__u32 ioBase, __u32 eep_no, __u32 eep_addr)
{
   __u32 eep_code   = (eep_addr & 0xff) | EEP_OP_READ;
   __u32 bit_cursor = 1 << (EEP_OPCODEBIT + EEP_ADDRBIT - 1);
   
   eep_start(ioBase, eep_no);

   // Send 93LC66 command, from MSB to LSB.
   for (; bit_cursor; bit_cursor >>= 1) {
      eep_sclk_low(ioBase);
      if (eep_code & bit_cursor) {	
         eep_sdi_high(ioBase);	
      } else { 
         eep_sdi_low(ioBase); 
      }
      eep_sclk_high(ioBase);
   }

   // Receive data
   eep_code = 0;
   for (bit_cursor = 1 << (EEP_DATABITNO - 1); bit_cursor ; bit_cursor >>= 1) {
      eep_rd_clk(ioBase);
      if (EEP_SDO_STAT(ioBase)) { 
         eep_code |= bit_cursor; 
      }
   }

   eep_cs_low(ioBase, eep_no); 
   return(eep_code);
}

__u32 eep_verify_read(__u32 ioBase, __u32 eep_no, __u32 eep_addr)
{
   __u32 data;
   int i;
   
   for (i = 0; i < 600; ++i){
      data = eep_read(ioBase, eep_no, eep_addr);
      if (data == eep_read(ioBase, eep_no, eep_addr)) {
         break;
      }
   }   
   return data;
}

/*********************************************************************
	93LC66 : WRITE
				   SB  OP Code  Address      Data
					1  01       8-Bit        16-Bit
*********************************************************************/
void eep_write (__u32 ioBase, __u32 eep_no, __u32 eep_addr, __u32 eep_data)
{
   __u32 bit_cursor = 1 << (EEP_OPCODEBIT + EEP_ADDRBIT - 1);
   __u32 eep_code   = (eep_addr & 0xff) | EEP_OP_WRITE;

   eep_ewen(ioBase, eep_no);
   eep_start(ioBase, eep_no); 

   /* Write OP Code And EEP Address, MSB --> LSB */
   for (; bit_cursor; bit_cursor >>= 1) {
      if (eep_code & bit_cursor) {	
         eep_sdi_high(ioBase);	
      } else { 
         eep_sdi_low(ioBase); 
      }

      eep_sclk_low(ioBase);
      eep_sclk_low(ioBase);
      eep_sclk_low(ioBase);
      eep_sclk_high(ioBase);
      eep_sclk_high(ioBase);
      eep_sclk_high(ioBase);      
   }

   /* Write EEP_DATA */
   for (bit_cursor = 1 << (EEP_DATABITNO - 1); bit_cursor ; bit_cursor >>= 1) {
      if (eep_data & bit_cursor) {	
         eep_sdi_high(ioBase);	
      } else { 
         eep_sdi_low(ioBase); 
      }
      
      eep_sclk_low(ioBase);
      eep_sclk_low(ioBase);
      eep_sclk_low(ioBase);
      eep_sclk_high(ioBase);
      eep_sclk_high(ioBase);
      eep_sclk_high(ioBase);        
   }

   eep_cs_low(ioBase, eep_no);
   eep_rd_clk(ioBase);     
   eep_cs_high(ioBase, eep_no); 

   eep_rd_clk(ioBase);        
   eep_rd_clk(ioBase);        
   eep_rd_clk(ioBase);        
   eep_rd_clk(ioBase);        
   while (!EEP_SDO_STAT(ioBase));

   eep_ewds(ioBase, eep_no);
   eep_sclk_low(ioBase);

   eep_cs_low(ioBase, eep_no);	
   eep_sdi_low(ioBase);
}

void eep_verify_write (__u32 ioBase, __u32 eep_no, __u32 eep_addr, __u32 eep_data)
{
   do {
      eep_write(ioBase, eep_no, eep_addr, eep_data);
   } while (eep_data != eep_verify_read(ioBase, eep_no, eep_addr));
}
