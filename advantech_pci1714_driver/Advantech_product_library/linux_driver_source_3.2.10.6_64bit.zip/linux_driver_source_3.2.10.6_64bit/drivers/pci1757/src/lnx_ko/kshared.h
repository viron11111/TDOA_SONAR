/*
 * kshared.h
 *
 *  Created on: July 7, 2012 
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1757
#define DEVICE_PID    BD_PCI1757
#define DEVICE_NAME   "PCI-1757"
#define DRIVER_NAME   "bio1757"


// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORTS_COUNT		   3
#define DIO_CHL_COUNT         (DIO_PORTS_COUNT * 8)

#define DI_INT_SRC_COUNT      1  
#define DI_SNAP_SRC_MAX       DI_INT_SRC_COUNT

enum KRNL_EVENT_IDX
{
   // Device event
   EvtDevPropChgedIdx = 0,
   
   // DIO event
   EvtDiIdxBegin,
   EvtDiintChan016Idx = EvtDiIdxBegin,
   EvtDiIdxEnd        = EvtDiintChan016Idx,

   KrnlSptedEventCount
};

static inline __u32 UserDioEvtType2KrnlIdx(__u32 eventType )
{
   switch ( eventType )
   {
   case EvtDiintChannel016:    
      return EvtDiintChan016Idx;     
   }
   return -1; // not supported user event type
}

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   if ( eventType == EvtPropertyChanged )
   {
      return EvtDevPropChgedIdx;
   }
   kdx = UserDioEvtType2KrnlIdx( eventType );
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DIO_DIR             0x00
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge
#define DEF_DIINT_GATE          0


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG
{
   __u8 portStart;
   __u8 portCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE
{
   __u8 state[DIO_PORTS_COUNT];
} DI_SNAP_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       EpBase;         // Base address of EEPROM's registers
   __u32       EpLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u32       DioPortDirConfigByHw;  // When DIO ports' direction can be set by software, the flag is 0; otherwise, it is 1
   __u8        DioPortDir[DIO_PORTS_COUNT]; 
   __u8        DoPortState[DIO_PORTS_COUNT];
   __u8        DiintTrigEdge[DI_INT_SRC_COUNT];
   __u8        DiintGateCtrl[DI_INT_SRC_COUNT];

   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_MAX];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_MAX];

   // ---------------------------------------------------------
   __u32       IntCsr;
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
