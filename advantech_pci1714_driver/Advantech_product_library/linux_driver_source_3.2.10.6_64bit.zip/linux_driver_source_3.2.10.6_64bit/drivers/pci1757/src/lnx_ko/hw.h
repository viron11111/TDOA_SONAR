/*
 * hw.h
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_


// device register : Port x data
#define DR_PortX( x )    (x)  // x:[0,2] 

#define DR_BID          0x24 // 

// DIO port group configuration register
#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _DIR_CTRL_REG{
   __u8 Value;
   struct{
      __u8 PCLowDir :             1;  // Port C lower nibble
      __u8 PBDir    :             1;  // Port B
      __u8 Reserved1:             1;
      __u8 PCHighDir:             1;  // Port C higher nibble
      __u8 PADir    :             1;  // Port A
      __u8 Reserved2:             2;
      __u8 DioPortDirConfigByHw:  1;  // 
	};
}DIR_CTRL_REG;

#define DR_Dir_Ctrl     3

// interrupt control & status register
#define INT_DISABLED          0
#define INT_SRC_PC0           1
#define INT_SRC_PC0_WITH_GATE 2
#define TRIG_EDGE_RISING      1  // rising edge. note: this is the device specified value.
#define TRIG_EDGE_FALLING     0  // falling edge. note: this is the device specified value.
typedef union _DEV_INT_CSR{
   __u8 Value;
   struct{
      __u8 IntMode : 2;   // Group interrupt mode. see INT_xxx definition.
      __u8 IntEdge : 1;   // Group interrupt trigger edge. see TRIG_EDGE_xxx definition.
      __u8 IntFlag : 1;   // Group 0 interrupt status
                          // when read: 1 -- interrupt occurred; 0 -- no interrupt
                          // when write: 1 -- clear interrupt; 0 -- don't care
      __u8 Reserved: 4;
   };
}DEV_INT_CSR;

#define DEV_INT_MASK  0x08  // for fast detect the interrupt status
#define DR_IntCSR     0x20

#endif /* _KERNEL_MODULE_HW_H_ */
