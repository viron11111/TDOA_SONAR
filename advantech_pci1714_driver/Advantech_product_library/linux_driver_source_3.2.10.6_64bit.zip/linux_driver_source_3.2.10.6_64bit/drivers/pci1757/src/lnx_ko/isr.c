/*
 * isr.c
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

__u8 * IsrSnapDiPorts( uint32 ioBase, __u8 buffer[ DIO_PORTS_COUNT ] )
{
   uint32 i;
   __u8 * ptr = buffer;
   //printk("portStart=%d portCount=%d\n",snapPara.portStart, snapPara.portCount);
   for ( i = 0; i < DIO_PORTS_COUNT; ++i, ++ptr )
   {
      *ptr = AdxIoInB(ioBase, DR_PortX(i));
      printk("port[%d]=%x\n", i, *ptr);
   }
   return buffer;
}

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   unsigned long flags;
   __u32         int_state;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   int_state = shared->IntCsr;
   shared->IntCsr = 0;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   if (shared->DiSnapParam[0].portCount)
   {
      IsrSnapDiPorts(shared->IoBase, shared->DiSnapState[0].state);
   }

   // signal the event if needed.
   if (!shared->IsEvtSignaled[EvtDiintChan016Idx]) {
      shared->IsEvtSignaled[EvtDiintChan016Idx] = 1;
      daq_device_signal_event(daq_dev, EvtDiintChan016Idx);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u8 int_states = AdxIoInB(shared->IoBase, DR_IntCSR);
   if (!int_states) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   shared->IntCsr |= int_states;
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->dio_tasklet);

   AdxIoOutB(shared->IoBase, DR_IntCSR, int_states);

   return IRQ_RETVAL(1);
}

