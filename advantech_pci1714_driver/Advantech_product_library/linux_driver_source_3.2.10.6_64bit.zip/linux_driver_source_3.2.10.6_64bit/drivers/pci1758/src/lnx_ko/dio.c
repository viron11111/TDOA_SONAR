/*
 * dio.c
 *
 *  Created on: 2011-9-15
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

static
void daq_diflt_set_blk_time(DEVICE_SHARED *shared)
{
   DREG_TABLE *table = GetDeviceRegTable(shared->ProductId);
   if (likely(table->DI_FLT_INTERVAL != -1)) {
      AdxIoOutD(shared->IoBase, table->DI_FLT_INTERVAL, shared->DiFilterTime);
   }
}

static
void daq_diflt_enable(DEVICE_SHARED *shared)
{
   DREG_TABLE *table = GetDeviceRegTable(shared->ProductId);
   if (likely(table->DI_FLT_CTL_BASE != -1)) {
      int max_count = DI_PORT_COUNT(shared->ProductId);
      int i;
      for (i = 0; i < max_count; i += 4) {
         AdxIoOutD(shared->IoBase, table->DI_FLT_CTL_BASE + i, *(__u32 *)&shared->DiFilterEn[i]);
      }
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DREG_TABLE    *table  = GetDeviceRegTable(shared->ProductId);

   if (shared->InitOnLoad) {
      if (shared->ProductId != BD_PCI1758UDI) {
         int count = DIO_PORT_COUNT(shared->ProductId);
         int i;
         for (i = 0; i < count; i += 4) {
            AdxIoOutD(shared->IoBase, table->DO_BASE + i, *(__u32*)&shared->DoPortState[i]);
         }
      }
   }
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DREG_TABLE    *table;
   DIO_RW_PORTS  xbuf;
   __u8          data_buf[MAX_DIO_PORT_COUNT];
   __u32         *curr_data;
   int           rest_count;
   unsigned      curr_port, max_count = DI_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   table = GetDeviceRegTable(shared->ProductId);

   xbuf.PortStart %= max_count;
   xbuf.PortCount  = min(max_count, xbuf.PortCount);

   curr_data  = (__u32 *)data_buf;
   curr_port  = xbuf.PortStart & ~0x3;
   rest_count = (int)min(xbuf.PortCount + (xbuf.PortStart & 3), max_count);
   while (rest_count > 0) {
      *curr_data++ = AdxIoInD(shared->IoBase, table->DI_BASE + curr_port);
      curr_port    = (curr_port + 4) % max_count;
      rest_count  -= 4;
   }

   if (unlikely(copy_to_user(xbuf.Data, data_buf + (xbuf.PortStart & 3), xbuf.PortCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DREG_TABLE    *table;
   DIO_RW_PORTS  xbuf;
   __u8          data_buf[MAX_DIO_PORT_COUNT]; 
   __u32         *curr_data;
   int           rest_count;
   unsigned      curr_port, max_count = DO_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   table = GetDeviceRegTable(shared->ProductId);

   xbuf.PortStart %= max_count;
   xbuf.PortCount  = min(max_count, xbuf.PortCount);

   curr_data  = (__u32 *)data_buf;
   curr_port  = xbuf.PortStart & ~0x3;
   rest_count = (int)min(xbuf.PortCount + (xbuf.PortStart & 3), max_count);
   
   if (xbuf.PortStart & 0x3) {
      *curr_data  = AdxIoInD(shared->IoBase, table->DO_BASE + curr_port);
   }
   if (rest_count & 0x3) {
      __u32 last_port = ((curr_port + rest_count) & ~0x3) % max_count;
      curr_data[rest_count / 4] = AdxIoInD(shared->IoBase, table->DO_BASE + last_port);
   }

   if (unlikely(copy_from_user(data_buf + (xbuf.PortStart & 0x3), (void *)xbuf.Data, xbuf.PortCount))) {
      return -EFAULT;
   }

   // Output aligned part.
   while (rest_count > 0) {
      AdxIoOutD(daq_dev->shared.IoBase, table->DO_BASE + curr_port, *curr_data++);
      curr_port   = (curr_port + 4) % max_count;
      rest_count -= 4;
   }

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DREG_TABLE    *table;
   DIO_RW_BIT    xbuf;
   __u8          data;
   unsigned      max_count = DO_PORT_COUNT(shared->ProductId);
   unsigned long flags;

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }
   if (xbuf.Port >= max_count) {
	  return -EINVAL;
   }
 
   table = GetDeviceRegTable(shared->ProductId);

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   data = AdxIoInB(shared->IoBase, table->DO_BASE + xbuf.Port);
   data = ((xbuf.Data & 0x1) << xbuf.Bit) | (~(1 << xbuf.Bit) & data);
   AdxIoOutB(daq_dev->shared.IoBase, table->DO_BASE + xbuf.Port, data);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
   
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DREG_TABLE    *table;
   DIO_RW_PORTS  xbuf;
   __u8          data_buf[MAX_DIO_PORT_COUNT];
   __u32         *curr_data;
   int           rest_count;
   unsigned      curr_port, max_count = DO_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   table = GetDeviceRegTable(shared->ProductId);

   xbuf.PortStart %= max_count;
   xbuf.PortCount  = min(max_count, xbuf.PortCount);

   curr_data  = (__u32 *)data_buf;
   curr_port  = xbuf.PortStart & ~0x3;
   rest_count = (int)min(xbuf.PortCount + (xbuf.PortStart & 3), max_count);
   while (rest_count > 0) {
      *curr_data++ = AdxIoInD(shared->IoBase, table->DO_BASE + curr_port);
      curr_port    = (curr_port + 4) % max_count;
      rest_count  -= 4;
   }

   if (unlikely(copy_to_user(xbuf.Data, data_buf + (xbuf.PortStart & 3), xbuf.PortCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest;
   unsigned          max_count = DI_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > max_count) {
      return -EINVAL;
   }

   if (xbuf.SetWhich == DIINT_SET_RISING_EDGE) {
      dest = (__u8 *)shared->DiRisingEdgeEn;
   } else {
      dest = (__u8 *)shared->DiFallingEdgeEn;
   }
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.Buffer, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_START_DI_SNAP xbuf;
   unsigned          event_kdx, src_idx;
   unsigned          max_count = DI_SNAP_SRC_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   event_kdx = GetEventKIndex(shared->ProductId, xbuf.EventId);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= max_count) {
      return -EINVAL;
   }

   daq_device_clear_event(daq_dev, event_kdx);
   daq_dev->shared.IsEvtSignaled[event_kdx / 32] &= ~(1 << (event_kdx & 31));
   daq_dev->shared.DiSnapParam[src_idx].PortStart = (__u8)xbuf.PortStart;
   daq_dev->shared.DiSnapParam[src_idx].PortCount = (__u8)xbuf.PortCount;

   {
      // enable the DI interrupt of the channel
      __u16      ctl_val;
      unsigned   group  = src_idx / 16;
      unsigned   offset = src_idx % 16;
      unsigned   mask   = 1 << offset;
      DREG_TABLE *table = GetDeviceRegTable(shared->ProductId);

      // rising edge setting
      ctl_val  = AdxIoInW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4) & ~mask;
      ctl_val |= shared->DiRisingEdgeEn[group] & mask;
      AdxIoOutW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4, ctl_val);

      // falling edge setting
      ctl_val  = AdxIoInW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4 + 2) & ~mask;
      ctl_val |= shared->DiFallingEdgeEn[group] & mask;
      AdxIoOutW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4 + 2, ctl_val);
   }

   return 0;
}

int daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned      event_kdx, src_idx;
   unsigned      max_count = DI_SNAP_SRC_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   event_kdx = GetEventKIndex(shared->ProductId, (__u32)arg);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= max_count) {
      return -EINVAL;
   }

   {
      // enable the DI interrupt of the channel
      __u16      ctl_val;
      unsigned   group  = src_idx / 16;
      unsigned   offset = src_idx % 16;
      unsigned   mask   = 1 << offset;
      DREG_TABLE *table = GetDeviceRegTable(shared->ProductId);

      ctl_val = AdxIoInW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4) & ~mask;
      AdxIoOutW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4, ctl_val);

      ctl_val = AdxIoInW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4 + 2) & ~mask;
      AdxIoOutW(shared->IoBase, table->DI_INT_CTL_BASE + group * 4 + 2, ctl_val);
   }

   return 0;
}

int daq_ioctl_diflt_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIFLT_CFG xbuf;
   unsigned          max_count = DI_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SetWhich & DIFLT_SET_BLKINTVL) {
      shared->DiFilterTime = xbuf.BlkTime;
      daq_diflt_set_blk_time(shared);
   }

   if (xbuf.SetWhich & DIFLT_SET_CHENBED) {
      __u8 *dest = (__u8 *)shared->DiFilterEn + xbuf.SrcStart;

      if (unlikely(xbuf.SrcStart + xbuf.SrcCount > max_count)) {
         return -EINVAL;
      }

      if (unlikely(copy_from_user(dest, xbuf.ChanEnabled, xbuf.SrcCount))) {
         return -EFAULT;
      }

      daq_diflt_enable(shared);
   }

   return 0;
}

int daq_ioctl_dowdt_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_WDT_CFG xbuf;
   unsigned          max_count = DO_PORT_COUNT(shared->ProductId);

   if (!max_count) {
      return -ENOTTY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SetWhich & WDT_SET_INTERVAL) {
      shared->WdtInterval = xbuf.Interval;
   }

   if (xbuf.SetWhich & WDT_SET_LOCKVALUE) {
      __u8 *dest = (__u8 *)shared->WdtLockValue + xbuf.SrcStart;

      if (unlikely(xbuf.SrcStart + xbuf.SrcCount > max_count)) {
         return -EINVAL;
      }

      if (unlikely(copy_from_user(dest, xbuf.LockValue, xbuf.SrcCount))) {
         return -EFAULT;
      }
   }

   return 0;
}

