/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

typedef struct _DREG_TABLE{
   int DI_BASE;
   int DO_BASE;
   int DI_INT_CTL_BASE;
   int DI_INT_STA_BASE;
   int DI_INT_IDENTIFY;
   int DI_FLT_CTL_BASE;
   int DI_FLT_INTERVAL;
   int WDT_INTERVAL;
   int WDT_CTL_STA;
   int WDT_RESET;
   int EEP_CTL_DO;
   int BOARD_ID;
} DREG_TABLE;

#define WDT_EN      0x1
#define WDT_INT_EN  0x2
#define WDT_TIMEOUT 0x4

static inline
DREG_TABLE * GetDeviceRegTable(__u32 pid)
{
   static
   DREG_TABLE udi_table = {
      0x00, /* DI base */
      -1,   /* DO base */
      0x10, /* DI INT control */
      0x30, /* DI INT state */
      0x50, /* DI INT port identify*/
      0x40, /* DI Filter control */
      0x52, /* DI filter interval */
      -1,   /* Watchdog interval */
      -1,   /* Watchdog control/status */
      -1,   /* Watchdog reset */
      -1,   /* EEPROM control/data */
      0x56, /* board id */
   };

   static
   DREG_TABLE udo_table = {
      -1,   /* DI base */
      0x00, /* DO base */
      -1,   /* DI INT control */
      -1,   /* DI INT state */
      -1,   /* DI INT port identify*/
      -1,   /* DI Filter control */
      -1,   /* DI filter interval */
      0x10, /* Watchdog interval */
      0x14, /* Watchdog control/status */
      0x16, /* Watchdog reset */
      0x1A, /* EEPROM control/data */
      0x1C, /* board id */
   };

   static
   DREG_TABLE udio_table = {
      0x00, /* DI base */
      0x08, /* DO base */
      0x10, /* DI INT control */
      0x20, /* DI INT state */
      0x40, /* DI INT port identify*/
      0x28, /* DI Filter control */
      0x30, /* DI filter interval */
      0x34, /* Watchdog interval */
      0x38, /* Watchdog control/status */
      0x3A, /* Watchdog reset */
      0x3C, /* EEPROM control/data */
      0x3E, /* board id */
   };

   if (pid == BD_PCI1758UDI){
      return &udi_table;
   }
   if (pid == BD_PCI1758UDO){
      return &udo_table;
   }
   return &udio_table;
}

#endif /* _KERNEL_MODULE_HW_H_ */
