/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DR_DO_BASE         0
#define DR_DO_PORTX(x)     (DR_DO_BASE + x)

#define DR_BID             0x4

#endif /* _KERNEL_MODULE_HW_H_ */
