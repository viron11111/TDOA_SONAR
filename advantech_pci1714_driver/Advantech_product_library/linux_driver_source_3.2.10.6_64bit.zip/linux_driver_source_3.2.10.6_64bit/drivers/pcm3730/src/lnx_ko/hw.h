/*
 * hw.h
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DR_DIO_BASE       0x0
#define DR_DIO_PORTX(x)    ( x? x+1 : 0 )

#endif /* _KERNEL_MODULE_HW_H_ */
