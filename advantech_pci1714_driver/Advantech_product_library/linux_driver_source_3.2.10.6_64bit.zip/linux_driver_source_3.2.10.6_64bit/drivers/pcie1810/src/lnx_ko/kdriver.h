/*
 * kdriver.h
 *
 *  Created on: 2015-06-10
 *      Author: 
 */

#ifndef _KERNEL_MODULE_H_
#define _KERNEL_MODULE_H_

#ifndef CONFIG_PCI
#  error "This driver needs to have PCI support."
#endif

#include <linux/pci.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/io.h>
#include <linux/workqueue.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <linux/delay.h>

#include <bdaqdef.h>
#include <ioctls.h>
#include <biokernbase.h>
#include <plx905x.h>
#include <i82c54.h>
#include "kshared.h"
#include "hw.h"

#define CVREGS  ((CARD_VER_R *)(daq_dev)->iomem_base[0])
#define IOREGS  ((IO_FUNC_R *)(daq_dev)->iomem_base[1])

typedef struct daq_file_ctx{
   struct list_head   ctx_list;
   struct daq_device  *daq_dev;
   HANDLE             events[KrnlSptedEventCount];
   int                write_access;
   int                busy;
} daq_file_ctx_t;


typedef struct daq_device
{
   DEVICE_SHARED         shared;
   struct pci_dev       *pdev;
   struct cdev           cdev;
   unsigned char        *iomem_base[PCIBAR_COUNT];       

   spinlock_t            dev_lock;
   struct tasklet_struct dev_tasklet;
   int                   remove_pending;
   struct list_head      file_ctx_list;
   int                   file_ctx_pool_size;
   daq_file_ctx_t        *file_ctx_pool;
   
   spinlock_t            fai_lock;
   wait_queue_head_t     fai_queue;
   daq_umem_t            fai_buffer;
   daq_dmem_t            fai_dma_buf;

   spinlock_t            fao_lock;
   wait_queue_head_t     fao_queue;
   struct delayed_work   fao_fifo_chk_work;
   daq_umem_t            fao_buffer;
   int                   fao_stop_asap;

   spinlock_t            cntr_lock;

   DEV_IF0_R             dev_if0;
   DEV_IF1_R             dev_if1;

} daq_device_t;

/************************************************************************/
/* Functions                                                            */
/************************************************************************/
//
// init.c
//
void daq_device_cleanup(daq_device_t * daq_dev);

//
// fops.c
//
int  daq_file_open(struct inode *in, struct file *fp);
int  daq_file_close(struct inode *inode, struct file *filp);
int  daq_file_mmap(struct file *filp, struct vm_area_struct *vma);
long daq_file_ioctl(struct file *filp, unsigned int cmd, unsigned long arg);
int  daq_device_signal_event(daq_device_t *daq_dev, unsigned index);
int  daq_device_clear_event(daq_device_t *daq_dev, unsigned index);
int  daq_device_is_event_active(daq_device_t *daq_dev, unsigned kdx);

//
// ai.c
//
void daq_ai_initialize_hw(daq_device_t *daq_dev);
void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup);
int  daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg);

//
// ao.c
//
void daq_ao_initialize_hw(daq_device_t *daq_dev);
void daq_fao_fifo_check_work_func(struct work_struct *work);
void daq_fao_stop_acquisition(daq_device_t *daq_dev, int cleanup);
int  daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fao_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fao_set_buffer(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fao_start(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_fao_stop(daq_device_t *daq_dev, unsigned long arg);
//
// dio.c
//
void daq_dio_initialize_hw(daq_device_t *daq_dev);
int  daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_diflt_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_dicos_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_dipm_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg);

//
// counter.c
//
void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count);
int  daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg);
int  daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg);

//
// isr.c
//
irqreturn_t daq_irq_handler(int irq, void *dev_id);
void daq_device_tasklet_func(unsigned long arg);

#endif /* _KERNEL_MODULE_H_ */
