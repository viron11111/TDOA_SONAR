/*
 * isr.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
__u32 daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   __u32 buf_state = 0;
   if (st->WritePos + inc_count >= st->BufLength)   {
      buf_state |= DAQ_IN_DATAREADY;

      st->WritePos += inc_count;
      st->WritePos %= st->BufLength;
      st->WPRunBack++;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         buf_state |= DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      int ovrnCount  = (int)(st->WritePos - st->ReadPos);

      buf_state |= DAQ_IN_BUF_FULL;

      if (st->WPRunBack > 1 || ovrnCount > 0) {

         buf_state |= DAQ_IN_BUF_OVERRUN;

         if (st->WPRunBack > 1) { 
            ovrnCount = st->BufLength;
         }
         st->OvrnCount = ovrnCount;
         st->OvrnOffset = st->ReadPos;
      } 
   }

   return buf_state;
}

static inline
__u32 daq_fai_copy_data_from_fifo(daq_device_t *daq_dev, __u32 count, __u32 userWP, __u32 *rbufRP)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   __u32         *usrBuf = (__u32*)daq_dev->fai_buffer.kaddr;
   __u32         *dmaBuf = (__u32*)daq_dev->fai_dma_buf.kaddr;
   __u32         copied;

   while (count) {
      copied = count;
      if (userWP + copied > faiStatus->BufLength || *rbufRP + copied > AI_FIFO_XSIZE) {
         copied = __min(faiStatus->BufLength - userWP, AI_FIFO_XSIZE - *rbufRP);
      }

      memcpy(&usrBuf[userWP], &dmaBuf[*rbufRP], copied * AI_DATA_SIZE);
      count   -= copied;
      userWP   = (userWP + copied) % faiStatus->BufLength;
      *rbufRP  = (*rbufRP + copied) % AI_FIFO_XSIZE; 
   }

   return 0;
}

static inline
__u32 daq_fao_update_status(FAO_CONFIG *cfg, FAO_STATUS *st, unsigned inc_count)
{
   __u32 buf_state = 0;
   if (st->ReadPos + inc_count >= st->BufLength) {
      buf_state  |=  DAQ_OUT_TRANSMITTED;

      st->ReadPos   += inc_count;
      st->ReadPos   %= cfg->SampleCount;
      st->WPRunBack  = 0;
   } else {
      if ((st->ReadPos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         buf_state |= DAQ_OUT_TRANSMITTED;
      }
      st->ReadPos += inc_count;
   }

   // check underrun
   if (st->ReadPos > st->WritePos && !st->WPRunBack) {
      buf_state |= DAQ_OUT_BUF_UNDERRUN;
   }
   return buf_state;
}

static inline
void daq_fao_copy_data_to_fifo(daq_device_t *daq_dev, __u32 count, __u32 userRP, __u32 *rbufWP)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_STATUS *faoStatus = &shared->FaoStatus;
   __u32         *usrBuf = (__u32*)daq_dev->fao_buffer.kaddr;
   __u32         *devBuf = (__u32*)(daq_dev->iomem_base[2] + 0x4000);

   __u32 copied;

   while (count) {
      copied = count;
      if (userRP + copied > faoStatus->BufLength || *rbufWP + copied > AO_FIFO_XSIZE) {
         copied = __min(faoStatus->BufLength - userRP, AO_FIFO_XSIZE - *rbufWP);
      }
      
      memcpy(&devBuf[*rbufWP], &usrBuf[userRP], copied * AO_DATA_SIZE);
      count   -= copied;
      userRP   = (userRP + copied) % faoStatus->BufLength; 
      *rbufWP  = (*rbufWP + copied) % AO_FIFO_XSIZE; 
   }
}

void daq_device_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   
   DEV_IF0_R dev_if0;
   DEV_IF1_R dev_if1;
   __u32     ai_buf_sta, ao_buf_sta, di_xif;

   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   dev_if0.xval          = daq_dev->dev_if0.xval;
   dev_if1.xval          = daq_dev->dev_if1.xval;
   daq_dev->dev_if0.xval = 0;
   daq_dev->dev_if1.xval = 0;

   ai_buf_sta            = faiStatus->BufState;
   ao_buf_sta            = faoStatus->BufState;
   faiStatus->BufState   = 0;
   faoStatus->BufState   = 0;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   di_xif = (dev_if0.xval & DI_P0P1_INT_MASK) >> 16;
   di_xif = (di_xif & 0x7) | ((di_xif & 0x70) >> 1) | ((dev_if1.xval & 0x7) << 6);

   if (dev_if0.xval & AI_INT_MASK) {

      if ((ai_buf_sta & DAQ_IN_CACHE_OVERFLOW) 
         && !shared->IsEvtSignaled[KdxAiCacheOverflow]) {
         shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
         daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
      }

      if ((ai_buf_sta & DAQ_IN_BUF_OVERRUN) 
         && !shared->IsEvtSignaled[KdxAiOverrun]) {
         shared->IsEvtSignaled[KdxAiOverrun] = 1;
         daq_device_signal_event(daq_dev, KdxAiOverrun);
      }

      if ((ai_buf_sta & DAQ_IN_DATAREADY) 
         && !shared->IsEvtSignaled[KdxAiDataReady]) {
         shared->IsEvtSignaled[KdxAiDataReady] = 1;
         daq_device_signal_event(daq_dev, KdxAiDataReady);
      }

      if (dev_if0.AI_CF) {
         daq_fai_stop_acquisition(daq_dev, 0);
      }

      if ((ai_buf_sta & DAQ_IN_BUF_FULL) 
         && faiStatus->AcqMode != DAQ_ACQ_INFINITE) {
         daq_fai_stop_acquisition(daq_dev, 0);
      }
   }

   if (dev_if0.xval & AO_INT_MASK) {
      if (ao_buf_sta & DAQ_OUT_CACHE_EMPTY) {
         if (faoStatus->AcqMode != DAQ_ACQ_INFINITE || daq_dev->fao_stop_asap) {
            daq_fao_stop_acquisition(daq_dev, 0);
         } else if (!shared->IsEvtSignaled[KdxAoCacheEmptied]) {
            shared->IsEvtSignaled[KdxAoCacheEmptied] = 1;
            daq_device_signal_event(daq_dev, KdxAoCacheEmptied);
         }
      }

      if (ao_buf_sta & DAQ_OUT_BUF_UNDERRUN) {
         if (daq_dev->fao_stop_asap) {
            faoStatus->DataLeft = 0;
            schedule_delayed_work(&daq_dev->fao_fifo_chk_work, 1 /*jiffy*/);
         } else if (!shared->IsEvtSignaled[KdxAoUnderrun]) {
            shared->IsEvtSignaled[KdxAoUnderrun] = 1;
            daq_device_signal_event(daq_dev, KdxAoUnderrun);
         }
      } 

      if ((ao_buf_sta & DAQ_OUT_TRANSMITTED) 
         && !shared->IsEvtSignaled[KdxAoDataTransed]) {
         shared->IsEvtSignaled[KdxAoDataTransed] = 1;
         daq_device_signal_event(daq_dev, KdxAoDataTransed);
      }
   }

   if (di_xif) {
      int i;

      for (i = 0; di_xif; ++i, di_xif >>= 1) {
         if (!(di_xif & 0x1)) { continue; }

         *(__u32*)&shared->DiSnapState[i].State[0] = *(__u32*)&IOREGS->DIO_DAT[0];
         if (!shared->IsEvtSignaled[KdxDiBegin + i]) {
            shared->IsEvtSignaled[KdxDiBegin + i] = 1;
            daq_device_signal_event(daq_dev, KdxDiBegin + i);
         }
      }
   } 

   if (dev_if0.xval & CT_INT_MASK) {      
      __u32 ct_xif = (dev_if0.xval & CT_INT_MASK) >> 24;
      int   ch;

      for (ch = 0; ct_xif; ++ch, ct_xif >>= 4) {
         if (!(ct_xif & 0x1)) { continue; }
         
         if ((shared->CntrState[ch].Operation & CNTR_OP_ONESHOT)
            && !shared->IsEvtSignaled[KdxCntOneShot0 + ch]) {
            shared->IsEvtSignaled[KdxCntOneShot0 + ch] = 1;
            daq_device_signal_event(daq_dev, KdxCntOneShot0 + ch);
         }
         
         if ((shared->CntrState[ch].Operation & CNTR_OP_TIMERPULSE)
            && !shared->IsEvtSignaled[KdxCntTimer0 + ch]) {
            shared->IsEvtSignaled[KdxCntTimer0 + ch] = 1;
            daq_device_signal_event(daq_dev, KdxCntTimer0 + ch);
         }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev   = (daq_device_t *)dev_id;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;

   DEV_IF0_R dev_if0;
   DEV_IF1_R dev_if1;
   __u32     ai_buf_sta = 0, ao_buf_sta = 0;

   unsigned long flags;

   dev_if0.xval         = IOREGS->DEV_IF0.xval;
   IOREGS->DEV_IF0.xval = dev_if0.xval;

   dev_if1.xval         = IOREGS->DEV_IF1.xval;
   IOREGS->DEV_IF1.xval = dev_if1.xval;

   if (!dev_if0.xval && !dev_if1.xval) {
      return IRQ_RETVAL(0);
   }

   if ((dev_if0.xval & AI_INT_MASK) && faiStatus->FnState == DAQ_FN_RUNNING) {
      __u32 rbufWP = IOREGS->AI_WP & AI_FIFO_MASK;
      __u32 rbufRP = shared->AiRBufStatus.RPValue;
      __u32 count  = (rbufWP >= rbufRP) ? (rbufWP - rbufRP) : (rbufWP + AI_FIFO_XSIZE - rbufRP);

      if (faiStatus->AcqMode != DAQ_ACQ_INFINITE) {
         count = __min(count, faiStatus->BufLength - faiStatus->WritePos);
      }

      ai_buf_sta = daq_fai_copy_data_from_fifo(daq_dev, count, faiStatus->WritePos, &rbufRP);
      shared->AiRBufStatus.RPValue = rbufRP;
      shared->AiRBufStatus.WPValue = rbufWP;

      ai_buf_sta |= daq_fai_update_status(&shared->FaiParam, &shared->FaiStatus, count);
      if (dev_if0.AI_OF) {
         ai_buf_sta |= DAQ_IN_CACHE_OVERFLOW;
      }
   }

   if ((dev_if0.xval & AO_INT_MASK) && faoStatus->FnState == DAQ_FN_RUNNING) {
      __u32 rbufRP = IOREGS->AO_RP;
      __u32 rbufWP = shared->AoRBufStatus.WPValue;
      __u32 count  = rbufWP > rbufRP ? rbufRP + AO_FIFO_XSIZE - rbufWP : rbufRP - rbufWP; 

      ao_buf_sta = dev_if0.AO_BE ? DAQ_OUT_CACHE_EMPTY : 0;

      if (faoStatus->DataLeft) {
         if (faoStatus->AcqMode != DAQ_ACQ_INFINITE) {
            __u32 rest;
            if (faoStatus->WritePos > faoStatus->ReadPos) {
               rest = faoStatus->WritePos - faoStatus->ReadPos;
            } else {
               rest = faoStatus->WritePos + faoStatus->BufLength - faoStatus->ReadPos;
            }
            count = rest > count ? count : rest; 
            faoStatus->DataLeft -= count;
         }

         //daq_fao_copy_data_to_fifo(daq_dev, count, faoStatus->ReadPos, &rbufWP);
         {
            __u32  *usrBuf = (__u32*)daq_dev->fao_buffer.kaddr;
            __u32  *devBuf = (__u32*)(daq_dev->iomem_base[2] + 0x4000);
            unsigned ubufRP = faoStatus->ReadPos;
            unsigned i;
            for (i = 0; i < count; ++i) {
               devBuf[rbufWP++] = usrBuf[ubufRP++];
               rbufWP %= AO_FIFO_XSIZE;
               ubufRP %= faoStatus->BufLength;
            }
         }

         shared->AoRBufStatus.RPValue = rbufRP;
         shared->AoRBufStatus.WPValue = rbufWP;

         ao_buf_sta |= daq_fao_update_status(&shared->FaoParam, &shared->FaoStatus, count);
      }
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   daq_dev->dev_if0.xval |= dev_if0.xval;
   daq_dev->dev_if1.xval |= dev_if1.xval;
   faiStatus->BufState   |= ai_buf_sta;
   faoStatus->BufState   |= ao_buf_sta;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   tasklet_schedule(&daq_dev->dev_tasklet);

   return IRQ_RETVAL(1);
}
