/*
 * counter.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static
int daq_cntr_is_sharable_op(unsigned curOP, unsigned newOP)
{
   if (curOP == CNTR_OP_IDLE) return 1;
   if (curOP & newOP)         return 0; 

   curOP |= newOP;
   return !(curOP & (CNTR_OP_ONESHOT | CNTR_OP_TIMERPULSE | CNTR_OP_PWMOUT));
}

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_EVENTCOUNT)) {
         shared->CntrState[start].Operation |= CNTR_OP_EVENTCOUNT;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];

      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 1;
      ctl->CTM.OUTEN = 0;
      ctl->CTM.GSRC  = 0;
      ctl->CTM.GMOD  = !!shared->CntrConfig.EcGateEnabled[start];
      ctl->CTM.GPOL  = !!(shared->CntrConfig.EcGatePolarity[start] == Negative);

      ctl->CLK.SRC   = 0;
      ctl->CLK.POL   = !!(shared->CntrConfig.EcClkPolarity[start] == Negative);

      ctl->LDH   = CNTR_MAX_VAL;

      ctl->CMN.xval  = 0;
      ctl->CMN.DFEN  = !!shared->CntrConfig.CntrClkFltChEnabled[start];
      ctl->CMN.DFDUR = (__u8)shared->CntrConfig.CntrClkFltTime[start];
      ctl->CMN.ARM   = 1;
 
      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_one_shot(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_ONESHOT)) {
         shared->CntrState[start].Operation |= CNTR_OP_ONESHOT;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];

      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 0;
      ctl->CTM.OUTEN = 1;
      ctl->CTM.GPOL  = !!(shared->CntrConfig.OsGatePolarity[start] == Negative);
      switch (shared->CntrConfig.OsGateSource[start])
      {
      case SignalNone:
         ctl->CTM.GMOD = CT_GMOD_NOGATE;
         break;
      case SigCntGate0:
      case SigCntGate1:
         ctl->CTM.GMOD = CT_GMOD_RETRIGGER;
         ctl->CTM.GSRC = CT_GSRC_EXTERN;
         break;
      case SigInternal2KHz:
         ctl->CTM.GMOD = CT_GMOD_RETRIGGER;
         ctl->CTM.GSRC = CT_GSRC_2KHZ;
         break;
      case SigInternal200Hz:
         ctl->CTM.GMOD = CT_GMOD_RETRIGGER;
         ctl->CTM.GSRC = CT_GSRC_200HZ;
         break;
      case SigInternal20Hz:
         ctl->CTM.GMOD = CT_GMOD_RETRIGGER;
         ctl->CTM.GSRC = CT_GSRC_20HZ;
         break;
      case SigInternal2Hz:
         ctl->CTM.GMOD = CT_GMOD_RETRIGGER;
         ctl->CTM.GSRC = CT_GSRC_2HZ;
         break;
      }

      switch (shared->CntrConfig.OsOutSigType[start]) 
      {
      default:
      case PositivePulse:   ctl->CTM.OMD = CT_OMD_ACTIVEHIGH;  break;
      case NegativePulse:   ctl->CTM.OMD = CT_OMD_ACTIVELOW;   break;
      case ToggledFromLow:  ctl->CTM.OMD = CT_OMD_TOGGLELOW;   break;
      case ToggledFromHigh: ctl->CTM.OMD = CT_OMD_TOGGLEHIGH;  break;
      }

      ctl->CLK.POL = !!(shared->CntrConfig.OsClkPolarity[start] == Negative);
      switch (shared->CntrConfig.OsClkSource[start])
      {
      default:
      case SigCntClk0:
      case SigCntClk1:        ctl->CLK.SRC = CT_CLK_EXTERN;  break;
      case SigInternal20MHz:  ctl->CLK.SRC = CT_CLK_20MHZ;   break;
      case SigInternal2MHz:   ctl->CLK.SRC = CT_CLK_2MHz;    break;
      case SigInternal200KHz: ctl->CLK.SRC = CT_CLK_200KHZ;  break;
      case SigInternal20KHz:  ctl->CLK.SRC = CT_CLK_20KHZ;   break;
      }

      if (daq_device_is_event_active(daq_dev, KdxCntOneShot0 + start)) {
         daq_device_clear_event(daq_dev, KdxCntOneShot0 + start);
         shared->IsEvtSignaled[KdxCntOneShot0 + start] = 0;
         ctl->CTM.INTEN = 1;
      } 
      
      ctl->RCNUM = 1;
      ctl->LDH = shared->CntrConfig.OsDelayCount[start];

      ctl->CMN.xval= 0;
      ctl->CMN.ARM = 1;

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_TIMERPULSE)) {
         shared->CntrState[start].Operation |= CNTR_OP_TIMERPULSE;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];

      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 1;
      ctl->CTM.OUTEN = 1;
      ctl->CTM.LMOD  = 1;

      ctl->CTM.GPOL  = !!(shared->CntrConfig.TmrGatePolarity[start] == Negative);
      if (shared->CntrConfig.TmrGateEnabled[start]) {
         ctl->CTM.GMOD = CT_GMOD_LAVEL;
         ctl->CTM.GSRC = CT_GSRC_EXTERN;
      }

      if (shared->CntrConfig.TmrOutSigType[start] == PositivePulse) {
         ctl->CTM.OMD = CT_OMD_TOGGLEHIGH;
      } else {
         ctl->CTM.OMD = CT_OMD_TOGGLELOW;
      }

      if (daq_device_is_event_active(daq_dev, KdxCntTimer0 + start)) {
         daq_device_clear_event(daq_dev, KdxCntTimer0 + start);
         shared->IsEvtSignaled[KdxCntTimer0 + start] = 0;
         ctl->CTM.INTEN = 1;
      } 

      ctl->CLK.SRC = CT_CLK_20MHZ;
      ctl->CLK.POL = 0;

      if (shared->CntrConfig.TmrDivisor[start] & 0x1){
         ctl->LDH = shared->CntrConfig.TmrDivisor[start] / 2 + 1;
      } else {
         ctl->LDH = shared->CntrConfig.TmrDivisor[start] / 2;
      }
      ctl->LDL = shared->CntrConfig.TmrDivisor[start] / 2;

      ctl->CMN.xval= 0;
      ctl->CMN.ARM = 1;

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_FREQMETER)) {
         shared->CntrState[start].Operation |= CNTR_OP_FREQMETER;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];

      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 1;
      ctl->CTM.OUTEN = 0;

      ctl->CLK.SRC = CT_CLK_EXTERN;
      ctl->CLK.POL = 0;

      ctl->LDH = CNTR_MAX_VAL;

      ctl->CMN.xval  = 0;
      ctl->CMN.DFEN  = !!shared->CntrConfig.CntrClkFltChEnabled[start];
      ctl->CMN.DFDUR = (__u8)shared->CntrConfig.CntrClkFltTime[start];
      ctl->CMN.ARM   = 1;

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_pwm_in(daq_device_t *daq_dev, __u32 start, __u32 groupCount)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || groupCount > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   while (groupCount--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_PWMIN)) {
         shared->CntrState[start].Operation |= CNTR_OP_PWMIN;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];
      
      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 1;
      ctl->CTM.OUTEN = 0;

      ctl->CLK.SRC = CT_CLK_EXTERN;
      ctl->CLK.POL = 0;

      ctl->LDH = CNTR_MAX_VAL;

      ctl->CMN.xval= 0;
      ctl->CMN.ARM = 1;

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_pwm_out(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CT_CTL_R      *ctl;
   unsigned long flags;

   if(start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->cntr_lock, flags);
      if (daq_cntr_is_sharable_op(shared->CntrState[start].Operation, CNTR_OP_PWMOUT)) {
         shared->CntrState[start].Operation |= CNTR_OP_PWMOUT;
      } else {
         spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);

      ctl = &IOREGS->CT_CTL[start];

      ctl->CTM.xval  = 0;
      ctl->CTM.INFEN = 1;
      ctl->CTM.OUTEN = 1;
      ctl->CTM.LMOD  = 1;

      ctl->CTM.GPOL = !!(shared->CntrConfig.PoGatePolarity[start] == Negative);
      if (shared->CntrConfig.PoGateEnabled[start]) {
         ctl->CTM.GMOD = CT_GMOD_LAVEL;
         ctl->CTM.GSRC = CT_GSRC_EXTERN;
      }

      if (shared->CntrConfig.PoSignalType[start] == PositivePulse) {
         ctl->CTM.OMD = CT_OMD_TOGGLEHIGH;
      } else {
         ctl->CTM.OMD = CT_OMD_TOGGLELOW;
      }

      ctl->CLK.SRC = CT_CLK_20MHZ;
      ctl->CLK.POL = 0;

      ctl->LDH = shared->CntrConfig.PoHiPeriod[start];
      ctl->LDL = shared->CntrConfig.PoLoPeriod[start];

      ctl->CMN.xval= 0;
      ctl->CMN.ARM = 1;

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;

   spin_lock_irqsave(&daq_dev->cntr_lock, flags);
   while (count--) {
      IOREGS->CT_CTL[start].CMN.ARM = 0;
      IOREGS->CT_CTL[start].CMN.RST = 1;
      IOREGS->CT_CTL[start].CTM.INTEN = 0;
      IOREGS->DEV_IF0.xval = CT_X_INT_MASK(start);

      shared->CntrState[start].Operation = 0;

      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->cntr_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   default: return ErrorPropReadOnly;
      // common 
   case CFG_NoiseFilterEnabledChannels:
      dataPtr = &shared->CntrConfig.CntrClkFltChEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_NoiseFilterOverallBlockTime:
      dataPtr = &shared->CntrConfig.CntrClkFltTime[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //Event Count
   case CFG_EcClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.EcGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //OneShot
   case CFG_OsClkSourceOfCounters:
      dataPtr = &shared->CntrConfig.OsClkSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsGateSourceOfCounters:
      dataPtr = &shared->CntrConfig.OsGateSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.OsClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.OsGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.OsOutSigType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsDelayCountOfCounters:
      dataPtr = &shared->CntrConfig.OsDelayCount[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //TimerPulse
   case CFG_TmrFrequencyOfCounters:
      dataPtr = &shared->CntrConfig.TmrDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.TmrGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.TmrGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.TmrOutSigType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

      //FreqMeter
   case CFG_FmMethodOfCounters:
      dataPtr = &shared->CntrConfig.FmMethod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_FmCollectionPeriodOfCounters:
      dataPtr = &shared->CntrConfig.FmPeroid[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

      //PwmOut
   case CFG_PoHiPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoHiPeriod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoLoPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoLoPeriod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.PoGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.PoGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.PoSignalType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
   switch(cntr.Operation)
   {
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case OneShot:
      return daq_cntr_start_one_shot(daq_dev, cntr.Start, cntr.Count);
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmIn:
      return daq_cntr_start_pwm_in(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmOut:
      return daq_cntr_start_pwm_out(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
