/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
void daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   // check data ready and update write position
   if (st->WritePos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_IN_DATAREADY;
      st->WritePos  += inc_count;
      st->WritePos  %= st->BufLength;
      st->WPRunBack += 1;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      int ovrnOffset = st->ReadPos;
      int ovrnCount  = st->WritePos - ovrnOffset;
      st->BufState |= DAQ_IN_BUF_FULL;

      if (st->WPRunBack > 1 || ovrnCount > 0){
         if (st->WPRunBack > 1) { 
            ovrnCount = st->BufLength;
         }

         st->OvrnCount  = ovrnCount;
         st->OvrnOffset = ovrnOffset;
         st->BufState |= DAQ_IN_BUF_OVERRUN;
      }
   }
}

static inline 
void event_handler(daq_device_t *daq_dev)
{
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   // check running time status: overrun, data ready. save the buffer status
   // to local variable, so even if we are preempted by ISR, it has no any effect to us.
   unsigned buf_state = faiStatus->BufState;
   unsigned isCacheOverflow = faiStatus->IsCacheOverflow; //Save to local variable, so even if we are preempted by ISR, it has no any effect to us.
   faiStatus->BufState = 0;

   if(isCacheOverflow && !shared->IsEvtSignaled[KdxAiCacheOverflow]) {
      shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
      daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
   }

   if ((buf_state & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun]) {
     shared->IsEvtSignaled[KdxAiOverrun] = 1;
     daq_device_signal_event(daq_dev, KdxAiOverrun);
   }

   if ((buf_state & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady]) {
     shared->IsEvtSignaled[KdxAiDataReady] = 1;
     daq_device_signal_event(daq_dev, KdxAiDataReady);
   }

   if (DAQ_IN_MUST_STOP(buf_state, faiStatus->AcqMode)) {
      daq_fai_stop_acquisition(daq_dev, false);
   }
}


static inline
int daq_fai_read_fifo_probe(DEVICE_SHARED *shared, __u16 *data_buf, unsigned count)
{
#define FIFO_IS_EMPTY(shared) (AdxIoInB(shared->IoBase, DR_AiFifoStatus) & 0x1)
   __u16 * buf_end = data_buf + count;

   while(!FIFO_IS_EMPTY(shared) && data_buf < buf_end) {
      *data_buf++ = AdxIoInB(shared->IoBase, DR_AiFifoData) + (AdxIoInB(shared->IoBase, DR_AiFifoData + 1) << 8);
   }
   return count - (__u32)(buf_end - data_buf);
}

static inline
void daq_fai_copy_data_from_dma_buf(daq_device_t *daq_dev, __u32 readyDataCount, __u32 destPos, __u32 *dmaComnBufReadPos) 
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   __u16 *data_buf = (__u16 *)daq_dev->fai_buffer.kaddr;  
   __u32 length;
   //daq_trace(("IsrCopyDataFromDmaBuf: destPos=%d, count=%d, DMABufRP=%d\n", destPos, readyDataCount, dmaComnBufReadPos));
   while(readyDataCount)
   {
      length = readyDataCount;
      if (((destPos + length) >= shared->FaiStatus.BufLength) || ((*dmaComnBufReadPos + length) >= DMA_COMN_BUF_SIZE / 2))
      {
         length = min(shared->FaiStatus.BufLength - destPos, DMA_COMN_BUF_SIZE / 2 - *dmaComnBufReadPos);
      }
      readyDataCount -= length;
      memcpy( &data_buf[destPos], daq_dev->fai_common_buffer + *dmaComnBufReadPos, length * AI_DATA_SIZE );
      destPos += length;
      destPos %= shared->FaiStatus.BufLength; //Must be %=, because the SampleCount might not be 2^n
      *dmaComnBufReadPos += length;
      *dmaComnBufReadPos %= DMA_COMN_BUF_SIZE / 2; //If the mask is 2^n, can use &= to replace %= for performance 
   }
}

void daq_fai_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   unsigned      isCacheOverflow = shared->FaiStatus.IsCacheOverflow; //Save to local variable, so even if we are preempted by ISR, it has no any effect to us.

   if (faiStatus->FnState != DAQ_FN_RUNNING){
      return;
   }

   if (shared->FaiParam.XferMode == DAQ_XFER_INT) {
      unsigned    dataCount;
      unsigned    sectLen = 0;
      __u16       *data_buf = (__u16*)daq_dev->fai_buffer.kaddr;

      if (!isCacheOverflow) {
         if (shared->ProductId == BD_PCM3718HO && shared->EnableFifoOf3718HO 
             && shared->FaiParam.SectionSize > (AI_FIFO_SIZE / 2)) {

            __u16* ptr = &data_buf[faiStatus->WritePos];
            __u16* endPtr = min(ptr + (AI_FIFO_SIZE / 2), data_buf + faiStatus->BufLength);
            dataCount = AI_FIFO_SIZE / 2;

            sectLen = min((unsigned)AI_FIFO_SIZE / 2, faiStatus->BufLength - faiStatus->WritePos);
            while (ptr < endPtr) {
               *ptr++ = AdxIoInB(shared->IoBase, DR_AiFifoData) + (AdxIoInB(shared->IoBase, DR_AiFifoData + 1) << 8);
               dataCount--;
            }

            if ( shared->FaiStatus.AcqMode == DAQ_ACQ_INFINITE )
            {
               // Get samples of Section2
               if (dataCount) {
                  ptr = &data_buf[0];
                  endPtr = ptr + dataCount;
                  while (ptr < endPtr) {
                     *ptr++ = AdxIoInB(shared->IoBase, DR_AiFifoData) + (AdxIoInB(shared->IoBase, DR_AiFifoData + 1) << 8);
                  }
               }
               sectLen = AI_FIFO_SIZE / 2;
            }
         } else { // FIFO half full
            // Only one data available
            sectLen = 1;
            data_buf[faiStatus->WritePos] = AdxIoInB(shared->IoBase, DR_AiData) + (AdxIoInB(shared->IoBase, DR_AiData + 1) << 8);
         }

         daq_fai_update_status(&shared->FaiParam, faiStatus, sectLen);
      } 

      event_handler(daq_dev);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_STATUS_REG reg;

   reg.Value = AdxIoInB(shared->IoBase, DR_AiStatus);
   if (!reg.IntFlag)
   {
      return IRQ_RETVAL(0);
   }

   if (shared->FaiParam.XferMode == DAQ_XFER_INT && shared->ProductId == BD_PCM3718HO 
      && shared->EnableFifoOf3718HO && shared->FaiParam.SectionSize >= (AI_FIFO_SIZE / 2)) {
      //Get the FIFO cache overflow for PCM3718HO
      AI_FIFO_STATUS_REG fifoStatus;
      fifoStatus.Value = AdxIoInB(shared->IoBase, DR_AiFifoStatus);
      daq_trace(("FIFO Status: 0x%x\n", fifoStatus.Value));
      if ( fifoStatus.FifoFull )
      {
         daq_trace(("@@@ CacheOverflow \n"));
         //Clear the FifoFull flag, otherwise the Flag is still true at the next time enter ISR
         AdxIoOutB( shared->IoBase, DR_ClrFifo, 0 );
         shared->FaiStatus.IsCacheOverflow = 1;
      } else {
         shared->FaiStatus.IsCacheOverflow = 0;
      }
   }

   if (shared->FaiParam.XferMode == DAQ_XFER_INT) {
      tasklet_schedule(&daq_dev->fai_tasklet);
   }

   AdxIoOutB(shared->IoBase, DR_ClrIntr, 0);

   return IRQ_RETVAL(1);
}

void daq_ai_dma_copy_data_work_func(struct work_struct *work)
{
   daq_device_t    *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, dma_work);
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   FAI_STATUS      *faiStatus = &shared->FaiStatus;

   __u32           copyDataCount, readyDataCount;

   if (daq_dev->dma_run_flag){
      unsigned long flags = claim_dma_lock();
      faiStatus->DmaComnBufWritePos = DMA_COMN_BUF_SIZE / 2 - get_dma_residue(shared->DmaChan);
      release_dma_lock(flags);
      if (faiStatus->DmaComnBufWritePos < faiStatus->DmaComnBufReadPos) {
         readyDataCount = faiStatus->DmaComnBufWritePos - faiStatus->DmaComnBufReadPos + DMA_COMN_BUF_SIZE / 2;
      } else {
         readyDataCount = faiStatus->DmaComnBufWritePos - faiStatus->DmaComnBufReadPos;
      }
      copyDataCount = shared->FaiParam.SectionSize;
      if ((DMA_COMN_BUF_SIZE / 4) < shared->FaiParam.SectionSize ) {
         copyDataCount = (DMA_COMN_BUF_SIZE / 4);
      }


      if (readyDataCount > copyDataCount) {
         // for infinite mode, only fill the buffer once 
         if (shared->FaiStatus.AcqMode != DAQ_ACQ_INFINITE) {
            if ((faiStatus->WritePos + copyDataCount) >= shared->FaiStatus.BufLength) {
               copyDataCount = shared->FaiStatus.BufLength - faiStatus->WritePos;
            }
         }
         daq_trace(("EvtDmaCopyDataTimer: readyDataCount=%d, copyDataCount=%d\n", readyDataCount, copyDataCount));

         daq_fai_copy_data_from_dma_buf(daq_dev, copyDataCount, faiStatus->WritePos, &(faiStatus->DmaComnBufReadPos));
         daq_fai_update_status(&shared->FaiParam, faiStatus, copyDataCount);
         event_handler(daq_dev);
      }

      schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(AI_CHK_DMA_PERIOD_MS));
   }
}

