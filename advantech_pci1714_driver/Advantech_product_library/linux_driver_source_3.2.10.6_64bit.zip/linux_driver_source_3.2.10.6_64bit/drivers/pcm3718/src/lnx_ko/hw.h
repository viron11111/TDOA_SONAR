/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define ISA_DEVICE_ADDR_BAR_IOx 0
#define POOL_TAG        '817P'

#define IO_LEN_3718X     16
#define IO_LEN_3718HO    32   


#define DR_AiData         0x0

#define DR_AoDataBase     0x4
typedef union _AI_CHL_CFG_REG{
   __u8 Value;
   struct{
      __u8 GainCode  : 4; 
      __u8 Reserved  : 4;
   };
}AI_CHL_CFG_REG;

#define DR_AiChlCfg       0x1
#define DR_AiMux          0x2  

typedef union _AI_STATUS_REG{
   __u8 Value;
   struct{
      __u8 NextChan  : 4;  
      __u8 IntFlag   : 1;  
      __u8 SigConnect: 1;  
      __u8 Reserved  : 1;  
      __u8 Busy      : 1;  
   };
}AI_STATUS_REG;
#define DR_AiStatus      0x8
#define DR_ClrIntr       0x8

typedef union _AI_CTRL_REG{
   __u8 Value;
   struct{
      __u8 TrigSource: 2; 
      __u8 DmaEn     : 1; 
      __u8 Reserved  : 1; 
      __u8 Irql      : 3; 
      __u8 IntEn     : 1; 
   };
}AI_CTRL_REG;
#define DR_AiCtrl        0x9

typedef union _PACER_CTRL_REG
{
   __u8 Value;
   struct{
      __u8 PacerEn     : 1; 
      __u8 Cntr2ClkSrc : 1; 
      __u8 Reserved    : 6;
   };
}PACER_CTRL_REG;
#define DR_PacerCtrl     0xa  

typedef union _AI_FIFO_CTRL_REG{
   __u8 Value;
   struct{
      __u8 FifoEn    : 1;  
      __u8 Reserved  : 7;
   };
}AI_FIFO_CTRL_REG;
#define DR_AiFifoCtrl     0x6   
typedef union _AI_FIFO_STATUS_REG{
   __u8 Value;
   struct{
      __u8 FifoEmpty    : 1; 
      __u8 FifoHalfFull : 1; 
      __u8 FifoFull     : 1; 
      __u8 Reserved     : 5;
   };
}AI_FIFO_STATUS_REG;
#define DR_AiFifoStatus  19 
#define DR_ClrFifo       19 
#define DR_AiFifoData    17 


#define DR_CntrCSR        0xF
#define DR_Cntr0IOR       0xC

#define DR_Cntr1CSR       0xD
#define DR_Cntr2CSR       0xE

#define DIO_STEP         0x8

#define DR_DiBase        0x3
#define DR_DI_PORTX( x )  ( DR_DiBase + x * DIO_STEP )

#define DR_DoBase        0x3
#define DR_DO_PORTX( x )  ( DR_DoBase + x * DIO_STEP )

#endif /* _KERNEL_MODULE_HW_H_ */
