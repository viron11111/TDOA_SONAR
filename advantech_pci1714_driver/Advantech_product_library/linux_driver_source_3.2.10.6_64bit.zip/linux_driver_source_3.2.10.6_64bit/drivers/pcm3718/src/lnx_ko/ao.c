/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"


//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int           i;
   __u16         rawData;

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         rawData = (__u16)(shared->AoChanState[i] << 4);
         AdxIoOutB(shared->IoBase, DR_AoDataBase + i * AO_DATA_SIZE, rawData & 0xff );
         AdxIoOutB(shared->IoBase, DR_AoDataBase + i * AO_DATA_SIZE + 1, ( rawData >> 8 ) & 0xff );
      }
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      __u32      i, ch, gains[AO_CHL_COUNT];

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
      }

   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }


   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   {
      AdxIoOutB(shared->IoBase, DR_AoDataBase, data[0] & 0xff );
      AdxIoOutB(shared->IoBase, DR_AoDataBase + 1, (data[0] >> 8) & 0xff );
   }

   return 0;
}


