/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define PCI_DEVICE_ADDR_BAR 1

#define DR_DI_BASE         0
#define DR_DI_PORTX(x)     (DR_DI_BASE + x)

#define DR_BID             0x10

#define DI_INT_EN          (1 << 1)
#define TRIG_EDGE_RISING   (1 << 2)
#define TRIG_EDGE_FALLING  (0 << 2)

#define DI_INT_MASK         0x8  // bit 3 of each CSR
#define DI_INT_CSR_LEN      2

#define DR_DI_INT_CSR_BASE  0x8
#define DR_DI_INT_CSR(x)    (DR_DI_INT_CSR_BASE + (x * DI_INT_CSR_LEN))

#endif /* _KERNEL_MODULE_HW_H_ */
