/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AO Data
#define DR_AO_DATA_BASE   0x0
#define DR_BID            0x10

typedef union _AO_CHL_CSR{
   __u16 Value;
   struct{
      __u16 CHx_Gain : 8;
      __u16 CHx_Mode : 4;
      __u16 CHx_VREF : 4;
   };
}AO_CHL_CSR;

#define DR_AO_CHCSR       0x12

#define DR_AO_SYNC_CTL    0x22
#define DR_AO_SYNC_STROBE 0x24

#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _DEV_CTL_STA{
   __u16 Value;
   struct{
      __u16 Cntr0Clk    : 1;
      __u16 Cntr0Gate   : 1;
      __u16 Reserved0   : 1;
      __u16 DirOfLDIO   : 1;
      __u16 DirOfHDIO   : 1;
      __u16 FifoClk     : 2;
      __u16 Reserved1   : 9;
   };
}DEV_CTL_STA;
#define DR_CONTROL        0x2A
#define DR_STATUS         0x2A

#define DR_CLR_FIFO       0x2C

// FIFO status register
typedef union _FIFO_STATUS{
   __u16 Value;
   struct{
      __u16 NotEmpty : 1;
      __u16 NotHalf  : 1;
      __u16 NotFull  : 1;
      __u16 Reserved : 9;
   };
}FIFO_STATUS;
#define DR_FIFO_STATUS    0x2E

#define DR_DIO_DATA       0x3E

#define DR_DMA_FIFO_DATA  0x40

#define DR_CNTR0       0x30
#define DR_CNTR1       0x32
#define DR_CNTR2       0x34
#define DR_CNTR_CTL    0x36

#endif /* _KERNEL_MODULE_HW_H_ */
