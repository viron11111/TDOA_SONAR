/*
 * isr.c
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   
   if (shared->DiSnapParam[0].PortCount) {
      __u32 i;
      for ( i = 0; i < DIO_PORT_COUNT; ++i ) {
        shared->DiSnapState[0].State[i] = AdxIoInB(shared->IoBase, DR_DI_PORTX(i));
      }
   }

   // signal the event if needed.
   if (!shared->IsEvtSignaled[KdxDiBegin]) {
      shared->IsEvtSignaled[KdxDiBegin] = 1;
      daq_device_signal_event(daq_dev, KdxDiBegin);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;

   tasklet_schedule(&daq_dev->dio_tasklet);

   return IRQ_RETVAL(1);
}

