/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: rocky
 */
#include "kdriver.h"

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         memset(cntr, 0, sizeof(CNTR_STATE));
         cntr->Operation = InstantEventCount;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_event_count(daq_dev, start);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
         break;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   CNTR_STATE      *cntr;
   struct timespec tm_now;
   unsigned long   flags;
   int             ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         memset(cntr, 0, sizeof(CNTR_STATE));
         cntr->Operation = InstantFreqMeter;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_event_count(daq_dev, start);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
         break;
      }

      cntr->AutoAdaptive = shared->CntrConfig.FmPeroid[start] == 0;
      if (shared->CntrConfig.FmPeroid[start]) {
         cntr->CheckPeriod = max((__u32)CNTR_CHK_PERIOD_NS, shared->CntrConfig.FmPeroid[start] * 1000000 / CNTR_RBUF_DEPTH);
      } else {
         cntr->CheckPeriod = CNTR_CHK_PERIOD_NS;
      }

      tm_now = current_kernel_time();
      cntr->PrevTime = timespec_to_ns(&tm_now);
      shared->CntrChkTimerOwner |= 0x1 << start;
      schedule_delayed_work(&daq_dev->cntr_fm_work, 1);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

static
void daq_cntr_update_fm_state(daq_device_t *daq_dev, __u32 counter)
{
   CNTR_STATE      *cntr = &daq_dev->shared.CntrState[counter];
   struct timespec tm_now;
   __s64           tm_now_ns;
   __u32           hw_val, val_delta, tm_delta;

   getnstimeofday(&tm_now);
   tm_now_ns = timespec_to_ns(&tm_now);
   tm_delta  = (__u32)(tm_now_ns - cntr->PrevTime);

   if (cntr->CanRead) {
      if (tm_delta < cntr->CheckPeriod){
         return;
      }

      if (daq_usb_cntr_read_event_count(daq_dev, counter, &hw_val, &tm_now) < 0) {
         cntr->CanRead = 0;
         return;
      }

      ++cntr->Tail;
      cntr->Tail &= CNTR_RBUF_POSMASK;
      if (cntr->Tail == cntr->Head) {
         cntr->SummedValue -= cntr->CntrDelta[cntr->Head];
         cntr->TotalTime   -= cntr->TimeDelta[cntr->Head];
         cntr->Head        =  (cntr->Tail + 1) & CNTR_RBUF_POSMASK;
      }

      val_delta = hw_val - cntr->PrevValue;
      cntr->CntrDelta[cntr->Tail] = val_delta;
      cntr->SummedValue          += val_delta;
      cntr->TimeDelta[cntr->Tail] = tm_delta;
      cntr->TotalTime            += tm_delta;
      cntr->PrevValue             = hw_val;
      cntr->PrevTime              = tm_now_ns;

      if (cntr->AutoAdaptive){
         if (val_delta >= 10 * CNTR_VAL_THRESHOLD_BASE) {
            cntr->CheckPeriod = CNTR_CHK_PERIOD_NS;
         } else if (val_delta < CNTR_VAL_THRESHOLD_BASE) {
            cntr->CheckPeriod = min(cntr->CheckPeriod << 3, (__u32)CNTR_CHK_PERIOD_MAX_NS);
         }
      }
   } else {
      if (daq_usb_cntr_read_event_count(daq_dev, counter, &hw_val, &tm_now) < 0) {
         return;
      }
      cntr->CanRead     = hw_val != 0;
      cntr->SummedValue = cntr->CntrDelta[0] = hw_val;
      cntr->TotalTime   = cntr->TimeDelta[0] = tm_delta;
      cntr->PrevTime    = tm_now_ns;
      cntr->PrevValue   = hw_val;
   }
}
//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_freq_measure_work_func(struct work_struct *work)
{
   daq_device_t *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, cntr_fm_work);
   __u32        active   = daq_dev->shared.CntrChkTimerOwner;
   int          i;

   for (i = 0; active; ++i, active >>= 1){
      if (active & 0x1) {
         daq_cntr_update_fm_state(daq_dev, i);
      }
   }

   if (daq_dev->shared.CntrChkTimerOwner){
      schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(CNTR_CHK_PERIOD_NS / 1000000L));
   }
}

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   while (count--) {
      shared->CntrChkTimerOwner &= ~(0x1 << start);
      if (shared->CntrState[start].Operation != CNTR_IDLE) {
         shared->CntrState[start].Operation = CNTR_IDLE;
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_usb_cntr_reset(daq_dev, start);
         spin_lock_irqsave(&daq_dev->dev_lock, flags);
      }
      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_FmCollectionPeriodOfCounters:
      dataPtr = &shared->CntrConfig.FmPeroid[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   struct timespec dummy;
   CNTR_READ       cntr;
   CNTR_VALUE      vals[CNTR_CHL_COUNT];
   int             i, ret;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   for (i = 0; i < cntr.Count; ++i) {
      ret = daq_usb_cntr_read_event_count(daq_dev, cntr.Start, &vals[i].Value, &dummy);
      if (ret < 0){
			return ret;
      }
      ++cntr.Start;
      cntr.Start %= CNTR_CHL_COUNT;
   }

   if (unlikely(copy_to_user(cntr.Value, vals, cntr.Count * sizeof(CNTR_VALUE)))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
