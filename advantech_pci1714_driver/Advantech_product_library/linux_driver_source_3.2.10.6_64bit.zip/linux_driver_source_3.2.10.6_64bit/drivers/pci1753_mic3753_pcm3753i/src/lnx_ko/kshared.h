/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1753
#define DEVICE_ID_3753     0x3753
#define DEVICE_PID    BD_PCI1753
#define DEVICE_PID_MIC3753    BD_MIC3753
#define DEVICE_PID_PCM3753    BD_PCM3753P
#define DEVICE_NAME   "PCI-1753"
#define DRIVER_NAME   "bio1753"

#define DEVICE_NAME_FROM_PID(pid) \
   (pid == BD_PCI1753 ? "PCI-1753" : "PCM-3753I")
//
// H/W feature and structures.
//
// Note:
//    This file is shared between kernel mode driver and user mode
// driver. So the definition must be consistent in both drivers.
#define DIO_GROUP_COUNT_MAX         8
#define DIO_PORTS_COUNT_MAX          24
#define DIO_CHL_COUNT_MAX            (DIO_PORTS_COUNT_MAX * 8)
#define DI_INT_SRC_COUNT_MAX         8  // CH#016,CH#040,CH#056,CH#080....
#define DI_SNAP_SRC_COUNT_MAX        ( DI_INT_SRC_COUNT_MAX + DI_COS_SRC_COUNT_MAX +DI_PM_SRC_COUNT_MAX  )

#define DI_COS_SRC_COUNT_MAX         2
#define DI_PM_SRC_COUNT_MAX          2

#define DIO_GROUP_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )? \
       DIO_GROUP_COUNT_MAX: DIO_GROUP_COUNT_MAX/2 ) )

#define DIO_PORTS_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )?\
       DIO_PORTS_COUNT_MAX: DIO_PORTS_COUNT_MAX/2 ) )

#define DIO_CHL_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )?\
       DIO_CHL_COUNT_MAX: DIO_CHL_COUNT_MAX/2 ) )

#define DI_COS_SRC_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )?\
       DI_COS_SRC_COUNT_MAX: DI_COS_SRC_COUNT_MAX/2 ) )

#define DI_PM_SRC_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )? \
       DI_PM_SRC_COUNT_MAX: DI_PM_SRC_COUNT_MAX/2 ) )

#define DI_INT_SRC_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )?\
       DI_INT_SRC_COUNT_MAX: DI_INT_SRC_COUNT_MAX/2 ) )

#define DI_SNAP_SRC_COUNT( ExpBoardOn, ProductId ) ( (uint32)( ( ( ExpBoardOn == 1 )&&( ProductId == BD_PCI1753 ) )?\
       DI_SNAP_SRC_COUNT_MAX: DI_SNAP_SRC_COUNT_MAX/2 ) )

//#define DEVICE_NAME( ProductId )      ( ( ( ( ProductId == BD_PCI1753 ) )?  L"PCI-1753" :L"PCM-3753I"  ) )
#define REGVAL_DLL_DRV           L"Bio1753.DLL"
#define DEVICE_NAME_MAX_CCHLEN   (sizeof(L"PCM-3753I") / sizeof(WCHAR))

#define  MAX_CUSTOMER_DATA_COUNT 128
#define  EEPROM_DELAY_TIME_UNIT_IN_10us    10


// device register : Port x data
#define PortCountPerGroup        3     // each group contains 3 port
#define DR_GroupX_Base( x )      ((x) * 4)
#define DR_GroupX_PortY( x, y )  ( DR_GroupX_Base(x) + y )

#define DR_GroupX_Ctrl( x )      ( DR_GroupX_Base(x) + 3 )
#define DR_BID                   0x14 // For version 0xA100 and later


#define STOP_INTERRUPT          0Xca
#define DEV_INT_MASK            0x80  // for fast detect the interrupt status
#define DEV_INT_SNAP_FALG_MASK  0x8a
#define DEV_INT_COS_PM_MASK     0x05
#define DR_IntCSR_START_ADDR    0x10
#define DR_IntCSR_START_ADDR_E  0x30
#define DEV_COS_FLAG_MASK       0xf7
#define DEV_PM_FLAG_MASK        0xfd
#define DEV_NO_DEFINE_MASK      0xf0
#define DR_COS_CHAN1753    0X1C
#define DR_COS_CHAN1753E   0X3C
#define DR_PM_CHAN1753     0X18
#define DR_PM_CHAN1753E    0X38
#define DR_PM_VALUE1753    0X14
#define DR_PM_VALUE1753E   0X34

// EEPROM register definition
#define EEPROM_DELAY_US      1000
#define EEPROM_WRITE_OK      0x80
#define EEPROM_READ_OK       0x40
#define EEPROM_TRIGGER_WRITE 0x7f
#define EEPROM_TRIGGER_READ  0x80

#define DR_EEPROM_DATA  29
#define DR_EEPROM_CTRL  31



//
// Kernel driver supported user notification event type.
// Note:
//    for performance, the event type value is just an index
// to event object pointer array and the definition is specified
// with the kernel mode driver. Please be CAREFUL when used in dll driver.
typedef enum _KRNL_EVENT_IDX
{
   // Device event
   EvtDevPropChgedIdx = 0,
   // DIO event
   EvtDiIdxBegin,
   EvtDiintChan016Idx = EvtDiIdxBegin,
   EvtDiintChan040Idx,
   EvtDiintChan064Idx,
   EvtDiintChan088Idx,
   EvtDiPmintPort000Idx,
   EvtDiCosintPort001Idx,
   EvtDiintChan112Idx,
   EvtDiintChan136Idx,
   EvtDiintChan160Idx,
   EvtDiintChan184Idx,
   EvtDiPmintPort012Idx,
   EvtDiCosintPort013Idx,

   EvtDiIdxEnd  = EvtDiCosintPort013Idx,
   KrnlSptedEventCount
}KRNL_EVENT_IDX;

// Helper function used to map a user mode event type to kernel event index for DIO
static  __inline uint32 UserDioEvtType2KrnlIdx( uint32 eventType )
{
   switch ( eventType )
   {
      case EvtDiintChannel016:
         return EvtDiintChan016Idx;
      case EvtDiintChannel040:
         return EvtDiintChan040Idx;
      case EvtDiintChannel064:
         return EvtDiintChan064Idx;
      case EvtDiintChannel088:
         return EvtDiintChan088Idx;
      case EvtDiintChannel112:
         return EvtDiintChan112Idx;
      case EvtDiintChannel136:
         return EvtDiintChan136Idx;
      case EvtDiintChannel160:
         return EvtDiintChan160Idx;
      case EvtDiintChannel184:
         return EvtDiintChan184Idx;
      case EvtDiPmintPort000:
         return EvtDiPmintPort000Idx;
      case EvtDiCosintPort001:
         return EvtDiCosintPort001Idx;
      case EvtDiPmintPort012:
         return EvtDiPmintPort012Idx;
      case EvtDiCosintPort013:
         return EvtDiCosintPort013Idx;
   }
   return -1; // not supported user event type
}

// Helper function used to map a user mode event type to kernel event index.
static  __inline uint32 GetEventKIndex( uint32 eventType )
{
	uint32 eventIdx;
   if ( eventType == EvtPropertyChanged )
   {
      return EvtDevPropChgedIdx;
   }
   eventIdx = UserDioEvtType2KrnlIdx( eventType );
   return eventIdx;
}

typedef struct _DI_SNAP_CONFIG
{
	uint32 portStart;
	uint32 portCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATUS
{
   __u8 state[DIO_PORTS_COUNT_MAX];
} DI_SNAP_STATUS;


// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DIO_DIR             0x00
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge
#define DEF_DIINT_GATE          0

typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number

   // HW Information
   __u32   SubsystemID;    // Used to identify the variant of the HW which has more difference.
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   IoBase;		   // Base address of Device's registers
   __u32   IoLength;
   __u32   Irq;        // interrupt number.

   // Device setting
   __u32   InitOnLoad;     // Whether or not we should init the output channel/port when driver loading.
   __u8   DioPortDir[DIO_PORTS_COUNT_MAX];
   __u8   DoPortState[DIO_PORTS_COUNT_MAX];
   __u8   DiintTrigEdge[DI_INT_SRC_COUNT_MAX];
   __u8   DiintGateCtrl[DI_INT_SRC_COUNT_MAX];

   __u8   DiCosChEnabled[DI_COS_SRC_COUNT_MAX]; // DI 'status change' interrupt enabled channels.
   __u8   DiPmChEnabled [DI_PM_SRC_COUNT_MAX]; // DI 'pattern match' interrupt enabled channels.
   __u8   DiPmPortsValue[DI_PM_SRC_COUNT_MAX]; // DI 'pattern match' port value to match.

   // DI snap configuration & status
   DI_SNAP_CONFIG DiSnapParam[ DI_SNAP_SRC_COUNT_MAX ];
   DI_SNAP_STATUS DiSnapState[ DI_SNAP_SRC_COUNT_MAX ];

   __u32 isExpBoardOn;
   // Interrupt Status and DI port snapshot
   // An flag used to fix the H/W bug:
   // The H/W will signal an improper interrupt each time we enable a channel's interrupt.
   __u32   IntCsr[DI_SNAP_SRC_COUNT_MAX];
   __u32    IsEvtSignaled[KrnlSptedEventCount]; // Use 'long' so we can use interlockedXXXX

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
