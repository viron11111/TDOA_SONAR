/*
 * dio.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

extern uint32 s_dioGroupRegOffset[8];
extern uint32 s_dioPortRegOffset[24];

void DioSetPortDir( daq_device_t *daq_dev )
{
   uint32 i;
   __u8 const *  dirs = daq_dev->shared.DioPortDir;
   GROUP_CTRL_REG newDir = {0};
   for ( i = 0; i <( DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)/PortCountPerGroup) ; ++i )
   {

      newDir.PADir = *dirs++ == 0 ? PORTDIR_IN : PORTDIR_OUT;
      newDir.PBDir = *dirs++ == 0 ? PORTDIR_IN : PORTDIR_OUT;
      newDir.PCLowDir = (*dirs & 0x0F) == 0 ? PORTDIR_IN : PORTDIR_OUT;
      newDir.PCHighDir= (*dirs & 0xF0) == 0 ? PORTDIR_IN : PORTDIR_OUT;
      ++dirs;
      //PCI-1753'S Control register can not support read back,so we set them directly.
      AdxIoOutB( daq_dev->shared.IoBase,  s_dioGroupRegOffset[i], newDir.Value );
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
	__u32 i;
   DioSetPortDir( daq_dev );
   if (daq_dev->shared.InitOnLoad){

	   __u8 const * state = daq_dev->shared.DoPortState;
		for ( i = 0; i < DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId); ++i, ++state )
		{
			AdxIoOutB( daq_dev->shared.IoBase, s_dioPortRegOffset[i], *state );
		}
   }
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   __u32        i, port;
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT_MAX];


   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
   xbuf.PortCount  = min((unsigned)DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId), xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
      data[i] = AdxIoInB(daq_dev->shared.IoBase, DR_DI_PORTX(port));

   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT_MAX];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
   xbuf.PortCount  = min((unsigned)DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId), xbuf.PortCount);
   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.PortCount))){
      return -EFAULT;
   }
//   xbuf.PortStart %= DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
//   xbuf.PortCount  = min((unsigned)DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId), xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
      AdxIoOutB(daq_dev->shared.IoBase, s_dioPortRegOffset[port], data[i]);
   }

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       data, status;
   unsigned   port, bit;
   unsigned long flags;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }
   xbuf.Port %= DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);

   port = (xbuf.Port) % DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
   bit  = xbuf.Bit;
   data = xbuf.Data;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   status = AdxIoInB(daq_dev->shared.IoBase, s_dioPortRegOffset[port]);
   status = ((data & 0x1) << bit) | (~(1 << bit) & status);
   AdxIoOutB(daq_dev->shared.IoBase, s_dioPortRegOffset[port], status);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
   
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT_MAX];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
   xbuf.PortCount  = min((unsigned)DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId), xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId);
      data[i] = AdxIoInB(daq_dev->shared.IoBase, s_dioPortRegOffset[port]);
   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_dio_set_port_direction(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_PORT_DIR xbuf;
   __u8              *dest = NULL;
   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }
   if (xbuf.PortStart + xbuf.PortCount > DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)) {
      return -EINVAL;
   }

   dest = shared->DioPortDir;
   dest += xbuf.PortStart;

   if (unlikely(copy_from_user(dest, xbuf.Dirs, xbuf.PortCount))) {
      return -EFAULT;
   }

   DioSetPortDir( daq_dev );
   return 0;
}

int daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)) {
      return -EINVAL;
   }

   if (xbuf.SetWhich != DIINT_SET_TRIGEDGE) {
      return -EINVAL;
   }
   dest = shared->DiintTrigEdge;
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, (void *)arg, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_START_DI_SNAP xbuf;
   uint32          evtIdx, group, status = 0 ;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   //find the current event is in which group recur to the relation with evtIdx and group
   evtIdx = UserDioEvtType2KrnlIdx( xbuf.EventId ) ;
   group = evtIdx -1;
   if ( evtIdx >= EvtDiintChan112Idx && evtIdx <= EvtDiintChan184Idx )
   {
	  group = evtIdx -3;
   }

   switch ( xbuf.EventId  )
     {

        case EvtDiintChannel016:
        case EvtDiintChannel040:
        case EvtDiintChannel064:
        case EvtDiintChannel088:
        case EvtDiintChannel112:
        case EvtDiintChannel136:
        case EvtDiintChannel160:
        case EvtDiintChannel184:
           status = InterruptEnableDiInt( daq_dev, 1,
           shared->DiintGateCtrl[group] ? INT_SRC_PC0_WITH_GATE : INT_SRC_PC0,
           shared->DiintTrigEdge[group] == RisingEdge ? TRIG_EDGE_RISING : TRIG_EDGE_FALLING,
           evtIdx );
           shared->DiSnapParam[evtIdx-1].portStart = (__u8)xbuf.PortStart;
           shared->DiSnapParam[evtIdx-1].portCount = (__u8)xbuf.PortCount;
           break;
        case EvtDiCosintPort001:
        case EvtDiCosintPort013:
           InterruptEnableDiCos( daq_dev,1,evtIdx);
  	        shared->DiSnapParam[evtIdx-1].portStart = (__u8)xbuf.PortStart;
  	        shared->DiSnapParam[evtIdx-1].portCount = (__u8)xbuf.PortCount;
           break;
        case EvtDiPmintPort000:
        case EvtDiPmintPort012:
           InterruptEnableDiPm( daq_dev,1,evtIdx);
  	        shared->DiSnapParam[evtIdx-1].portStart = (__u8)xbuf.PortStart;
  	        shared->DiSnapParam[evtIdx-1].portCount = (__u8)xbuf.PortCount;
           break;
        default:
           break;
     }

   return status;
}

int daq_ioctl_dio_set_dicos_cfg(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DICOS_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)) {
      return -EINVAL;
   }

   dest = shared->DiCosChEnabled;
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.ChanEnable, xbuf.SrcCount))) {
      return -EFAULT;
   }
   return 0;
}

int daq_ioctl_dio_set_dipm_cfg(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
     return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORTS_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)) {
      return -EINVAL;
   }

   if (xbuf.SetWhich == DIPM_SET_CHENBED) {
      dest = shared->DiPmChEnabled;
   }else if(xbuf.SetWhich == DIPM_SET_PORTVAL)
   {
      dest = shared->DiPmPortsValue;
   }
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.Buffer, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
//   DEVICE_SHARED *shared = &daq_dev->shared;
   uint32 evtId;
   uint32 evtIdx, group, status ;

   if (unlikely(copy_from_user(&evtId, (void *)arg, sizeof(evtId)))) {
      return -EFAULT;
   }

   //find the current event is in which group recur to the relation with evtIdx and group
   evtIdx = UserDioEvtType2KrnlIdx( evtId ) ;
   if (evtIdx >= DI_SNAP_SRC_COUNT(daq_dev->shared.isExpBoardOn,daq_dev->shared.ProductId)) {
      return -EINVAL;
   }

   group = evtIdx -1;
   if ( evtIdx >= EvtDiintChan112Idx && evtIdx <= EvtDiintChan184Idx )
   {
      group = evtIdx -3;
   }

   switch ( evtId )
    {
       case EvtDiintChannel016:
       case EvtDiintChannel040:
       case EvtDiintChannel064:
       case EvtDiintChannel088:
       case EvtDiintChannel112:
       case EvtDiintChannel136:
       case EvtDiintChannel160:
       case EvtDiintChannel184:
          status = InterruptEnableDiInt( daq_dev, 0, INT_SRC_PC0,TRIG_EDGE_FALLING,evtIdx );
          status = InterruptEnableDiInt( daq_dev, 0, INT_SRC_PC0_WITH_GATE,TRIG_EDGE_FALLING,evtIdx );
          break;
       case EvtDiPmintPort000:
       case EvtDiPmintPort012:
          status = InterruptEnableDiPm( daq_dev,0,evtIdx);
          break;
       case EvtDiCosintPort001:
       case EvtDiCosintPort013:
          status = InterruptEnableDiCos( daq_dev,0,evtIdx);
          break;
       default:
       return ErrorEventNotSpted;
    }

   return 0;
}

int InterruptEnableDiInt( daq_device_t *daq_dev,unsigned long isEnable, unsigned long src,unsigned long edge,unsigned long eventIdx )
{
   DEV_INT_CSR csr;
   uint32 intRegOffset = 0;
   if ( eventIdx <= EvtDiintChan088Idx)
   {
      //get intRegOffset base on intCsr start address and eventIdx
      intRegOffset = DR_IntCSR_START_ADDR + eventIdx - 1;
   }else{
      intRegOffset = DR_IntCSR_START_ADDR_E + eventIdx - 7;
   }
   csr.Value = AdxIoInB( daq_dev->shared.IoBase, intRegOffset ) & (~DEV_INT_MASK);

   if ( isEnable )
   {
      csr.GrpMode = src;
      csr.GrpEdge = edge;
      csr.Value &= (~DEV_INT_COS_PM_MASK);
      // Reset the associated event
      daq_dev->shared.IsEvtSignaled[eventIdx] = 0;
      daq_device_clear_event( daq_dev, eventIdx );
   }else{
      csr.GrpMode = INT_DISABLED;
      csr.Value &= (~DEV_INT_COS_PM_MASK);
   }
   // the following lines should be synchronized with interrupt
   spin_lock(&daq_dev->dev_lock);
   AdxIoOutB( daq_dev->shared.IoBase, intRegOffset, csr.Value );
   spin_unlock(&daq_dev->dev_lock);

   return 0;
}

int InterruptEnableDiPm( daq_device_t *daq_dev,unsigned long isEnable,unsigned long eventIdx )
{
   DEV_INT_CSR csr;
   uint32 pmRegOffset = 0;
   if ( EvtDiPmintPort000Idx == eventIdx )
   {
      //get intRegOffset with intCsr start address and eventIdx
      pmRegOffset = DR_IntCSR_START_ADDR ;
   }else if (1 == daq_dev->shared.isExpBoardOn)
   {
      pmRegOffset = DR_IntCSR_START_ADDR_E ;
   }
   csr.Value = AdxIoInB( daq_dev->shared.IoBase, pmRegOffset ) & (~DEV_INT_MASK);
   if ( isEnable )
   {
      switch (eventIdx)
      {
        case EvtDiPmintPort000Idx:
              AdxIoOutB(daq_dev->shared.IoBase,DR_PM_CHAN1753,daq_dev->shared.DiPmChEnabled[0]);
              AdxIoOutB(daq_dev->shared.IoBase,DR_PM_VALUE1753,daq_dev->shared.DiPmPortsValue[0]);
              break;

        case EvtDiPmintPort012Idx:
              AdxIoOutB(daq_dev->shared.IoBase,DR_PM_CHAN1753E,daq_dev->shared.DiPmChEnabled[1]);
              AdxIoOutB(daq_dev->shared.IoBase,DR_PM_VALUE1753E,daq_dev->shared.DiPmPortsValue[1]);
              break;
         default:
            break;
      }
      csr.PmEnable = 1;
      csr.Value &= DEV_COS_FLAG_MASK;
       // Reset the associated event
      daq_dev->shared.IsEvtSignaled[eventIdx] = 0;
      daq_device_clear_event( daq_dev, eventIdx );
   }else{
      csr.PmEnable = INT_DISABLED;
      csr.Value &= DEV_COS_FLAG_MASK;
   }
   // the following lines should be synchronized with interrupt
   spin_lock(&daq_dev->dev_lock);
   AdxIoOutB( daq_dev->shared.IoBase, pmRegOffset, csr.Value );
   spin_unlock(&daq_dev->dev_lock);
   return 0;
}

int InterruptEnableDiCos( daq_device_t *daq_dev,unsigned long isEnable,unsigned long eventIdx )
{
   DEV_INT_CSR csr;
   uint32 cosRegOffset = 0;
   if ( EvtDiCosintPort001Idx == eventIdx )
   {
      //get intRegOffset base on intCsr start address and eventIdx
      cosRegOffset = DR_IntCSR_START_ADDR ;
   }else if (1 == daq_dev->shared.isExpBoardOn)
   {
      cosRegOffset = DR_IntCSR_START_ADDR_E ;
   }
   csr.Value = AdxIoInB( daq_dev->shared.IoBase, cosRegOffset ) & (~DEV_INT_MASK);
   if ( isEnable )
   {
      switch (eventIdx)
      {
         case EvtDiCosintPort001Idx:
            AdxIoOutB(daq_dev->shared.IoBase,DR_COS_CHAN1753,daq_dev->shared.DiCosChEnabled[0]);
            break;
         case EvtDiCosintPort013Idx:
            AdxIoOutB(daq_dev->shared.IoBase,DR_COS_CHAN1753E,daq_dev->shared.DiCosChEnabled[1]);
            break;
         default:
         break;
      }
      csr.CosEnable = 1;
      csr.Value &= DEV_PM_FLAG_MASK;
      // Reset the associated event
      daq_dev->shared.IsEvtSignaled[eventIdx] = 0;
      daq_device_clear_event( daq_dev, eventIdx );
   }else{
      csr.CosEnable = INT_DISABLED;
      csr.Value &= DEV_COS_FLAG_MASK;
   }

   // the following lines should be synchronized with interrupt
   spin_lock(&daq_dev->dev_lock);
   AdxIoOutB( daq_dev->shared.IoBase, cosRegOffset, csr.Value );
   spin_unlock(&daq_dev->dev_lock);

   return 0;
}
