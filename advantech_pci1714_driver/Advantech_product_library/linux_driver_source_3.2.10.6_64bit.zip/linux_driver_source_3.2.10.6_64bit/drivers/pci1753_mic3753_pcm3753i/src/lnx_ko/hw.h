/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define PCI_DEVICE_ADDR_BAR 2

#define DR_DI_BASE         0
#define DR_DI_PORTX(x)     (DR_DI_BASE + x)

#define DR_BID             0x14

#define TRIG_EDGE_RISING   1
#define TRIG_EDGE_FALLING  0
#define DR_INT_TRIGEDGE    0x8

// DIO port group configuration register
#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _GROUP_CTRL_REG{
	__u8 Value;
	struct{
		__u8 PCLowDir : 1;  // Port C lower nibble
		__u8 PBDir    : 1;  // Port B
		__u8 Reserved : 1;
		__u8 PCHighDir: 1;  // Port C higher nibble
		__u8 PADir    : 1;  // Port A
		__u8 Reserved2: 3;
	};
}GROUP_CTRL_REG;

// interrupt control & status register
#define INT_DISABLED          0
#define INT_SRC_PC0           1
#define INT_SRC_PC0_WITH_GATE 2
#define TRIG_EDGE_RISING      1  // rising edge. note: this is the device specified value.
#define TRIG_EDGE_FALLING     0  // falling edge. note: this is the device specified value.
typedef union _DEV_INT_CSR{
	__u8 Value;
   struct{
		__u8 PmEnable  :1; //enable pattern match function
		__u8 PmFlag    :1;    // pattern match interrupt status  when read: 1 -- interrupt occurred; 0 -- no interrupt
                                                    //when write: 1 -- clear interrupt; 0 -- don't care
		__u8 CosEnable :1;//enable change of status function
		__u8 CosFlag   :1;  //change of status interrupt status

		__u8 GrpMode   :2;  // Group X interrupt mode. see INT_xxx definition.
		__u8 GrpEdge   :1;  // Group X interrupt trigger edge. see TRIG_EDGE_xxx definition.
		__u8 GrpFlag   :1;  // Group X  interrupt status
                        // when read: 1 -- interrupt occurred; 0 -- no interrupt
                        // when write: 1 -- clear interrupt; 0 -- don't care
   };
}DEV_INT_CSR;

#define STOP_INTERRUPT          0Xca
#define DEV_INT_MASK            0x80  // for fast detect the interrupt status
#define DEV_INT_SNAP_FALG_MASK  0x8a
#define DEV_INT_COS_PM_MASK     0x05
#define DR_IntCSR_START_ADDR    0x10
#define DR_IntCSR_START_ADDR_E  0x30
#define DEV_COS_FLAG_MASK       0xf7
#define DEV_PM_FLAG_MASK        0xfd
#define DEV_NO_DEFINE_MASK      0xf0
#define DR_COS_CHAN1753    0X1C
#define DR_COS_CHAN1753E   0X3C
#define DR_PM_CHAN1753     0X18
#define DR_PM_CHAN1753E    0X38
#define DR_PM_VALUE1753    0X14
#define DR_PM_VALUE1753E   0X34

// EEPROM register definition
#define EEPROM_DELAY_US      1000
#define EEPROM_WRITE_OK      0x80
#define EEPROM_READ_OK       0x40
#define EEPROM_TRIGGER_WRITE 0x7f
#define EEPROM_TRIGGER_READ  0x80


#endif /* _KERNEL_MODULE_HW_H_ */
