/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

uint32 const s_dioGroupRegOffset[] = {
   DR_GroupX_Ctrl( 0), DR_GroupX_Ctrl( 1 ), DR_GroupX_Ctrl( 2 ), DR_GroupX_Ctrl( 3 ),
   DR_GroupX_Ctrl(8 ), DR_GroupX_Ctrl( 9),  DR_GroupX_Ctrl( 10 ),DR_GroupX_Ctrl( 11 ),
};

//
// For Fast Access DIO port Data register
uint32 const s_dioPortRegOffset[] = {
   DR_GroupX_PortY( 0, 0 ), DR_GroupX_PortY( 0, 1 ), DR_GroupX_PortY( 0, 2 ),
   DR_GroupX_PortY( 1, 0 ), DR_GroupX_PortY( 1, 1 ), DR_GroupX_PortY( 1, 2 ),
   DR_GroupX_PortY( 2, 0 ), DR_GroupX_PortY( 2, 1 ), DR_GroupX_PortY( 2, 2 ),
   DR_GroupX_PortY( 3, 0 ), DR_GroupX_PortY( 3, 1 ), DR_GroupX_PortY( 3, 2 ),

   DR_GroupX_PortY( 8, 0 ), DR_GroupX_PortY( 8, 1 ), DR_GroupX_PortY( 8, 2 ),
   DR_GroupX_PortY( 9, 0 ), DR_GroupX_PortY( 9, 1 ), DR_GroupX_PortY( 9, 2 ),
   DR_GroupX_PortY( 10, 0 ),DR_GroupX_PortY( 10, 1 ),DR_GroupX_PortY( 10, 2 ),
   DR_GroupX_PortY( 11, 0 ),DR_GroupX_PortY( 11, 1 ),DR_GroupX_PortY( 11, 2 ),
};

__u8 * IsrSnapDiPorts( uint32 ioBase, __u8 buffer[ DIO_PORTS_COUNT_MAX ],DI_SNAP_CONFIG snapPara )
{
   uint32 i;
   __u8 * ptr = &(buffer[snapPara.portStart]);

   for ( i = snapPara.portStart; i < snapPara.portStart + snapPara.portCount; ++i, ++ptr )
   {
      *ptr = AdxIoInB( ioBase, s_dioPortRegOffset[i] );
   }
   return buffer;
}

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   __u32 i;
   unsigned long flags;
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   __u32   intCsrs[DI_SNAP_SRC_COUNT_MAX];
   uint32 intScrUpDownCount = 6;
   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   for(i = 0; i < DI_SNAP_SRC_COUNT_MAX; ++i)
   {
      intCsrs[i] = shared->IntCsr[i];
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   //pci1753 has 6 interrupt snap sources:4 DI + 1 DIPM + 1 DICOS

   //get intCos flag and intPm flag for pci1753/pcm3753
   //the register format of pci1753/pcm3753 is:
   //         interrupt_flag |trigger_edge |    mode   | intcos_flag| cos_enable|  intpm_flag| pm_enable|
   // base+16      F0        |     E0      |   M01 M02 |    F02     |     M2    |     F01    |     M1   |
   // base+17      F1        |     E1      |   M01 M02 |     -      |     -     |     -      |     -    |
   // base+18      F2        |     E2      |   M01 M02 |     -      |     -     |     -      |     -    |
   // base+19      F3        |     E3      |   M01 M02 |     -      |     -     |     -      |     -    |
   intCsrs[4] = intCsrs[0]&0x02;
   intCsrs[5] = intCsrs[0]&0x08;
   intCsrs[0] = intCsrs[0]&0xf0;
   if ( 1 == shared->isExpBoardOn )
   {
      //get intCos flag and intPm flag for pci1753E
      intCsrs[10] = intCsrs[6]&0x02;
      intCsrs[11] = intCsrs[6]&0x08;
      intCsrs[6] = intCsrs[6]&0xf0;
      intScrUpDownCount += 6;//pci1753E has 6 interrupt snap sources.
   }

   for ( i = 0; i < intScrUpDownCount; i++ )
   {
      if ( intCsrs[i] & DEV_INT_SNAP_FALG_MASK )
      {
         //if the interrupt flag is true,get data and signal event.
         IsrSnapDiPorts( shared->IoBase, shared->DiSnapState[i].state ,shared->DiSnapParam[i] );

         if ( !shared->IsEvtSignaled[EvtDiintChan016Idx + i] )
         {
            shared->IsEvtSignaled[ EvtDiintChan016Idx + i] = 1;
            daq_device_signal_event( daq_dev, ( EvtDiintChan016Idx + i ) );
         }
      }
   }
}


uint32 IsrSnapInterruptState( uint32 * csrBuf,uint32 csrRegBase,uint32 count)
{
   uint32 i;
   uint32 isIntOccurred = 0;
   for (  i = 0 ; i < count ; ++i,++csrBuf )
   {
      *csrBuf = AdxIoInB( csrRegBase, i);
      if ( *csrBuf & DEV_INT_SNAP_FALG_MASK )
      {
         // clear the interrupt
         AdxIoOutB( csrRegBase, i, *csrBuf );
         isIntOccurred = 1;
      }
   }
   return isIntOccurred;
}



irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   // for DI interrupt
//   __u32 i;
   __u32 isIntOn;

   isIntOn = IsrSnapInterruptState( &shared->IntCsr[0],shared->IoBase + DR_IntCSR_START_ADDR,4);
   if ( shared->isExpBoardOn )
   {
      //skip DiPm0 and DiCos0 IntCsr,because the flags of them are in  register with DiInterrupt 0
      //we set intCsr start with 6
      if ( IsrSnapInterruptState(&shared->IntCsr[6],shared->IoBase + DR_IntCSR_START_ADDR_E ,4))
      {
         isIntOn = 1;
      }
   }

   if (!isIntOn) {
      return IRQ_RETVAL(0);
   }

   tasklet_schedule(&daq_dev->dio_tasklet);

   return IRQ_RETVAL(1);
}



