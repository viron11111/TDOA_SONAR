/*
 * dio.c
 *
 *  Created on: 2012-8-10
 *      Author: W
 */
#include "kdriver.h"
#include "hw.h"

static
void daq_dio_set_port_dir(DEVICE_SHARED *shared)
{
   DIO_CHL_CSR csr;
   int i = 0;
   csr.Value = AdxMemInW(shared->IoMemBase, DR_DIO_MODE_PORT0);
   csr.Port0Mode = shared->DioPortDir[0] == Input ? PORTDIR_IN : PORTDIR_OUT;
   csr.Port1Mode = shared->DioPortDir[1] == Input ? PORTDIR_IN : PORTDIR_OUT;
   AdxMemOutW(shared->IoMemBase, DR_DIO_MODE_PORT0, csr.Value);

   //
   // if not keep last, initialize DO port value.
   //
   if ( shared->InitOnLoad )
   {
      //
      // It's no need to check direction, any value written to a DI port
      // has no effect on both the port and HW register.
      //
      for ( i = 0; i < DIO_PORT_COUNT; i++ )
      {
         AdxMemOutB(shared->IoMemBase, DR8_DIO_PORT(i), shared->DoPortState[i]);
      }
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   daq_dio_set_port_dir(&daq_dev->shared);
}

int daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   DIO_SET_PORT_DIR xbuf;
   __u8             dirs[DIO_PORT_COUNT];
   unsigned         i;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PortCount > DIO_PORT_COUNT)){
      return -EINVAL;
   }

   if (unlikely(xbuf.PortStart + xbuf.PortCount > DIO_PORT_COUNT)){
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dirs, (void *)xbuf.Dirs, xbuf.PortCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PortCount; ++i){
      shared->DioPortDir[xbuf.PortStart + i] = dirs[i];
   }
   daq_dio_set_port_dir(shared);

   return 0;
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORT_COUNT;
      data[i] = AdxMemInB(daq_dev->shared.IoMemBase, DR_DIO_DATA_PORT0 + port);
   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.PortCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORT_COUNT;
      AdxMemOutB(daq_dev->shared.IoMemBase, DR_DIO_DATA_PORT0 + port, data[i]);
   }

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       data, status;
   unsigned   port, bit;
   unsigned long flags;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   port = xbuf.Port % DIO_PORT_COUNT;
   bit  = xbuf.Bit;
   data = xbuf.Data;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   status = AdxMemInB(daq_dev->shared.IoMemBase, DR_DIO_DATA_PORT0 + port);
   status = ((data & 0x1) << bit) | (~(1 << bit) & status);
   AdxMemOutB(daq_dev->shared.IoMemBase, DR_DIO_DATA_PORT0 + port, status);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
 
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   return daq_ioctl_di_read_port(daq_dev, arg);
}
