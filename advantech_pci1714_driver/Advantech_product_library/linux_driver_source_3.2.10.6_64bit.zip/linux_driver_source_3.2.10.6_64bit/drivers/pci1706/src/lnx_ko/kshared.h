/*
 * kshared.h
 *
 *  Created on: 2012-06-04
 *      Author: W
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>

#include "hw.h"

#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1706
#define DEVICE_PID    BD_PCI1706U
#define DEVICE_NAME   "PCI-1706"
#define DRIVER_NAME   "bio1706"

#define IOCTL_DEVICE_HOTRESET_GET_STATUS             _IO(BDAQ_DEV_MAGIC, 50)
#define IOCTL_DEVICE_HOTRESET_SET_STATUS             _IO(BDAQ_DEV_MAGIC, 51)


//////////////////////////////////////////////////////////////////////////
// rename SigAmsiPinX
#define  SigAmsiTrigger    SigAmsiPin0
#define  SigAmsiConvClock  SigAmsiPin4
#define  SigAmsiScanClock  SigAmsiPin5

#define IS_DEVICE_GROUPED( ProductID, GroupID )   ( (BD_PCI1706MSU == (ProductID)) && ((GroupID) > 0) )

#define IS_AO_SUPPORTED( ProductID )     ((ProductID) != BD_PCI1706UL)


// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             8

#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        (AI_CHL_COUNT / 2)
#define AI_CHL_MASK              (AI_CHL_COUNT - 1) 

#define AI_RES_IN_BIT            32
#define AI_RESOLUTION_IN_BIT             16 

#define AI_DATA_SIZE             sizeof(uint32)
#define AI_DATA_MASK             0xFFFF0000

#define AI_GAIN_V_Neg10To10        0
#define AI_GAIN_V_Neg5To5          1
#define AI_GAIN_V_Neg2pt5To2pt5    2
#define AI_GAIN_V_Neg1pt25To1pt25  3

#define AI_CLK_BASE              (10*1000*1000)       // 10MHz clock
#define AI_MAX_PACER             (250*1000)           // 250KHz
#define AI_MIN_PACER             (1)
#define AI_FIFO_SIZE             1024                 // Ai fifo size in samples.

#define AI_MAX_SAMPLE_RATE	(250*1000)           // 250KHz
#define AI_MIN_SAMPLE_RATE	(1)

#define TRIGGER_MAX_DELAY (0xFFFFFFFF)           //2^32 - 1 
#define TRIGGER_MIN_DELAY (1)

#define ScanCountMax		(0xFFFFFFFF)

#define SAI_TIMEOUT_VAL          100  // 1000ms time-out value for each sample reading.
#define SAI_DELAY_TIME           10    // 10us delay before reading data

#define AI_TRIG_COUNT            1

#define AI_DMA_ENABLE    1
#define AI_DMA_DISABLE   0

// ----------------------------------------------------------
// AO default values
// ----------------------------------------------------------
#define VOLTAGE 0
#define CURRENT 1

#define AO_CHL_COUNT          2
#define AO_CHL_MASK           (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT         12
#define AO_DATA_SIZE          sizeof(__u32)
#define AO_DATA_MASK          0xFFF0

#define DEF_AO_GAIN             V_0To5
#define DEF_AO_MODE             VOLTAGE
#define DEF_AO_DATA             0x0

#define DEF_AO_INIT_STATE       0



// ----------------------------------------------------------
// DIO default values
// ----------------------------------------------------------
#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

#define DEF_DIO_DIR             0x00
#define DEF_DO_STATE            0x00


// ----------------------------------------------------------
// Counter default values
// ----------------------------------------------------------
#define CNTR_CHL_COUNT           2
#define CNTR_RES_IN_BIT          32
#define CNTR_DATA_SIZE           sizeof(int)
#define CNTR_MIN_VAL             0
#define CNTR_MAX_VAL             0xFFFFFFFF
#define CNTR_CLK_BASE            20000000UL
#define CNTR_IDLE                0

#define DEF_CNTR_CHIP_CLKSRC    SigInternal20MHz
#define DEF_CNTR_CHIP_LOADVAL   0xFFFFFFFF
#define DEF_CNTR_CHIP_OPMODE    C1780_MD//0
#define DEF_CNTR_OST_CLKSRC     SigInternalClock
#define DEF_CNTR_OST_DELAYCNT   0xFFFFFFFF
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      50

#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       (10000000UL)
#define CNTR_CHK_PERIOD_MAX_NS   (10000000000UL >> 4)
#define CNTR_VAL_THRESHOLD_BASE  10

//counter frequency selection
#define CNTR_FREQ_2K     2000
#define CNTR_FREQ_20K    20000
#define CNTR_FREQ_200K   200000
#define CNTR_FREQ_2M     2000000
#define CNTR_FREQ_10M    10000000
#define CNTR_FREQ_20M    20000000

//counter base frequency selection
#define CNTR_BASEFREQ_2      2
#define CNTR_BASEFREQ_20     20
#define CNTR_BASEFREQ_200    200
#define CNTR_BASEFREQ_2K     2000

//counter clock source selection
#define CNTR_CLOCK_SOURCE_CLK_N   0x0
#define CNTR_CLOCK_SOURCE_CLK_N1  0x1
#define CNTR_CLOCK_SOURCE_OUT_N1  0x2
#define CNTR_CLOCK_SOURCE_GATE_N  0x3
#define CNTR_CLOCK_SOURCE_20M     0x4
#define CNTR_CLOCK_SOURCE_2M      0x5
#define CNTR_CLOCK_SOURCE_200K    0x6
#define CNTR_CLOCK_SOURCE_20K     0x7
#define CNTR_CLOCK_SOURCE_2K      0x8
#define CNTR_CLOCK_SOURCE_200     0x9
#define CNTR_CLOCK_SOURCE_20      0xA
#define CNTR_CLOCK_SOURCE_2       0xB
#define CNTR_CLOCK_SOURCE_NONE    0xC

//counter gate source selection
#define CNTR_GATE_SOURCE_GATEN     0x0
#define CNTR_GATE_SOURCE_GATE_N1   0x1
#define CNTR_GATE_SOURCE_OUT_N1    0x2
#define CNTR_GATE_SOURCE_RESERVED  0x3
#define CNTR_GATE_SOURCE_2K        0x4
#define CNTR_GATE_SOURCE_200       0x5
#define CNTR_GATE_SOURCE_20        0x6
#define CNTR_GATE_SOURCE_2         0x7

//counter up/dowm mode
#define CNTR_MODE_DOWN         0x0
#define CNTR_MODE_UP           0x1

//counter rising/falling edge
#define CNTR_EDGE_RISING   0x0
#define CNTR_EDGE_FALLING	0x1

// Gate Polarity

#define GP_HIGH_RISING  0x0
#define GP_LOW_FALLING  0x1


//counter once/repetitively mode
#define CNTR_MODE_ONCE           0x0
#define CNTR_MODE_REPETITIVELY   0x1

//counter reload mode
#define CNTR_MODE_FROM_LOAD         0x0
#define CNTR_MODE_FROM_HOLD         0x1

//counter output mode
#define CNTR_OUTPUT_HIGH_PULSE  0x0
#define CNTR_OUTPUT_LOW_PULSE   0x1
#define CNTR_OUTPUT_LOW_TTL     0x2
#define CNTR_OUTPUT_HIGH_TTL    0x3

//counter output enable
#define CNTR_OUTPUT_DISENABLE   0x0
#define CNTR_OUTPUT_ENABLE      0x1

//counter gate mode
#define CNTR_GATE_MODE_NOGATE  0x0
#define CNTR_GATE_MODE_LEVEL   0x1
#define CNTR_GATE_MODE_EDGE    0x2
#define CNTR_GATE_MODE_PULSE   0x3

//counter gate polariy
#define CNTR_GATE_POLARIY_H 0x0
#define CNTR_GATE_POLARIY_L 0x1



//#define CHK_FREQUENCE_RANGE(freq, MIN, MAX)  if(freq >= MIN && freq < MAX)
enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,

   KdxAoDataTransed,
   KdxAoUnderrun,
   KdxAoTransStopped,
   KdxAoStopped,

   EvtCntTerminalCount0Idx,
   EvtCntTerminalCount1Idx,
   EvtCntTimer0Idx,
   EvtCntTimer1Idx,
   EvtCntOneShot0Idx,
   EvtCntOneShot1Idx,

   KrnlSptedEventCount,
   InvalidEventIdx = KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;

   case EvtCntTerminalCount0:       kdx = EvtCntTerminalCount0Idx; break;
   case EvtCntTerminalCount1:       kdx = EvtCntTerminalCount1Idx; break;
   case EvtCntTimer0:               kdx = EvtCntTimer0Idx; break;
   case EvtCntTimer1:               kdx = EvtCntTimer1Idx; break;
   case EvtCntOneShot0:             kdx = EvtCntOneShot0Idx; break;   
   case EvtCntOneShot1:             kdx = EvtCntOneShot1Idx; break;     
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           1 // differential
#define DEF_AI_GAIN             AI_GAIN_V_Neg10To10
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (100 * 100)
#define DEF_FAI_SECTSIZE        0//(AI_FIFO_SIZE / 2)
#define DEF_FAI_MODE            0

// Hysteresis Voltage const value
#define DEF_HYSTERESIS_VOLTAGE     0xF8

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   __u32  ScanClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;
   __u16  *UserBuffer;

#if 1  // added for pci1706  2012-6-20

   double ScanClkRatePerCH;
   __u32  ConvDivide;
   __u32  ScanDivide;
   __u16  HysteresisVoltage;
   __u32  DelayCount;
   __u32  ScanCount;
   double TriggerSourceLevel;
   __u32  TriggerSourceLevelBinary;

   DEV_TRIG_SOURCE_REG  TrigSource;
   DEV_TRIG_ACTIVE_REG  TrigActive;

   DEV_MSI_REG MsiModel;
#endif

}FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
}FAI_STATUS;

typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------

   __u32 BaseFreq[CNTR_CHL_COUNT];

   
   // properties for Primal Counter

   __u32  ChipClkPolarity[CNTR_CHL_COUNT];   // CFG_ChipClkPolarityOfCounters
   __u32  ChipCntType[CNTR_CHL_COUNT]; 	     // CFG_ChipSignalCountingTypeOfCounters
   __u32  ChipGateSrc[CNTR_CHL_COUNT]; 	     // CFG_ChipGateSourceOfCounters
   __u32  ChipGatePolarity[CNTR_CHL_COUNT];  // CFG_ChipGatePolarityOfCounters
   __u32  ChipOutSignal[CNTR_CHL_COUNT];	 // CFG_ChipOutSignalOfCounters
   __u32  ChipHoldValue[CNTR_CHL_COUNT]; 	     // CFG_ChipHoldValueOfCounters   
   __u32  ChipClkSource[CNTR_CHL_COUNT];
   __u32  ChipOpMode[CNTR_CHL_COUNT];
   __u32  ChipLoadValue[CNTR_CHL_COUNT];

   // ----TimerPulse----------------------------------------------------
   __u32   TmGateEnable[CNTR_CHL_COUNT];
   __u32   TmGatePolarity[CNTR_CHL_COUNT];
   __u32   TmOutSignal[CNTR_CHL_COUNT];
   __u32   TmrFreqDiv[CNTR_CHL_COUNT];
   // ----EventCount----------------------------------------------------
   __u32   EcClockPolarity[CNTR_CHL_COUNT];    // CFG_EcClkPolarityOfCounters
   __u32   EcGateEnable[CNTR_CHL_COUNT];       // CFG_EcGateEnabledOfCounters
   __u32   EcGatePolarity[CNTR_CHL_COUNT];     // CFG_EcGatePolarityOfCounters
   // ----OneShot----------------------------------------------------
   __u32  OstDelayCount[CNTR_CHL_COUNT];
   __u32  OstClkSource[CNTR_CHL_COUNT];
   __u32  OsClkPolarity[CNTR_CHL_COUNT];
   __u32   OstGateSource[CNTR_CHL_COUNT];
   __u32   OstGatePolarity[CNTR_CHL_COUNT];
   __u32	  OstOutSignal[CNTR_CHL_COUNT];

   // properties for Frequency Measurement
   __u32  FmMethod[CNTR_CHL_COUNT];		  // CFG_FmMethodOfCounters
   __u32  FmPeriod[CNTR_CHL_COUNT]; 	  // CFG_FmCollectionPeriodOfCounters, unit in ms

   // properties for Pulse width modulation
   __u32  PoGateEn[CNTR_CHL_COUNT];		  // CFG_PoGateEnabledOfCounters
   __u32  PoGatePolarity[CNTR_CHL_COUNT];	  // CFG_PoGatePolarityOfCounters
   __u32  PoHighDiv[CNTR_CHL_COUNT];		  // CFG_PoHiPeriodOfCounters
   __u32  PoLowDiv[CNTR_CHL_COUNT];		  // CFG_PoLoPeriodOfCounters

}CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     Overflow;
   __u32     PrevValue;
   __u32     BaseFreq;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
}CNTR_STATE;


typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       GroupId;
   bool        IsMSUSlave;
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       BrBase;
   __u32       BrLength;
   __u32       IoBase;
   __u32       IoLength;
   __u32       HardwareVer;
   void		   *BrMemBase;
   void        *IoMemBase;
   __u32       Irq;
   __u32       InitOnLoad;

   double   DevWaitForSleepTime;   //Waiting time for entering sleep
   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;

   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u16       AoChanMode[AO_CHL_COUNT];
   __u16       AoChanRawData[AO_CHL_COUNT];
   double      AoChanDoubleData[AO_CHL_COUNT];
   double      AoExtRefUnipolar;
   double      AoExtRefBipolar;
   __u16       AoChanState[AO_CHL_COUNT];


   // --------------------------------------------------------
   __u8        DioPortDir[DIO_PORT_COUNT];
   __u8        DoPortState[DIO_PORT_COUNT];

   // --------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;
   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
