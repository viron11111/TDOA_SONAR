/*
 * ao.c
 *
 *  Created on: 2012-8-10
 *      Author: W 
 */
#include "kdriver.h"
#include "hw.h"

static inline
unsigned daq_ao_build_chan_map(unsigned start, unsigned count)
{
   #if AO_CHL_COUNT > 32
   #error AO channel count exceeds the limitation of the algorithm! Please modify the algorithm at first.
   #endif

   #define BUILD_CH_MAP(start, count)   (((1 << (count)) - 1) << (start))

   if (start + count <= AO_CHL_COUNT) {
      return BUILD_CH_MAP(start, count);
   } else {
      return BUILD_CH_MAP(start, AO_CHL_COUNT - start) | BUILD_CH_MAP(0, start + count - AO_CHL_COUNT);
   }
}

static inline
int daq_ao_chan_available(DEVICE_SHARED *shared, unsigned start, unsigned count)
{
   unsigned sao_ch;
   
   sao_ch = daq_ao_build_chan_map(start, count);
   return sao_ch == 0;
}

static inline
void  daq_ao_fill_chan_csr(unsigned chan, unsigned gain, AO_CHL_CSR *csr)
{
   switch (gain)
   {
   case V_0To5      : 
							csr->CHx_Gain = 0; 
		    				csr->CHx_Mode = VOLTAGE;
						   break;

   case V_0To10     : 
							csr->CHx_Gain = 1; 
		    				csr->CHx_Mode = VOLTAGE;
							break;

   case V_Neg5To5   : csr->CHx_Gain = 2; 
		    				csr->CHx_Mode = VOLTAGE;
							break;

   case V_Neg10To10 : csr->CHx_Gain = 3;
		    				csr->CHx_Mode = VOLTAGE;
							break;

   case mA_4To20    : csr->CHx_Gain = 1;
		    				csr->CHx_Mode = CURRENT;
							break;

   case mA_0To20    : csr->CHx_Gain = 2;
		    				csr->CHx_Mode = CURRENT;
							break;

   case mA_0To24    : csr->CHx_Gain = 3;
		    				csr->CHx_Mode = CURRENT;
							break;

   default:          break; 
   }
   
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_CHL_CSR    csr     = {0};
   int           i;

   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_fill_chan_csr(i, shared->AoChanGain[i], &csr);
      AdxMemOutB(shared->IoMemBase, DR8_AO_CTRL(i), csr.Value);      
  

  	  if( shared->InitOnLoad )
   	  {
   	    AdxMemOutW(shared->IoMemBase, DR16_AO_DATA(i), shared->AoChanRawData[i]);
   	  }
    }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }
   if (xbuf.SetWhich & AO_SET_EXTREFBI) {
      memcpy(&shared->AoExtRefBipolar, &xbuf.ExtRefBipolar, sizeof(shared->AoExtRefBipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      AO_CHL_CSR csr;
      __u32      i, ch, gains[AO_CHL_COUNT];

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      csr.Value = AdxMemInW(shared->IoMemBase, DR_AO_BASE);
      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
         daq_ao_fill_chan_csr(ch, gains[i], &csr);
      	// Set AO channel configuration
      	AdxMemOutB(shared->IoMemBase, DR8_AO_CTRL(i), csr.Value);
      }

   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;
	__u16				  aoBinaryValue;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }

   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   for(i = 0; i < xbuf.ChanCount; ++i)
   {
      ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
		aoBinaryValue = (data[i] << 4) & AO_DATA_MASK;
      AdxMemOutW(shared->IoMemBase, DR16_AO_DATA(ch), aoBinaryValue);
	  AdxMemOutB(shared->IoMemBase, DR8_AO_TRIG(ch), 1);
   }

   return 0;
}

