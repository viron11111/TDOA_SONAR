/*
 * hw.h
 *
 *  Created on: 2012-06-04
 *      Author: W 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#ifndef BIT
#define BIT(n)  (1<<(n))
#endif

// device register : AI Data
#define DR_AI_DATA        0x40
#define DR_AI_SWTRIG      0x0

// device register : AO Data
#define DR_AO_DATA_BASE   0x6A

typedef union _AI_CHL_CTL{
   __u32 Value;
   struct{
      struct{
         __u16 Gain  : 2;
         __u16 DMA_Enable  : 1;
         __u16 Trigger   : 1; // 3,     Trigger flag
         __u16 D2Stop    : 1; // 4,     Invalid data after delay count (DelayToStop)
         __u16 Reserved1 : 3; // 7:5,   Reserved  
         __u16 ChNum     : 3; // 10:8,  Channel number
         __u16 Reserved2 : 5; // 15:11, Reserved
      };
      __u16 Data;
   }Fields;
   
}AI_CHL_CTL,*PAI_CHL_CTL;

#define DR_AI_CHCTL       0x2

typedef union _FIFO_DMARQ_CTL{
   __u16 Value;
   struct{
      __u16 unused1  : 7;
      __u16 DMA_Request  : 1;
      __u16 Clear_FIFO  : 1;
      __u16 unused2  : 7;
   };
}FIFO_DMARQ_CTL;

#define DR_AI_MUX         0x4

#define DEV_CTL_SW_TRIG   1

typedef union _DEV_CTL_STA{
   __u16 Value;
   struct{
      __u16 Tri    : 1;
      __u16 Ent    : 1;
      __u16 unused1   : 14;
   };
}DEV_CTL_STA;

typedef union _DEV_INT_CONTROL{
   __u16 Value;
   struct{
      __u16 FifoAlmostFull : 1;
      __u16 FifoFull  : 1;
      __u16 AiStopByHw  : 1;
      __u16 Count0    : 1;
      __u16 Count1    : 1;
      __u16 unused1   : 11;
   };
}DEV_INT_CONTROL;

typedef union _DEV_TRIG_SOURCE_REG{
   __u16 Value;
   struct{
   __u16 TrigSource   : 4;
   __u16 TrigMode     : 2;
   __u16 unused     : 2;
   __u16 ScanClock    : 4;
   //__u16 unused1    : 2;
   __u16 ConvClock    : 4;
   //__u16 unused2    : 2;
   };
}DEV_TRIG_SOURCE_REG;

typedef union _DEV_TRIG_ACTIVE_REG{
   __u16 Value;
   struct{
   __u16 TrigChannel   : 3;
   __u16 unused     : 5;
   __u16 AnalogFR    : 1;
   __u16 unused1    : 3;
   __u16 DigitalFR    : 1;
   __u16 unused2    : 3;
   };
}DEV_TRIG_ACTIVE_REG;

typedef union _AO_CHL_CSR{
   __u16 Value;
   struct{
      __u16 CHx_Gain : 2;
      __u16 CHx_Mode : 1;
   	__u16 unused1  : 1;
   	__u16 Trig_Mode: 1;
   	__u16 unused2  : 3;
   	__u16 Trig_Bit : 1;
   	__u16 unused3  : 7;
   };
}AO_CHL_CSR;

typedef union _DIO_CHL_CSR{
   __u16 Value;
   struct{
	__u16 Port0Mode  : 8;
	__u16 Port1Mode  : 8;
	};
}DIO_CHL_CSR;


typedef union _COUNTER_CHL_CSR{
   __u32 Value;
   struct{
   __u32 CounterMode			 : 1;
   __u32 CounterEdge			 : 1;
   __u32 CounterRepe        : 1;
   __u32 CounterReload      : 1;
   __u32 CounterOutputMode  : 2;
   __u32 unused1   : 1;
   __u32 CounterOutputEnable : 1;
   __u32 CounterClkSource    : 4;
   __u32 unused2   : 4;
   __u32 CounterGateMode     : 2;
   __u32 unused3   : 2;
   __u32 CounterGatePolarity : 1;
   __u32 unused4   : 3;
   __u32 CounterGateClkSource: 3;
   __u32 unused5   : 5;
	};
}COUNTER_CHL_CSR;

typedef union _COUNTER_CMD_CSR{
   __u16 Value;
   struct{
   __u16 CmdCode   : 3;
   __u16 unused1   : 13;
	};
}COUNTER_CMD_CSR;

typedef enum tagCounterCmd{
	DISARM = 0,
	LOADFROMLOAD,
	SAVETOHOLD,
	STEPCOUNTER,
	ARMCOUNTER,
	RESETCOUNTER = 7,
}CounterCmd;


//AI Register
#define DR_STATUS    0x24
#define DR_CONTROL	0x00

#define DR_CONTROL_CH0        0x00
#define DR_STATUS_CH0         0x00

// AI channel setting
#define DR32_AI_CHANNEL(n) ((n)*4)


#define DR_EN_INTR       0x20
typedef union _INT_EN_REG {
    struct {
        __u16 EnFifoAF      : 1; // 0, FIFO Almost full
        __u16 EnFifoFF      : 1; // 1, FIFO Full
        __u16 EnAiStopByHw  : 1; // 2, Delay to stop
        __u16 EnCntr0       : 1; // 3, Counter0
        __u16 EnCntr1       : 1; // 4, Counter1
        __u16 Reserved      : 11;
    }Fields;

    __u16  Value;

} INT_EN_REG, *PINT_EN_REG;


#define DR_INTR_FLAG     0x22

#define DR_EN_AIWORK       0x24

#define DR_TRIG_SOURCE      0x26

#define DR_TRIG_DELAY_COUNT       0x28

#define DR_SCAN_DIV	0x2C

#define DR_CONV_DIV	 0x30
#define DR_CONV_COUNTER  0x34

#define DR_TRIG_ACTIVE  0x38

#define DR8_AI_TRIG_EDGE    57

#define DR_TRIG_VOL  	0x3A

#define DR_HYST_VOL 	 0x3C
#define HYSTERSIS_VOLTAGE_VALUE    0x78

#define DR_FIFO_DATA  	0x40
#define DR_FIFO_USED  	0x44
#define DR_FIFO_CONTROL 0x46

typedef union _AI_FIFO_CSR {
    struct  
    {
        __u16 AlmostFull     : 1;  // 0, Almost full flag
        __u16 Full           : 1;  // 1, Full flag
        __u16 Reserved0      : 2;
        __u16 AlmostEmpty    : 1;  // 4, Almost empty flag
        __u16 Empty          : 1;  // 5, Empty flag
        __u16 Reserved1      : 1;
        __u16 DREQ           : 1;  // 7, DMA request enable
        __u16 Clear          : 1;  // 8, Clear FIFO
        __u16 Reserved2      : 7;
    } Fields;
    
    __u16  Value;

}AI_FIFO_CSR, *PAI_FIFO_CSR;


#define DR_MSI_CLKDIV 	0x4C
#define DR_MSI_DIV  	   0x50
#define DR_MSI_SOURCE  	0x58

#define DR_CLR_INTR      0x8
#define DR_CLR_FIFO      0x9

#define DR_BID           0x48
typedef union _DEV_INFO_REG {
    struct {
        __u16 BoardID      : 4;  // 3:0, BoardID
        __u16 GroupID      : 4;  // 7:4, GroupID
        __u16 Master       : 1;  // 8, master
        __u16 Reserved1    : 3;
        __u16 HotReset     : 1;  // 12
        __u16 Reserved2    : 3;
    }Fields;

    __u16 Value;

}DEV_INFO_REG, *PDEV_INFO_REG;


#define DR_CNTR0       0x18
#define DR_CNTR1       0x1A
#define DR_CNTR2       0x1C
#define DR_CNTR_CTL    0x1E

#define AI_GAIN_CHANGE       0xB4
#define AI_GAIN_CHG_VALUE    0x0100

// AO Register
#define DR_AO_CONTROL       0x68
#define DR_AO_DATA          0x6A
#define AO_TRIG_BIT         0x0100

#define DR_AO_BASE			104
#define DR8_AO_CTRL(n)		((n)*4 + DR_AO_BASE)
#define DR8_AO_TRIG(n)		((n)*4 + DR_AO_BASE + 1)
#define DR16_AO_DATA(n)	((n)*4 + DR_AO_BASE + 2)



// DIO Register
#define DR_DIO_MODE_PORT0   0x70
#define DR_DIO_MODE_PORT1   0x71
#define DR_DIO_DATA_PORT0   0x72
#define DR_DIO_DATA_PORT1   0x73

#define PORTDIR_OUT   0xFF
#define PORTDIR_IN    0x00

#define DR8_DIO_PORT(n)     ((n)+DR_DIO_DATA_PORT0)   


// COUNTER Register
#define DR_COUNTER0_MODE     0x78
#define DR_COUNTER1_MODE     0x7C

#define DR_COUNTER0_LOAD     0x80
#define DR_COUNTER1_LOAD     0x84

#define DR_COUNTER0_HOLD     0x88
#define DR_COUNTER1_HOLD     0x8C

#define DR_COUNTER0_CMD     0x90
#define DR_COUNTER0_ENABLE  0x92

#define DR_COUNTER1_CMD     0x94
#define DR_COUNTER1_ENABLE  0x96

#define DR_COUNTER0_DATA       0x98

#define ENABLE_COUNTER  0x01

#define CNT_CMD_DISARM  0x000
#define CNT_CMD_LOAD    0x001
#define CNT_CMD_SAVE    0x002
#define CNT_CMD_STEP    0x003
#define CNT_CMD_ARM     0x004
#define CNT_CMD_RESET   0x007

typedef enum _AI_CLK_SRC {
    AI_CLK_10M = 0,
    AI_CLK_EXT,
    AI_CLK_AMSI,
    AI_CLK_NONE,
}AI_CLK_SRC;


typedef enum _AI_TRIG_SRC {
    AI_TRIG_SOFT = 0,
    AI_TRIG_ANALOG,
    AI_TRIG_EXT,
    AI_TRIG_NONE,
    AI_TRIG_AMSI0 = 8
}AI_TRIG_SRC;



///////////////////////////////////MSI///////////////////////////////////////
// MSI clock line 0/1 direction, source and divider
#define DR8_MSICLK0_SRC         76
#define DR8_MSICLK0_DIR         77
#define DR8_MSICLK1_SRC         78
#define DR8_MSICLK1_DIR         79
#define DR32_MSICLK0_DIV        80
#define DR32_MSICLK1_DIV        84

// MSI trigger line 0 direction, source
#define DR8_MSITRG0_SRC         88
#define DR8_MSITRG0_DIR         89

typedef union _DEV_MSI_REG {
    __u16 Value;
    struct {
        __u16 CnvClkSrc      : 2;  
        __u16 CnvClkDir      : 2;  
        __u16 ScnClkSrc      : 2;  
        __u16 ScnClkDir    : 2;
        __u16 TrigSrc     : 2;  
        __u16 TrigDir    : 2;
        __u16 Reserved       :4;
    };

}DEV_MSI_REG, *PDEV_MSI_REG;


typedef enum _MSI_DIR
{
    MSI_INPUT = 0,
    MSI_OUTPUT
} MSI_DIR;

typedef enum _MSI_TRIG_SRC {
    MSI_TRIG_SOFT = 0,
    MSI_TRIG_ANALOG,
    MSI_TRIG_EXT,
    MSI_TRIG_NONE,
} MSI_TRIG_SRC;

typedef enum _MSI_CLK_SRC {
    MSI_CLK_10M = 0,
    MSI_CLK_EXT_CONV,
    MSI_CLK_EXT_SCAN,
    MSI_CLK_NONE,
} MSI_CLK_SRC;



#endif /* _KERNEL_MODULE_HW_H_ */
