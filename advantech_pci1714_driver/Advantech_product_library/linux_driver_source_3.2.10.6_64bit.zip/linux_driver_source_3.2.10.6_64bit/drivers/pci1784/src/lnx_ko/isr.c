/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"


/************************************************************************
   handlers for interrupt sources the device supported
************************************************************************/
static inline 
void daq_timer_int_tasklet(daq_device_t *daq_dev, DEVICE_SHARED *shared, __u32 active)
{
   CNTR_SNAP *snap;
   unsigned  i;

   if (active) {
      snap = &shared->CntrSnap[KdxCntTimer4 - KdxCntBegin];
      
      for (i = 0; i < CNTR_UDCHL_COUNT; ++i) {
         if (daq_dev->CntrCtl[i].TmrLatch == 1) {
            snap->State[i] = AdxIoInD(shared->IoBase, DR_CNTRX_DATA(i));
         }
      }

      if (!shared->IsEvtSignaled[KdxCntTimer4]) {
         shared->IsEvtSignaled[KdxCntTimer4] = 1;
         daq_device_signal_event(daq_dev, KdxCntTimer4);
      }
   }
}

static inline 
void daq_ud_index_int_tasklet(daq_device_t *daq_dev, DEVICE_SHARED *shared, __u32 active)
{
   CNTR_SNAP *snap;
   __u32 i, j, mask, disabled = 0; 

   for (i = 0; active; active >>= 1, ++i) {
      if (active & 0x1) {
         snap = &shared->CntrSnap[i + KdxUdIndex0 - KdxCntBegin];

         // Latch the counters 
         mask = snap->Mask & (~(1 << i));
         AdxIoOutD(shared->IoBase, DR_SW_LATCH, mask);

         for (j = 0; j < CNTR_UDCHL_COUNT; ++j) {
            snap->State[j] = AdxIoInD(shared->IoBase, DR_CNTRX_DATA(j));
         }

         if (!shared->IsEvtSignaled[KdxUdIndex0 + i]) {
            shared->IsEvtSignaled[KdxUdIndex0 + i] = 1;
            daq_device_signal_event(daq_dev, KdxUdIndex0 + i);
         }

         // disable / enable index reset
         if (shared->CntrConfig.UdResetTimes[i] && shared->CntrConfig.UdResetTimes[i] != -1) {
            ++shared->CntrState[i].UdResetCount;
            if (shared->CntrState[i].UdResetCount >= shared->CntrConfig.UdResetTimes[i]) {
               disabled |= 1 << i;
            }
         }
      }
   }

   if (disabled) {
      daq_dev->CntrRst.ResetCntr   = 0;
      daq_dev->CntrRst.IdxResetEn &= ~disabled;
      AdxIoOutD(shared->IoBase, DR_CNTR_RESET, daq_dev->CntrRst.Value);
   }
}

static inline 
void daq_di_int_tasklet(daq_device_t *daq_dev, DEVICE_SHARED *shared, __u32 active)
{
   CNTR_SNAP *snap;
   __u32     i, j;

   for (i = 0; active; active >>= 1, ++i) {
      if (active & 0x1) {

         // snap DI
         if (shared->DiSnap[i].Count > 0)  {
            shared->DiSnap[i].State[0] = ((__u8)AdxIoInD(shared->IoBase, DR_DIO_CSR)) >> 4;

            if (!shared->IsEvtSignaled[KdxDiintChan0 + i]) {
               shared->IsEvtSignaled[KdxDiintChan0 + i] = 1;
               daq_device_signal_event(daq_dev, KdxDiintChan0 + i);
            }
         }
         
         // snap counter
         snap = &shared->CntrSnap[i + KdxCntDiLatch0 - KdxCntBegin];
         if (snap->RefCount > 0) {
            for (j = 0; j < CNTR_UDCHL_COUNT; ++j) {
               if (daq_dev->CntrCtl[j].DiLatch != 0) {
                  snap->State[j] = AdxIoInD(shared->IoBase, DR_CNTRX_DATA(j));
               }
            }

            if (!shared->IsEvtSignaled[KdxCntDiLatch0 + i]) {
               shared->IsEvtSignaled[KdxCntDiLatch0 + i] = 1;
               daq_device_signal_event(daq_dev, KdxCntDiLatch0 + i);
            }
         }
      }
   }
}

static inline 
void daq_ud_cmp_int_tasklet(daq_device_t *daq_dev, DEVICE_SHARED *shared, __u32 active)
{
   CNTR_CONTCMP *cmp;
   __u32 kdx, i;

   for (i = 0; active; active >>= 1, ++i) {
      cmp = &shared->CntrCmp[i];

      if ((active & 0x1) && cmp->Type != CNTR_CONTCMP_DISABLED) {
         if (cmp->Type == CNTR_CONTCMP_TABLE) {
            if (cmp->Curr + 1 < cmp->TblSize) {
               ++cmp->Curr;
               kdx = KdxCntPm0 + i;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CMP_DATA(i), cmp->TblData[cmp->Curr]);
            } else {
               kdx = KdxCntCmpEnd0 + i;
            }
         } else {
            if (cmp->Curr + 1 < cmp->Count) {
               ++cmp->Curr;
               kdx = KdxCntPm0 + i;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CMP_DATA(i), cmp->Start + cmp->Increment * cmp->Curr);
            } else {
               kdx = KdxCntCmpEnd0 + i;
            }
         }

         if (!shared->IsEvtSignaled[kdx]) {
            shared->IsEvtSignaled[kdx] = 1;
            daq_device_signal_event(daq_dev, kdx);
         }
      }
   }
}

// -----------------------------------------------------------------------------

void daq_int_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   INTR_CSR      csr;
   unsigned long flags;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   csr.Value = daq_dev->int_state;
   daq_dev->int_state = 0;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // timer interrupt
   daq_timer_int_tasklet(daq_dev, shared, csr.Timer);

   // counter index interrupt
   daq_ud_index_int_tasklet(daq_dev, shared, csr.Idx);

   // DI channel interrupt
   daq_di_int_tasklet(daq_dev, shared, csr.DI);

   // counter continuous compare event
   daq_ud_cmp_int_tasklet(daq_dev, shared, csr.OvCmp | csr.UdCmp);
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u32 int_state = AdxIoInD(shared->IoBase, DR_INTR_CSR);
   if (!(int_state & DEV_INTR_MASK)) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   daq_dev->int_state |= int_state;
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->int_tasklet);

   // Clear interrupt
   AdxIoInD(shared->IoBase, DR_INTR_CLR); 

   return IRQ_RETVAL(1);
}

