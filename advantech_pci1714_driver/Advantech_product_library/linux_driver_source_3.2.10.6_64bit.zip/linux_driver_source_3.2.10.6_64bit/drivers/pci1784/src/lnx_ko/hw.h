/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

typedef union _CNTR_CTL_REG{
   __u32 Value;
   struct{
      __u32 Mode      : 3;   // Counter input mode. See 'CNTR_MODE'
      __u32 _resv1    : 1;
      __u32 ResetVal  : 1;   // Counter default value after reset: 0 -- 0x80000000, 1 -- 0x0
      __u32 OvflLock  : 1;   // Counter overflow lock
      __u32 UdflLock  : 1;   // Counter underflow lock
      __u32 DigiFlt   : 1;   // Digital filter. 0 -- disabled, 1 -- enabled
      __u32 SwLatch   : 1;   // Software latch counter. 0 -- disabled, 1 -- enabled
      __u32 IdxLatch  : 1;   // Index latch counter. 0 -- disabled, 1 -- enabled
      __u32 TmrLatch  : 1;   // Timer latch counter. 0 -- disabled, 1 -- enabled
      __u32 _resv2    : 1;
      __u32 DiLatch   : 4;   // DiX latch counter. Each bit specify a DI channel latch function.0 -- disabled, 1 -- enabled
   };
}CNTR_CTL_REG;

typedef enum _CNTR_MODE_HW{
   HwDisable = 0, HwAbPhaseX1, HwAbPhaseX2, HwAbPhaseX4, HwTwoPulse, HwPulseDir
}CNTR_MODE_HW;

#define DR_CNTR_CTL_BASE 0
#define DR_CNTRX_CTL(x)  (DR_CNTR_CTL_BASE + (x * 4))

#define DR_CNTR_DATA_BASE 0
#define DR_CNTRX_DATA(x)  (DR_CNTR_DATA_BASE + (x * 4))

#define DR_CNTR_CMP_DATA_BASE 0x10
#define DR_CNTRX_CMP_DATA(x)  (DR_CNTR_CMP_DATA_BASE + (x * 4))

typedef union _INTR_CSR{
   __u32 Value;
   struct{
      __u32 Ovfl  : 4;   // Counter overflow interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 Udfl  : 4;   // Counter underflow interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 Idx   : 4;   // Counter index interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 DI    : 4;   // DI interrupt. Each bit specify a DI channel. 0 -- disabled, 1 -- enabled
      __u32 OvCmp : 4;   // Counter over compare interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 UdCmp : 4;   // Counter under compare interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 _resv1: 4;   // 
      __u32 Timer : 1;   // Timer interrupt. 0 -- disabled, 1 -- enabled
      __u32 _resv2: 2;   // 
      __u32 Intr  : 1;   // For control, Enable interrupt. For status, indicates whether the interrupt occurred.
   };
}INTR_CSR; 

#define DEV_INTR_MASK  0x90ffffff
#define DR_INTR_CSR    0x20
#define DR_INTR_CLR    0x24

// clock control register and bit define
typedef union _CLK_CTL{
   __u32 Value;
   struct{
      __u32 SampClk  : 2;  // Sampling clock. 
      __u32 _reserved: 14; // Counter underflow interrupt. Each bit specify a counter. 0 -- disabled, 1 -- enabled
      __u32 TmrDivider: 8; // Timer divider
      __u32 TmrBaseClk: 3; // Timer base clock
   };
}CLK_CTL; 

typedef enum _SAMP_CLK{
   Clk8MHz = 0, Clk4MHz, Clk2MHz, Clk1MHz
}SAMP_CLK;

typedef enum _TMR_CLK {
   Clk50KHz = 0, Clk5KHz, Clk500Hz, Clk50Hz, Clk5Hz, ClkNone = 7
}TMR_CLK;

#define DR_CLK_CTL    0x24

// Latch counter by software write.
#define DR_SW_LATCH   0x28  

//
#define DR_BID        0x28 

// Reset counter to default value. The default value is specified by counter control register.
typedef union _CNTR_RST_REG {
   __u32 Value;
   struct {
      __u32 ResetCntr : 4; // reset the counters. each bit stands for a counter channel.
      __u32 IdxResetEn: 4; // enable index reset of counter. each bit stands for a counter channel.
   };
} CNTR_RST_REG;

#define DR_CNTR_RESET 0x2c

// Digital output 
typedef union _DIO_CSR{
   __u32 Value;
   struct{
      __u32 Do     : 4;    // DO data
      __u32 Di     : 4;    // DI data when reading the device.
      __u32 _resv  : 8;    // 
      __u32 OvcmpDo: 4;    // 
      __u32 UdcmpDo: 4;
      __u32 DoLevel: 4;
      __u32 DoMode : 4;
   };
}DIO_CSR;  

#define DR_DIO_CSR   0x30


#endif /* _KERNEL_MODULE_HW_H_ */
