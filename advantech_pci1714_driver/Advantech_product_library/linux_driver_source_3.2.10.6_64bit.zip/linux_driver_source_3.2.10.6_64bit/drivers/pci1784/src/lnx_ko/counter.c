/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static 
int CntTypeToHwMode(int sigCntType)
{
   switch(sigCntType)
   {
   default:
   case PulseDirection: return HwPulseDir;
   case TwoPulse:       return HwTwoPulse;
   case AbPhaseX1:      return HwAbPhaseX1;
   case AbPhaseX2:      return HwAbPhaseX2;
   case AbPhaseX4:      return HwAbPhaseX4;
   }
}

static
int daq_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;

   if(start != CNTR_CHL_COUNT - 1 || count != 1){
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[start].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
      shared->CntrState[start].Operation = TimerPulse;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   daq_device_clear_event(daq_dev, KdxCntTimer4);
   shared->IsEvtSignaled[KdxCntTimer4] = 0;

   // configure hardware: timer base block and divisor
   daq_dev->ClkCtl.TmrDivider = shared->CntrConfig.TmrDivisor;
   daq_dev->ClkCtl.TmrBaseClk = shared->CntrConfig.TmrBaseClk;
   AdxIoOutD(shared->IoBase, DR_CLK_CTL, daq_dev->ClkCtl.Value);

   // enable timer interrupt
   daq_dev->IntrCtl.Timer = 1;
   daq_dev->IntrCtl.Intr  = 1;
   AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);

   return 0;
}

static
int daq_cntr_start_updown_counting(daq_device_t *daq_dev, __u32 start, __u32 count, int reset)
{
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   CNTR_CONFIG     *cnt_cfg = &shared->CntrConfig;
   CNTR_RST_REG    *rst_reg = &daq_dev->CntrRst;
   CNTR_CTL_REG    *ctl_reg;
   unsigned long   flags;

   if(start >= CNTR_UDCHL_COUNT || start + count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
   
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   rst_reg->ResetCntr = 0;

   while (count--) {
      if (shared->CntrState[start].Operation != CNTR_IDLE) {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
      shared->CntrState[start].Operation = UpDownCount;

      // reset event flags
      shared->IsEvtSignaled[KdxUdIndex0 + start] = 0;
      daq_device_clear_event_unsafe(daq_dev, KdxUdIndex0 + start);

      shared->IsEvtSignaled[KdxCntPm0 + start] = 0;
      daq_device_clear_event_unsafe(daq_dev, KdxCntPm0 + start);

      shared->IsEvtSignaled[KdxCntCmpEnd0 + start] = 0;
      daq_device_clear_event_unsafe(daq_dev, KdxCntCmpEnd0 + start);

      // configure continuous compare
      if (shared->CntrCmp[start].Type != CNTR_CONTCMP_DISABLED) {
         shared->CntrCmp[start].Curr = 0;
         if (shared->CntrCmp[start].Type == CNTR_CONTCMP_TABLE) {
            AdxIoOutD(shared->IoBase, DR_CNTRX_CMP_DATA(start), shared->CntrCmp[start].TblData[0]);
         } else {
            AdxIoOutD(shared->IoBase, DR_CNTRX_CMP_DATA(start), shared->CntrCmp[start].Start);
         }
      }

      // enable interrupt before we start counter
      // enable index interrupt
      if (shared->CntrConfig.UdResetTimes[start] != 0) {
         daq_dev->IntrCtl.Idx |= 1 << start;
      }

      // enable over-compare / under-compare interrupt
      if (shared->CntrCmp[start].Type != CNTR_CONTCMP_DISABLED) {
         daq_dev->IntrCtl.OvCmp |= 1 << start;
         daq_dev->IntrCtl.UdCmp |= 1 << start;
      }

      if (daq_dev->IntrCtl.Value) {
         daq_dev->IntrCtl.Intr = 1;
         AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);
      }

      // configure counter mode, etc.
      ctl_reg = &daq_dev->CntrCtl[start];
      ctl_reg->Mode     = CntTypeToHwMode(cnt_cfg->UdCntType[start]);
      ctl_reg->ResetVal = cnt_cfg->UdInitVal[start] ? 0 : 1;
      ctl_reg->DigiFlt  = (cnt_cfg->NosFltEnabled >> start) & 0x1; 
      ctl_reg->SwLatch  = 1;
      AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(start), ctl_reg->Value);

      // reset counter to default state and enable index reset, if needed.
      if (reset) {
         rst_reg->ResetCntr |= 1 << start;
      }

      // enable the index reset 
      if (shared->CntrConfig.UdResetTimes[start] == 0) {
         rst_reg->IdxResetEn &= ~(1 << start);
      } else {
         rst_reg->IdxResetEn |= 1 << start;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   AdxIoOutD(shared->IoBase, DR_CNTR_RESET, rst_reg->Value);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   while (count--) {
      shared->CntrState[start].Operation = CNTR_IDLE;
      if (start < CNTR_UDCHL_COUNT) {
         daq_dev->CntrCtl[start].Mode = HwDisable;
         AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(start), daq_dev->CntrCtl[start].Value);

         // disable index interrupt & over-compare/under-compare interrupt
         daq_dev->IntrCtl.Idx   &= ~(1 << start);
         daq_dev->IntrCtl.OvCmp &= ~(1 << start);
         daq_dev->IntrCtl.UdCmp &= ~(1 << start);
      } else {
         if (shared->CntrSnap[KdxCntTimer4 - KdxUdIndex0].RefCount == 0) {
            daq_dev->IntrCtl.Timer = 0;
         }

         // Stop the timer by setting its clock source to 'N/A' value.
         daq_dev->ClkCtl.TmrBaseClk = ClkNone;
         AdxIoOutD(shared->IoBase, DR_CLK_CTL, daq_dev->ClkCtl.Value);
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   // reset interrupt sources
   if ((daq_dev->IntrCtl.Value << 1) == 0) {
      daq_dev->IntrCtl.Intr = 0;
   }
   AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);

   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_cntr_cont_cmp_clear(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_CONTCMP  *cnt_cmp;
   unsigned long flags;
   unsigned      i;

   if(start >= CNTR_UDCHL_COUNT || start + count > CNTR_UDCHL_COUNT) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   for (i = start; i < start + count; ++i) {
      cnt_cmp = &shared->CntrCmp[i];

      // Release compare table if have
      if (cnt_cmp->Type == CNTR_CONTCMP_TABLE) {
         if (cnt_cmp->TblData != NULL) {
            kfree(cnt_cmp->TblData);
         }
         cnt_cmp->TblData = NULL;
      }
      cnt_cmp->Type = CNTR_CONTCMP_DISABLED;

      // configure hardware if the the counter is running
      if (shared->CntrState[i].Operation != CNTR_IDLE) 
      {
         // disable over-compare & under-compare interrupt 
         daq_dev->IntrCtl.OvCmp &= ~(1 << i);
         daq_dev->IntrCtl.UdCmp &= ~(1 << i);
      }
   }

   // configure hardware if the the counter is running
   daq_dev->IntrCtl.Intr = daq_dev->IntrCtl.Value << 1 ? 1 : 0;
   AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);

   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_NoiseFilterOverallBlockTime:
      dataPtr = &shared->CntrConfig.NosFltSampClk;
      valLen  = sizeof(__u32);
      break;
   case CFG_NoiseFilterEnabledChannels:
      dataPtr = &shared->CntrConfig.NosFltEnabled;
      valLen  = sizeof(__u32);
      break;
   case CFG_TmrFrequencyOfCounters:
      if (cntr.Start != CNTR_CHL_COUNT - 1 || cntr.Count != 1) {
         return -EINVAL; 
      }
      dataPtr = &shared->CntrConfig.TmrConfig;
      valLen  = sizeof(__u32);
      break;
   case CFG_UdCountingTypeOfCounters:
      dataPtr = &shared->CntrConfig.UdCntType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_UdInitialValueOfCounters:
      dataPtr = &shared->CntrConfig.UdInitVal[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_UdCountValueResetTimesByIndexs:
      dataPtr = &shared->CntrConfig.UdResetTimes[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case UpDownCount:
      return daq_cntr_start_updown_counting(daq_dev, cntr.Start, cntr.Count, (__u32)(size_t)cntr.Param);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_reset_value(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RST_REG *rst_reg = &daq_dev->CntrRst;
   CNTR_RESET   cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_UDCHL_COUNT || cntr.Start + cntr.Count > CNTR_UDCHL_COUNT){
      return -EINVAL;
   }

   rst_reg->ResetCntr = ((1 << cntr.Count) - 1) << cntr.Start;
   AdxIoOutD(daq_dev->shared.IoBase, DR_CNTR_RESET, rst_reg->Value);

   return 0;
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared  = &daq_dev->shared;
   CNTR_READ     cntr;
   CNTR_VALUE    vals[CNTR_CHL_COUNT];
   CNTR_VALUE    *curr = vals;
   __u32         latch;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   latch  = ((1 << cntr.Count) - 1) << cntr.Start;
   latch  = (latch & 0x1F) | (latch >> 5);
   latch &= 0xF;
   AdxIoOutD(shared->IoBase, DR_SW_LATCH, latch);

   while(cntr.Count--)	{
      if (cntr.Start < CNTR_UDCHL_COUNT) {
         curr->Value = AdxIoInD(shared->IoBase, DR_CNTRX_DATA(cntr.Start));
      } else {
         curr->Value = 0;
      }

      ++curr;
      ++cntr.Start;
      cntr.Start %= CNTR_CHL_COUNT;
   }

   if (unlikely(copy_to_user(cntr.Value, vals, (curr - vals) * sizeof(CNTR_VALUE)))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}

int daq_ioctl_cntr_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   CNTR_START_SNAP cntr;
   CNTR_SNAP       *snap; 
   unsigned        kdx, i;
   unsigned long   flags;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.CntrStart >= CNTR_UDCHL_COUNT || cntr.CntrStart + cntr.CntrCount > CNTR_UDCHL_COUNT){
      return -EINVAL;
   }

   kdx = GetEventKIndex(cntr.EventType);
   if (kdx - KdxCntBegin >= CNTR_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   snap = &shared->CntrSnap[kdx - KdxCntBegin];
   snap->Mask = ((1 << cntr.CntrCount) - 1) << cntr.CntrStart;
   snap->RefCount++;

   // reset event flags
   shared->IsEvtSignaled[kdx] = 0;
   daq_device_clear_event(daq_dev, kdx);

   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   if (kdx >= KdxUdIndex0 && kdx <= KdxUdIndex3) {
      __u32 ct = kdx - KdxUdIndex0;

      daq_dev->CntrCtl[ct].IdxLatch = 1;
      AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(ct), daq_dev->CntrCtl[ct].Value);
     
      daq_dev->IntrCtl.Idx |= 1 << ct; // enable index interrupt
   } else {
      __u32 active = ((1 << cntr.CntrCount) - 1) << cntr.CntrStart;

      if (kdx == KdxCntTimer4) {
         for (i = 0; i < CNTR_UDCHL_COUNT; ++i) {
            if (active & (1 << i)) {
               daq_dev->CntrCtl[i].TmrLatch = 1;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(i), daq_dev->CntrCtl[i].Value);
            }
         }

         daq_dev->IntrCtl.Timer = 1; // enable timer interrupt
      } else { 
         // kdx = [ EvtCntDiLatch0Idx, EvtCntDiLatch3Idx ]       
         __u32 di_mask = 1 << (kdx - KdxCntDiLatch0);
         for (i = 0; i < CNTR_UDCHL_COUNT; ++i) {
            if (active & (1 << i)) {
               daq_dev->CntrCtl[i].DiLatch |= di_mask;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(i), daq_dev->CntrCtl[i].Value);
            }
         }
         
         daq_dev->IntrCtl.DI |= di_mask; // enable DIx interrupt
      }
   }

   // enable interrupt
   daq_dev->IntrCtl.Intr = 1;
   AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);

   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

int daq_ioctl_cntr_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   CNTR_SNAP       *snap; 
   __u32           evt_id;
   unsigned        kdx, i;
   unsigned long   flags;

   evt_id = (__u32)arg;

   kdx = GetEventKIndex(evt_id);
   if (kdx - KdxCntBegin >= CNTR_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   snap = &shared->CntrSnap[kdx - KdxCntBegin];
   if (!snap->RefCount)  { return 0; }
   if (--snap->RefCount) { return 0; }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   if (kdx >= KdxUdIndex0 && kdx <= KdxUdIndex3) {
      __u32 ct = kdx - KdxUdIndex0;

      daq_dev->CntrCtl[ct].IdxLatch = 0;
      AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(ct), daq_dev->CntrCtl[ct].Value);

      // disable index interrupt if needed
      if ((daq_dev->CntrRst.IdxResetEn & (0x1 << ct)) == 0) {
         daq_dev->IntrCtl.Idx &= ~(1 << ct);
      }
   } else {
      if (kdx == KdxCntTimer4) {
         for (i = 0; i < CNTR_UDCHL_COUNT; ++i) {
            if (daq_dev->CntrCtl[i].TmrLatch) {
               daq_dev->CntrCtl[i].TmrLatch = 0;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(i), daq_dev->CntrCtl[i].Value);
            }
         }

         // disable timer interrupt if needed
         if (shared->CntrState[CNTR_CHL_COUNT - 1].Operation == CNTR_IDLE) {
            daq_dev->IntrCtl.Timer = 0;
         }
      } else { // kdx = [ EvtCntDiLatch0Idx, EvtCntDiLatch3Idx ]
         __u32 di_chan = kdx - KdxCntDiLatch0;
         __u32 di_mask = 1 << di_chan;
         for (i = 0; i < CNTR_UDCHL_COUNT; ++i) {
            if (daq_dev->CntrCtl[i].DiLatch & di_mask) {
               daq_dev->CntrCtl[i].DiLatch &= ~di_mask;
               AdxIoOutD(shared->IoBase, DR_CNTRX_CTL(i), daq_dev->CntrCtl[i].Value);
            }
         }

         // disable DIx interrupt if needed
         if (shared->DiSnap[di_chan].Count == 0) {
            daq_dev->IntrCtl.DI &= ~di_mask;
         }
      }
   }

   // disable interrupt
   daq_dev->IntrCtl.Intr = (daq_dev->IntrCtl.Value << 1) ? 1 : 0;
   AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);
   
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

int daq_ioctl_cntr_contcmp_config(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   CNTR_CONTCMP_CFG cfg;
   CNTR_CONTCMP     *cmp;
   unsigned long    flags;
   __u32            firstValue;

   if (unlikely(copy_from_user(&cfg, (void *)arg, sizeof(cfg)))){
      return -EFAULT;
   }
   if (cfg.Counter >= CNTR_UDCHL_COUNT) { 
      return -EINVAL; 
   }

   cmp = &shared->CntrCmp[cfg.Counter];

   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   if (cfg.Type == CNTR_CONTCMP_TABLE) {
      // Prepare memory for the compare table
      if (cmp->Type == CNTR_CONTCMP_INTVL) {
         cmp->TblData = NULL;
      } else {
         if (cmp->TblData && cmp->TblSize != cfg.TblSize) {
            kfree(cmp->TblData);
            cmp->TblData = NULL;
         }
      } 

      if (cmp->TblData == NULL) {
         cmp->TblData = (__u32 *)kmalloc(cfg.TblSize * sizeof(__u32), GFP_KERNEL);
         if (cmp->TblData == NULL) {
            spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
            return -ENOMEM; 
         }
      }

      // set compare table
      cmp->Type = CNTR_CONTCMP_TABLE;
      cmp->Curr = 0;
      cmp->TblSize = cfg.TblSize;
      if (unlikely(copy_from_user(cmp->TblData, cfg.TblData, cfg.TblSize * sizeof(__u32)))) {
         return -EFAULT;
      }
      
      //
      firstValue = cmp->TblData[0];
   } else {
      if (cmp->Type == CNTR_CONTCMP_TABLE) {
         if (cmp->TblData != NULL) {
            kfree(cmp->TblData);
         }
         cmp->TblData = NULL;
      }

      // set compare interval
      cmp->Type      = CNTR_CONTCMP_INTVL;
      cmp->Curr      = 0;
      cmp->Start     = cfg.Start;
      cmp->Increment = cfg.Increment;
      cmp->Count     = cfg.Count;

      // 
      firstValue = cmp->Start;
   }

   // configure hardware if the the counter is running
   if (shared->CntrState[cfg.Counter].Operation != CNTR_IDLE) {
      // set compare value
      shared->CntrCmp[cfg.Counter].Curr = 0;
      AdxIoOutD(shared->IoBase, DR_CNTRX_CMP_DATA(cfg.Counter), firstValue);

      // Enable over-compare & under-compare interrupt 
      daq_dev->IntrCtl.OvCmp |= 1 << cfg.Counter;
      daq_dev->IntrCtl.UdCmp |= 1 << cfg.Counter;
      daq_dev->IntrCtl.Intr   = 1;
      AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);
   }

   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

int daq_ioctl_cntr_contcmp_clear(daq_device_t *daq_dev, unsigned long arg)
{
   return daq_cntr_cont_cmp_clear(daq_dev, (__u32)arg, 1);
}
