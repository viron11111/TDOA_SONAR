/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1784
#define DEVICE_PID    BD_PCI1784
#define DEVICE_NAME   "PCI-1784"
#define DRIVER_NAME   "bio1784"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT		   1                 // 1 DI/O
#define DIO_CHL_COUNT         4                 // 4 channel DI, 4 channel DO
#define DI_INT_SRC_COUNT      4                 // CH#[0, 1, 2, 3]
#define DI_SNAP_SRC_COUNT     DI_INT_SRC_COUNT

#define CNTR_CHL_COUNT           5
#define CNTR_UDCHL_COUNT         4

#define CNTR_RES_IN_BIT          32
#define CNTR_DATA_SIZE           sizeof(__u32)
#define CNTR_MIN_VAL             0
#define CNTR_MAX_VAL             0xffffffff

#define CNTR_IDLE                0
#define CNTR_CONTCMP_DISABLED    0

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDiintChan1,
   KdxDiintChan2,
   KdxDiintChan3,
   KdxDiEnd = KdxDiintChan3,

   KdxCntBegin,
   KdxUdIndex0 = KdxCntBegin,
   KdxUdIndex1,
   KdxUdIndex2,
   KdxUdIndex3,

   KdxCntDiLatch0,
   KdxCntDiLatch1,
   KdxCntDiLatch2,
   KdxCntDiLatch3,

   KdxCntTimer4,

   KdxCntPm0,
   KdxCntPm1,
   KdxCntPm2,
   KdxCntPm3,

   KdxCntCmpEnd0,
   KdxCntCmpEnd1,
   KdxCntCmpEnd2,
   KdxCntCmpEnd3,

   KdxCntEnd = KdxCntCmpEnd3,
   KrnlSptedEventCount,
};

#define CNTR_EVENT_COUNT      (KdxCntEnd - KdxCntBegin + 1)
#define CNTR_SNAP_SRC_COUNT   (KdxCntTimer4 - KdxUdIndex0 + 1)

// Helper function used to map a user mode event type to kernel event index.
#define IS_DI_EVENT(id)       (!(id < EvtDiintChannel000 || id > EvtDiintChannel003))
#define IS_UDIDX_EVENT(id)    (!(id < EvtUdIndex0 || id > EvtUdIndex3))
#define IS_CNTPM_EVENT(id)    (!(id < EvtCntPatternMatch0 || id > EvtCntPatternMatch3))
#define IS_CMP_END_EVENT(id)  (!(id < EvtCntCompareTableEnd0 || id > EvtCntCompareTableEnd3))
#define IS_TMR_EVENT(id)      (id == EvtCntTimer4)

static inline __u32 GetEventKIndex(__u32 etype)
{
   __u32 kdx = -1;
   if (etype == EvtPropertyChanged)  { kdx = KdxDevPropChged;   } 
   else if (IS_DI_EVENT(etype))      { kdx = etype - EvtDiintChannel000 + KdxDiBegin;        }
   else if (IS_UDIDX_EVENT(etype))   { kdx = etype - EvtUdIndex0            + KdxUdIndex0;   }
   else if (IS_CNTPM_EVENT(etype))   { kdx = etype - EvtCntPatternMatch0    + KdxCntPm0;     }
   else if (IS_CMP_END_EVENT(etype)) { kdx = etype - EvtCntCompareTableEnd0 + KdxCntCmpEnd0; }
   else if (IS_TMR_EVENT(etype))     { kdx = KdxCntTimer4; }

   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DI_INVERSE          0
#define DEF_DO_MODE             0
#define DEF_DO_STATE            0

// Counter default value
#define DEF_CT_NOSFLT_SAMPCLK   Clk8MHz
#define DEF_CT_NOSFLT_ENABLED   0
#define DEF_CT_UD_CNTTYPE       PulseDirection
#define DEF_CT_UD_INITVAL       0
#define DEF_CT_UD_RSTTMS        0
#define DEF_CT_TMR_CFG          ((Clk50Hz << 8) | 5)

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP
{
   __u8 Start;
   __u8 Count;
   __u8 State[DIO_PORT_COUNT];
   __u8 Reserve;
} DI_SNAP;

typedef struct _CNTR_CONFIG
{
   __u32  NosFltSampClk;
   __u32  NosFltEnabled;

   // --------------------------------------------------------
   __u32  UdCntType[ CNTR_CHL_COUNT ];   
   __u32  UdInitVal[CNTR_CHL_COUNT];
   __u32  UdResetTimes[CNTR_CHL_COUNT];

   // --------------------------------------------------------
   union {
      struct {
         __u8 TmrDivisor; // Timer/Pulse frequency, in counter divisor
         __u8 TmrBaseClk; // Timer clock source
      };
      __u32 TmrConfig;
   };

}CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     UdResetCount;
}CNTR_STATE;

typedef struct _CNTR_SNAP
{
   __u16  RefCount;
   __u16  Mask;
   __u32  State[CNTR_CHL_COUNT]; // The last channel can't be snapped.
} CNTR_SNAP;

typedef struct _CNTR_CONTCMP 
{
   __u32 Type;
   __u32 Curr;
   union {
      struct {
         __u32 Start;
         __s32 Increment;
         __u32 Count;
      };
      struct {
         __u32 *TblData;
         __u32 TblSize;
         __u32 __pad__;         
      };
   };
} CNTR_CONTCMP;

typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number
   __u32   SubsystemID;

   // HW Information
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   IoBase;
   __u32   IoLength;
   __u32   Irq;
   __u32   InitOnLoad;

   // --------------------------------------------------------
   DI_SNAP DiSnap[DI_SNAP_SRC_COUNT];
   __u32   DoConfig; 
   __u8    DiInverse[DIO_PORT_COUNT];
   __u8    DoState[DIO_PORT_COUNT];
   
   // --------------------------------------------------------
   CNTR_CONFIG  CntrConfig;
   CNTR_STATE   CntrState[CNTR_CHL_COUNT];
   CNTR_SNAP    CntrSnap[CNTR_SNAP_SRC_COUNT];
   CNTR_CONTCMP CntrCmp[CNTR_UDCHL_COUNT];

   // ---------------------------------------------------------
   __u32   IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
