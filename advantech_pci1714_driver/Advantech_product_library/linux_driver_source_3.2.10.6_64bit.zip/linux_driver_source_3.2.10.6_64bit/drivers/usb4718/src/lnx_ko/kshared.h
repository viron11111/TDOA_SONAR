/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x1809
#define DEVICE_ID  	 0x4718
#define DEVICE_PID    BD_USB4718
#define DEVICE_NAME   "USB-4718"
#define DRIVER_NAME   "bio4718"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------

// The USB4718 only support differential connection
#define AI_CHL_COUNT             8
#define AI_SE_CHL_COUNT          0
#define AI_DIFF_CHL_COUNT        AI_CHL_COUNT

#define AI_CHL_MASK              (AI_CHL_COUNT - 1)
#define AI_RES_IN_BIT            16
#define AI_DATA_SIZE             sizeof(USHORT)
#define AI_DATA_MASK             0xffff

#define SAI_TIMEOUT_VAL          3500  // 3500ms

#define DIO_PORT_COUNT           1  // 1 DI, 1 DO
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

#define mA_4To20_Gain           0x1E
#define mA_0To20_Gain           0x1F
#define RESET_CHL_GAIN          0xff

#define CJC_AVG_COUNT           5

// -----------------------------------------------------
// gains for thermo-couple
// -----------------------------------------------------
//Note: The USB4718 hardware use special gainCode for Thermo couple measure
//These gain code is special for Thermo only, and is not exposed for user
//The device exposed gain is only unipolar, however, the internal gain code for thermo may be bipolar
//define the gain for thermo type, to make each GainCode respond to one vrgType
#define Jtype_Gain   100
#define Ktype_Gain   101
#define Ttype_Gain   102
#define Etype_Gain   103
#define Rtype_Gain   104
#define Stype_Gain   105
#define Btype_Gain   106

#define Jtype1_Gain   110
#define Ktype1_Gain   111
#define Ttype1_Gain   112
#define Etype1_Gain   113
#define Rtype1_Gain   114
#define Stype1_Gain   115
#define Btype1_Gain   116

#define EE_AiChGainType      0x0210  //AI Gain type for each channel:
#define EE_AiBurnOutTypeSet  0x0220  //Burn Out Settings: 0: Disable; 1: 888888; 2: -888888; 3: MaxVal; 4: MinVal
#define AiBurnOutOccur       0x0230  // 0: Not Burn Out, 1: Burn Out
#define AiCh4To20mABurnSet   0x0240  // 0: UpperLimit, 1: LowerLimit, 2: Last value

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDevRemoved,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   case EvtDeviceRemoved:   kdx = KdxDevRemoved;   break;
   default:                 kdx = -1;              break;
   }
   return kdx;
}

typedef struct _USB_AI_CH_STAUS
{
   __u32 CmdCode;
   __u16 ChanStart;
   __u16 ChanCount;
   __u32 RetCode;
   __u32 *Status;
} USB_AI_CH_STAUS, *PUSB_AI_CH_STAUS;

// -----------------------------------------------------
// macros the usbcommon.h needed
// -----------------------------------------------------
#define  MAX_AI_CHANNELS         AI_CHL_COUNT

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_GAIN             0xb  // 0 ~ 100mv
#define DEF_SAI_CHSTART         0
#define DEF_SAI_CHCOUNT         1
#define DEF_BURN_DETECT_RETTYPE 0
#define DEF_BURN_DETECT_RETVAL  0.0
#define DEF_CJC_CHANNEL         -1
#define DEF_CJC_UPDATE_FREQ     2.0
#define DEF_CJC_VALUE           25.0

// DIO default values
#define DEF_DO_STATE            0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number

   // HW Information
   __u32   BoardId;        // Board Id of the device
   __u32   InitOnLoad;

   // Device setting
   __u8    AiChanGain[AI_CHL_COUNT];
   __u32   SaiAutoConvChStart;
   __u32   SaiAutoConvChCount;

   __u32   BurnDetectType[AI_CHL_COUNT];
   double  BurnDetectValue[AI_CHL_COUNT];
   double  LastValue[AI_CHL_COUNT];
   double  LastUpdateTime;
   double  CjcUpdateFreq;
   double  CjcValue;
   double  CjcError;
   __s32   CjcChannel;

   // ---------------------------------------------------------
   __u8    DoPortState[DIO_PORT_COUNT];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
