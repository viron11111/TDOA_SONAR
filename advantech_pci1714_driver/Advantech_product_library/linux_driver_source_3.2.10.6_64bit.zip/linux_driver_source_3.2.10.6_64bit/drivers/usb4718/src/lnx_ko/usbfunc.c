/*
 * usbfunc.c
 *
 *  Created on: 2011-8-31
 *      Author: rocky
 */
#include <linux/usb.h>
#include "kdriver.h"
#include <daqusb.h>

typedef struct _BioUsbGetAiChStatus_TX
{
   __u16 CmdCode;
   __u16 StartChan;
   __u16 ChanCount;
} BioUsbGetAiChanStatus_TX;

typedef struct _BioUsbGetAiChStatus_RX
{
   __u32  RetCode;
   __u32  Status[MAX_AI_CHANNELS];
} BioUsbGetAiChanStatus_RX;

typedef struct _BioUsbSetAiChanStatus
{
   __u32  Status[MAX_AI_CHANNELS];
   __u16  CmdCode;
   __u16  StartChan;
   __u16  ChanCount;
} BioUsbSetAiChanStatus;

typedef struct _BioUsbCjcTempRead
{
   __u32 Data;
   __u32 Status;
}BioUsbCjcTempRead;

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
#define DO_CTRL_XFER_LOCKED(daq_dev, _expr_) \
   ({\
      int __xret;\
      mutex_lock(&daq_dev->ctrl_pipe_lock);\
      if (likely(daq_dev->udev)){\
         __xret = _expr_;\
      } else {\
         __xret = -ENODEV;\
      }\
      mutex_unlock(&daq_dev->ctrl_pipe_lock);\
      __xret;\
   })

static inline
int __daq_usb_control_in(struct usb_device *usb_dev, __u8 major, __u16 minor, void *data, __u16 size)
{
   return usb_control_msg(usb_dev, usb_rcvctrlpipe(usb_dev, 0),
            major, USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
            minor, 0, data, size, USB_CTRL_GET_TIMEOUT);
}

static inline
int __daq_usb_control_out(struct usb_device *usb_dev, __u8 major, __u16 minor, void *data, __u16 size)
{
   return usb_control_msg(usb_dev, usb_sndctrlpipe(usb_dev, 0),
            major, USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
            minor, 0, data, size,  USB_CTRL_SET_TIMEOUT);
}

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
int daq_usb_dev_get_firmware_ver(daq_device_t *daq_dev, char ver[], int len)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_in(daq_dev->udev, MAJOR_SYSTEM, MINOR_GET_FW_VERSION, ver, len));
}

int daq_usb_dev_init_firmware(daq_device_t *daq_dev, int is_open)
{
   __u32 dummy = 0; // Unused, but firmware required.

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev->udev, MAJOR_SYSTEM,
               is_open ? MINOR_DEVICE_OPEN : MINOR_DEVICE_CLOSE, &dummy, sizeof(dummy)));
}

int daq_usb_dev_locate_device(daq_device_t *daq_dev, __u8 enable)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev->udev, MAJOR_SYSTEM, MINOR_LOCATE, &enable, sizeof(enable)));
}

int daq_usb_dev_get_board_id(daq_device_t *daq_dev, __u32 *id)
{
   int ret = DO_CTRL_XFER_LOCKED(daq_dev,
               __daq_usb_control_in(daq_dev->udev, MAJOR_SYSTEM, MINOR_READ_SWITCHID, id, sizeof(__u32)));
   *id = __be32_to_cpu(*id) & 0xf;

   return ret;
}

int daq_usb_dev_set_board_id(daq_device_t *daq_dev, __u32 id)
{
   id = __cpu_to_be32(id & 0xf);

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev->udev, MAJOR_SYSTEM, MINOR_WRITE_SWITCHID, &id, sizeof(__u32)));
}

int daq_usb_dev_dbg_input(daq_device_t *daq_dev, __u16 majorCmd, __u16 minorCmd, __u32 dataSize, void *data)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_in(daq_dev->udev, majorCmd, minorCmd, data, dataSize));
}

int daq_usb_dev_dbg_output(daq_device_t *daq_dev, __u16 majorCmd, __u16 minorCmd, __u32 dataSize, void *data)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_out(daq_dev->udev, majorCmd, minorCmd, data, dataSize));
}

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
int daq_usb_di_read_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDI_RX rx = { 0 };
   BioUsbDI_TX tx;
   int         ret = 0;

   tx.Size = __constant_cpu_to_be16(1);

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = __cpu_to_be16(start);
         ret = __daq_usb_control_out(daq_dev->udev, MAJOR_DIO, MINOR_DI_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev->udev, MAJOR_DIO, MINOR_DI_RX, &rx, sizeof(rx));
         if (ret < 0) break;
         *data++ = (__u8)__be16_to_cpu(rx.Data);
         start = (++start) % DIO_PORT_COUNT;
      }
      ret;
   }));
}

int daq_usb_do_write_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDO tx;
   int      ret = 0;

   tx.Size = __constant_cpu_to_be16(1);

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = __cpu_to_be16(start);
         tx.Data    = __cpu_to_be32(*data);
         ret = __daq_usb_control_out(daq_dev->udev, MAJOR_DIO, MINOR_DO, &tx, sizeof(tx));
         if (ret < 0) break;

         ++data;
         start = (++start) % DIO_PORT_COUNT;
      }
      ret;
   }));
}

int daq_usb_do_read_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDORead_RX rx = { 0 };
   BioUsbDORead_TX tx;
   int             ret = 0;

   tx.Size = __constant_cpu_to_be16(1);

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = cpu_to_be16(start);
         ret = __daq_usb_control_out(daq_dev->udev, MAJOR_DIO, MINOR_DO_READ_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev->udev, MAJOR_DIO, MINOR_DO_READ_RX, &rx, sizeof(rx));
         if (ret < 0) break;

         *data++ = (__u8)__be16_to_cpu(rx.Data);
         start = (++start) % DIO_PORT_COUNT;
      }
      ret;
   }));
}

// ---------------------------------------------------------------------------------
//
// ---------------------------------------------------------------------------------
int daq_usb_ai_configure_channel(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *chType, __u8 *gain)
{
   BioUsbMaiSetGain tx;
   unsigned i;

   tx.StartChannel = __cpu_to_be16(start);
   tx.ChannelCount = __cpu_to_be16(count);
   for (i = 0; i < count; ++i){
      tx.Gain[i] = __cpu_to_be16(gain[i]);
   }

   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_out(daq_dev->udev, MAJOR_AI, MINOR_MAI_SETGAIN, &tx, sizeof(tx)));
}

int daq_usb_ai_get_channel_status(daq_device_t *daq_dev, __u32 cmdCode, __u32 start, __u32 count, __u32 *status)
{
   BioUsbGetAiChanStatus_TX tx;
   BioUsbGetAiChanStatus_RX rx;
   unsigned i;
   int ret;

   tx.CmdCode   = __cpu_to_be16(cmdCode);
   tx.StartChan = __cpu_to_be16(start);
   tx.ChanCount = __cpu_to_be16(count);

   ret = DO_CTRL_XFER_LOCKED(daq_dev,\
			({
				ret = __daq_usb_control_out(daq_dev->udev, MAJOR_AI, MINOR_GET_CHLSTATUS_TX, &tx, sizeof(tx));
				if (ret > 0){
				   ret = __daq_usb_control_in(daq_dev->udev, MAJOR_AI, MINOR_GET_CHLSTATUS_RX, &rx, sizeof(rx));
				}
				ret;
			}));

   if (ret > 0){
      for (i = 0; i < count; ++i){
         status[i] = __be32_to_cpu(rx.Status[i]);
      }
   }

   return ret;
}

int daq_usb_ai_set_channel_status(daq_device_t *daq_dev, __u32 cmdCode, __u32 start, __u32 count, __u32 *status)
{
   BioUsbSetAiChanStatus tx;
   unsigned i;

   tx.CmdCode   = __cpu_to_be16(cmdCode);
   tx.StartChan = __cpu_to_be16(start);
   tx.ChanCount = __cpu_to_be16(count);
   for (i = 0; i < count; ++i) {
      tx.Status[i] = __cpu_to_be32(status[i]);
   }

   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_out(daq_dev->udev, MAJOR_AI, MINOR_SET_CHLSTATUS, &tx, sizeof(tx)));
}

int daq_usb_ai_read_channel(daq_device_t *daq_dev, __u32 start, __u32 count, __u32 timeout, __u16 *sample)
{
   BioUsbMaiBinaryIn_TX tx;
   BioUsbMaiBinaryIn_RX rx = {0};
   unsigned long absolute_timeout;
   unsigned      i;
   int           ret;

   tx.StartChannel = __cpu_to_be16(start);
   tx.ChannelCount = __cpu_to_be16(count);
   tx.TriggerMode  = 0;

   ret = DO_CTRL_XFER_LOCKED(daq_dev,\
			({
				ret = __daq_usb_control_out(daq_dev->udev, MAJOR_AI, MINOR_MAI_BINARYIN_TX, &tx, sizeof(tx));
				if (ret > 0) {
				   absolute_timeout = jiffies + msecs_to_jiffies(timeout);
				   for(;;){
				      ret = __daq_usb_control_in(daq_dev->udev, MAJOR_AI, MINOR_MAI_BINARYIN_RX, &rx, sizeof(rx));
				      if (ret > 0 && rx.Error ) break;
				      if (time_is_before_jiffies(absolute_timeout)){
				         ret = -EIO;
				         break;
				      }
                                      mdelay(10);
				   }
				}
				ret;
			}));

   if (ret > 0){
      for (i = 0; i < min(count, (__u32)AI_CHL_COUNT); ++i){
         sample[i] = (__u16)__be32_to_cpu(rx.Data[i]);
      }
   }

   return ret;
}

int daq_usb_ai_read_cjc_error(daq_device_t *daq_dev, __u16 *error)
{
   __u32 cjcError = 0;
   int   ret;

   ret = DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_in(daq_dev->udev, MAJOR_AI, MINOR_CJCERROR_READ, &cjcError, sizeof(cjcError)));
   *error = (__u16)__be32_to_cpu(cjcError);

   return ret;
}

int daq_usb_ai_read_cjc_value(daq_device_t *daq_dev, __u32 timeout, __u16 *value)
{
   BioUsbCjcTempRead rx = {0};
   int           ret;
   unsigned long absolute_timeout = jiffies + msecs_to_jiffies(timeout);

   ret = DO_CTRL_XFER_LOCKED(daq_dev,\
			({
				for(;;){
				   ret = __daq_usb_control_in(daq_dev->udev, MAJOR_AI, MINOR_CJCTEMP_READ, &rx, sizeof(rx));
				   if (ret < 0 || rx.Status) break;
				   if (time_is_before_jiffies(absolute_timeout)){
				      ret = -EIO;
				      break;
				   }
				}
				ret;
			}));

   if (ret > 0){
      *value = (__u16)__be32_to_cpu(rx.Data);
   }

   return ret;
}

