/*
 * dio.c
 *
 *  Created on: 2011-9-15
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
static
void daq_dio_set_port_dir(daq_device_t *daq_dev)
{
   DIO_CONTROL_REG dioCtrl = {0};
   
   dioCtrl.HighByteDir = (daq_dev->shared.DioPortDir[1] == Input) ? 1 : 0;
   dioCtrl.LowByteDir = (daq_dev->shared.DioPortDir[0] == Input) ? 1 : 0;
   AdxMemOutD( daq_dev->shared.BarMemBase[1], REG_DIO_CONFIG, dioCtrl.Value );
   daq_trace(("DioSetPortDir: 0x%x\n", dioCtrl.Value ));
}

void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   daq_dio_set_port_dir(daq_dev);

   if (daq_dev->shared.InitOnLoad){
      int i;
      __u8 const * state = daq_dev->shared.DoPortState;
      daq_dio_set_port_dir(daq_dev);
      for (i = 0; i < DIO_PORT_COUNT; ++i) {
        AdxMemOutB(daq_dev->shared.BarMemBase[1], REG_DIO_DATA + i, *state);
      }
   }
}

int daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_SET_PORT_DIR xbuf;
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);

   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORT_COUNT;
      daq_dev->shared.DioPortDir[port] = xbuf.Dirs[port];
   }

   daq_dio_set_port_dir( daq_dev );
   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       state;
   unsigned long flags;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }
   if (xbuf.Port >= DIO_PORT_COUNT) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   state = AdxMemInB(daq_dev->shared.BarMemBase[1], REG_DIO_DATA + xbuf.Port);
   state &= ~(1 << xbuf.Bit);
   state |= (!!xbuf.Data) << xbuf.Bit;
   AdxMemOutB(daq_dev->shared.BarMemBase[1], REG_DIO_DATA + xbuf.Port, state);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}
