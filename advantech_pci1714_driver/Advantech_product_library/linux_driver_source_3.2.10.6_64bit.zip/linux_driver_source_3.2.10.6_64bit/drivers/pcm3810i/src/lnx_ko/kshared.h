/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x3810
#define DEVICE_PID    BD_PCM3810I
#define DEVICE_NAME   "PCM-3810"
#define DRIVER_NAME   "bio3810"

#define Internal_CFG_PiClkSourceOfCounters    0xffff
#define Internal_CFG_FoutClkSourceOfCounters  0xfffe


// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define PCIBAR_COUNTS            4

#define AI_CHL_COUNT             16
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        ( AI_SE_CHL_COUNT / 2 )

#define AI_CLK_BASE              (20*1000*1000)    // 20MHz clock 
#define AI_MAX_PACER             (250*1000)        // 250KHz
#define AI_MIN_PACER             (AI_CLK_BASE / (4294967296.0)) //The clock divisor is 32bit counter, 4.7ms

#define MAX_VAL_32BIT            4294967295              
#define MAX_VAL_16BIT            65535

#define AI_FIFO_SIZE             4096                                 // Ai fifo size in samples.
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)        // 0xF for 16 channel AI.
#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(__u32)
#define AI_DATA_MASK             0xfff00000

// The acceptable CJC value range
#define CJC_VALUE_LOW            -273
#define CJC_VALUE_HIGH           1200

//define the gain for thermo type, to make each GainCode respond to one vrgType
#define Jtype_Gain   100
#define Ktype_Gain   101
#define Ttype_Gain   102
#define Etype_Gain   103
#define Rtype_Gain   104
#define Stype_Gain   105
#define Btype_Gain   106

//////////// normal pcm3810
#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt25To2pt25  1
#define AI_GAIN_V_Neg1pt25To1pt25  2
#define AI_GAIN_mV_Neg625To625     3
#define AI_GAIN_V_Neg10To10        4
#define AI_GAIN_V_Neg0To10        16
#define AI_GAIN_V_Neg0To5         17 
#define AI_GAIN_V_Neg0To2pt5      18
#define AI_GAIN_V_Neg0To1pt5      19

/* PCM3810HG Gain
    V_Neg5To5,            0         
    mV_Neg500To500,       1         
    mV_Neg50To50,         2         
    mV_Neg5To5,           3         
    V_Neg10To10,          4        
    V_Neg1To1,            5      
    mV_Neg100To100,       6     
    mV_Neg10To10,         7        
    V_0To10,             16          
    V_0To1,              17          
    mV_0To100,           18        
    mV_0To10,            19          

    Jtype_Neg210To1200C,  Jtype_Gain 
    Ktype_Neg270To1372C,  Ktype_Gain
    Ttype_Neg270To400C,   Ttype_Gain 
    Etype_Neg270To1000C,  Etype_Gain 
    Rtype_Neg50To1768C,   Rtype_Gain 
    Stype_Neg50To1768C,   Stype_Gain 
    Btype_40To1820C,      Btype_Gain
*/

///////////////////////////////////////////////////////////////////////////////////////////
//AO
#define AO_CHL_COUNT       2
#define AO_CHL_MASK        (AO_CHL_COUNT - 1)      // 0x1 for 2 channel AO.
#define AO_RES_IN_BIT      12
#define AO_DATA_SIZE       sizeof(__u16)
#define AO_DATA_MASK       0x0fff

#define AO_CLK_BASE        (20*1000*1000)       // 20MHz clock 
#define AO_MAX_PACER       (250*1000)           // 250KHz
#define AO_MIN_PACER       (AO_CLK_BASE / 4294967296.0 )

#define AO_FIFO_SIZE               (4096)                          // AO fifo size in samples

#define FAO_MODE_FINITE_SYNC   0    // synchronous finite output 
#define FAO_MODE_FINITE_ASYNC  0x1  // asynchronous finite output 
#define FAO_MODE_INFINITE      0x2  // infinite output
   
#define AO_EXT_REF_UNIPOLAR  10   // Default 10V external reference voltage
#define AO_EXT_REF_BIPOLAR   10   // Default 10V external reference voltage 

// AIO calibrate
#define OFFSET                  0
#define SPAN                    1
#define CHECK                   2

//////////////////////////////////////////////////////////////////////////////////////////

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)
//////////////////////////////////////////////////////////////////////////////////////////

#define CNTR_CHL_COUNT           3
#define CNTR_RES_IN_BIT          24  
#define CNTR_DATA_SIZE           sizeof(__u32)
#define CNTR_MIN_VAL             0
#define CNTR_MAX_VAL             ( (1 << 24) - 1 )  
#define CNTR_CLK_BASE            (20 * 1000 * 1000UL) 
#define CNTR_IDLE                0
#define CNTR_DATA_MASK           0xffffff

#define CNTR_RBUF_DEPTH          24 
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)                     
#define CNTR_CHK_PERIOD_MS       10                                        
#define CNTR_CHK_PERIOD_NS       ((__u32)CNTR_CHK_PERIOD_MS * 1000 * 10UL)   
#define CNTR_CHK_PERIOD_MAX_NS   (((__u32)10 * 1000 * 1000 * 10UL) >> 4 )   

#define CNTR_VAL_THRESHOLD_BASE  10      // the threshold of counter value difference between two read, for frequency measurement mainly.
      
#define CNTR_PWMIN_CHK_PERIOD_MS 5

#define CNTR_TIMER_PULSE_MAX_FREQ   ( 5 * 1000 * 1000 )

////////////////////////////////////////////////////////////////////////////////////////////
#ifdef USE_IN_SO
#  define AdxMemInB(MemBase, Offset) (*(uint8 *) ((uint8 *)MemBase + Offset))
#  define AdxMemInW(MemBase, Offset) (*(uint16 *)((uint8 *)MemBase + Offset))
#  define AdxMemInD(MemBase, Offset) (*(uint32 *)((uint8 *)MemBase + Offset))

#  define AdxMemOutB(MemBase, Offset, Data) (*(uint8 *) ((uint8 *)MemBase + Offset) = (uint8)Data)
#  define AdxMemOutW(MemBase, Offset, Data) (*(uint16 *)((uint8 *)MemBase + Offset) = (uint16)Data)
#  define AdxMemOutD(MemBase, Offset, Data) (*(uint32 *)((uint8 *)MemBase + Offset) = (uint32)Data)
#endif

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,

   KdxAoDataTransed,
   KdxAoUnderrun,
   KdxAoTransStopped,
   KdxAoStopped,

   KdxCntTimer0,
   KdxCntTimer1,
   KdxCntTimer2,
   KdxCntTerminalCount0,
   KdxCntTerminalCount1,
   KdxCntTerminalCount2,

   KrnlSptedEventCount,
   InvalidEventIdx = KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:           kdx = KdxDevPropChged;      break;
   case EvtBufferedAiDataReady:       kdx = KdxAiDataReady;       break;
   case EvtBufferedAiOverrun:         kdx = KdxAiOverrun;         break;
   case EvtBufferedAiStopped:         kdx = KdxAiStopped;         break;
   case EvtBufferedAiCacheOverflow:   kdx = KdxAiCacheOverflow;   break;

   case EvtBufferedAoDataTransmitted: kdx = KdxAoDataTransed;     break;
   case EvtBufferedAoUnderrun:        kdx = KdxAoUnderrun;        break;
   case EvtBufferedAoTransStopped:    kdx = KdxAoTransStopped;    break;
   case EvtBufferedAoStopped:         kdx = KdxAoStopped;         break;

   case EvtCntTerminalCount0:         kdx = KdxCntTerminalCount0; break;
   case EvtCntTerminalCount1:         kdx = KdxCntTerminalCount1; break;
   case EvtCntTerminalCount2:         kdx = KdxCntTerminalCount2; break;
   case EvtCntTimer0:                 kdx = KdxCntTimer0;         break;
   case EvtCntTimer1:                 kdx = KdxCntTimer1;         break;
   case EvtCntTimer2:                 kdx = KdxCntTimer2;         break;
   default:                           kdx = -1;                   break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg10To10
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (10 * 100)
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE / 2)
#define DEF_FAI_MODE            0
#define DEF_FAI_TRIG_SRC        SignalNone
#define DEF_FAI_TRIG_ACT        ActionNone
#define DEF_FAI_SCANSRC         SignalNone
#define DEF_FAI_PAUSE_GATE      0
#define DEF_FAI_PASUE_POLAR     0

// AO default values
#define DEF_AO_GAIN             V_0To5
#define DEF_AO_EXT_REF_BIPOLAR  AO_EXT_REF_BIPOLAR
#define DEF_AO_EXT_REF_UNIPOLAR AO_EXT_REF_UNIPOLAR
#define DEF_AO_INIT_STATE       0

#define DEF_FAO_CHSTART         0
#define DEF_FAO_CHCOUNT         1
#define DEF_FAO_CLKSRC          SigInternalClock
#define DEF_FAO_PACERDIVISOR    (20 * 1000)
#define DEF_FAO_SECTSIZE        AO_FIFO_SIZE
#define DEF_FAO_MODE            DAQ_XFER_INT
#define DEF_FAO_TRIG_SRC        SignalNone
#define DEF_FAO_TRIG_ACT        ActionNone
#define DEF_FAO_TRIG_EDGE       RisingEdge

// DIO default values
#define DEF_DIO_DIR             0xff
#define DEF_DO_STATE            0xff

// CNTR default values
#define DEF_CNTR_CHIP_CLKSRC    SigInternalClock
#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_OST_CLKSRC     SigInternalClock
#define DEF_CNTR_OST_DELAYCNT   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      0
#define DEF_CNTR_PI_CLKSRC      SigInternalClock

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;
   __u32  ScanCount;            
   __u32  ScanClkSource;         
   double ScanClkRate;           
   __u32  ScanClkDivider;        
   __u32  FifoCount;          

   __u32  TrigAction;            
   __u32  TrigSource;          
   __u32  TrigEdge;              
   __u32  TrigDelayCount;       
   __u32  ActualDelayCount;      
   double TrigLevel;           
   __u16  TrigLevelBin;         
   __u32  AiPauseGateEn;         
   __u32  AiPauseGatePolarity;   
} FAI_CONFIG;

typedef struct _FAO_CONFIG
{
   __u32  ChanStart;  
   __u32  ChanCount;  

   __u32  ConvClkSource;          
   double ConvClkRatePerCH;       
   __u32  PacerDivider;          
   __u32  XferMode;             

   __u32  SectionSize;
   __u32  SampleCount; 
   __u32  SectionCount; 

   __u32  TrigAction;            
   __u32  TrigSource;           
   __u32  TrigEdge;           
}FAO_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  ReadyDataCount;       
   __u32  WPRunBack_TDtp;    
   __u32  OvrnOffset;
   __u32  OvrnCount;   
} FAI_STATUS;
//////////////////////////////////

typedef struct _RING_BUFFER_STATUS
{
   __u16   PPValue;     

   __u32   ReadPointer;    
   __u32   WritePointer;   

}RING_BUFFER_STATUS;

typedef struct _FAO_STATUS
{
   __u32      AcqMode;        
   __u32      FnState;             
   __u32      BufState;             

   __u32      BufLength;          
   __u32      WritePos;            
   __u32      ReadPos;             
   __u32      WPRunBack;       

   __u32      DataLeft;
   __u32      DataCopyCount;      
}FAO_STATUS;

//////////////////////////////////
typedef struct _CLK_INFO{
   __u32 ClkValue; 
   __u32 ClkId;    
}CLK_INFO;

typedef struct _CNTR_CONFIG
{
   __u32  ChipClkSource[ CNTR_CHL_COUNT ];
   __u32  ChipGateSource[ CNTR_CHL_COUNT ];
   __u32  ChipOpMode[ CNTR_CHL_COUNT ];
   __u32  ChipLoadValue[ CNTR_CHL_COUNT ];
   __u32  ChipHoldValue[ CNTR_CHL_COUNT ];
   __u32  ChipSigCntType[ CNTR_CHL_COUNT ];
   __u32  ChipClkPolarity[ CNTR_CHL_COUNT ];
   __u32  ChipGatePolarity[ CNTR_CHL_COUNT ];
   __u32  ChipOutSigType[ CNTR_CHL_COUNT ];

   // Event Count
   __u32  EcClkPolarity[ CNTR_CHL_COUNT ];
   __u32  EcGatePolarity[ CNTR_CHL_COUNT ];
   __u32  EcGateEnabled[ CNTR_CHL_COUNT ];

   // One-shot
   __u32  OsClkSource[ CNTR_CHL_COUNT ];
   __u32  OsGateSource[ CNTR_CHL_COUNT ];
   __u32  OsDelayCount[ CNTR_CHL_COUNT ];
   __u32  OsClkPolarity[ CNTR_CHL_COUNT ];
   __u32  OsGatePolarity[ CNTR_CHL_COUNT ];
   __u32  OsOutSigType[ CNTR_CHL_COUNT ];

   // Timer/Pulse
   __u32  TmrDivisor[ CNTR_CHL_COUNT ]; 
   __u32  TmrGatePolarity[ CNTR_CHL_COUNT ];
   __u32  TmrGateEnabled[ CNTR_CHL_COUNT ];
   __u32  TmrOutSigType[ CNTR_CHL_COUNT ];

   // Frequency measurement
   __u32  FmPeroid[ CNTR_CHL_COUNT ];
   __u32  FmMethod[ CNTR_CHL_COUNT ];

   // PwmIn 
   __u32  PiClkSource[ CNTR_CHL_COUNT ]; 
   // PWMOut
   __u32  PoHiPeriod[ CNTR_CHL_COUNT ]; 
   __u32  PoLoPeriod[ CNTR_CHL_COUNT ]; 
   __u32  PoGatePolarity[ CNTR_CHL_COUNT ];
   __u32  PoGateEnabled[ CNTR_CHL_COUNT ];
}CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;  
   __u32     CanRead;     
   __u32     Chan;        
   __u32     Overflow;  
   __u32     CheckPeriod;   
   __u32     PrevVal;       
   __u32     LoadValue;    
   __u32     HoldValue;    
   __u32     GateFreq;     
   __u32     PrevTime;     
   __u64     TotalTime;     

   struct  {  
      __u32  Head;        
      __u32  Tail;        
      __u16  CntrDelta[CNTR_RBUF_DEPTH];  
      __u32  TimeDelta[CNTR_RBUF_DEPTH];  
   };
}CNTR_STATE;


typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u64       BarPhyBase[PCIBAR_COUNTS];
   __u32       BarLength[PCIBAR_COUNTS];
   void*       BarMemBase[PCIBAR_COUNTS];
   __u32       KerPageSize;
   __u32       Irq;
   __u32       InitOnLoad;

   __u32       PcbVer;         // PCB Version
   __u32       PldVer;         // Programmable Logic Device Version
   __u32       FirmwareVer;    // Firmware version

   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;
   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;
   FAO_CONFIG  FaoParam;      
   FAO_STATUS  FaoStatus;      

   RING_BUFFER_STATUS AiRingBufStatus;
   RING_BUFFER_STATUS AoRingBufStatus;

   double      SaiAutoConvClkRate;            
   __u32       SaiAutoConvClkDiv;            
   __u32       SaiAutoConvChStart;         
   __u32       SaiAutoConvChCount;          

   __u32       CjcChan;         
   double      CjcUpdateFreq;
   double      CjcValue;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];    
   double      AoExtRefUnipolar;             
   double      AoExtRefBipolar;           
   __u32       AoChanState[AO_CHL_COUNT]; 
   // ---------------------------------------------------------
   __u8        DioPortDir[DIO_PORT_COUNT];
   __u8        DoPortState[DIO_PORT_COUNT];

   // ---------------------------------------------------------
   // Counter
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;

   // ---------------------------------------------------------
   // Interrupt flag
   __u8        AiIntFlag;      
   __u8        AoIntFlag;      
   __u8        CntrIntFlag;      

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
