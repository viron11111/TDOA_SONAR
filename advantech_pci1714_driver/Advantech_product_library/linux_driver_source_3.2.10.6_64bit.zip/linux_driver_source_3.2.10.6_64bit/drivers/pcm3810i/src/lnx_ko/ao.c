/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static inline
void  daq_ao_fill_chan_csr(unsigned chan, unsigned gain, DA_CONTROL_REG *csr)
{
   csr->Value = 0;

   if ( gain == V_ExternalRefBipolar || gain == V_ExternalRefUnipolar )
   {
      csr->RefSrc = 1;
      if ( gain == V_ExternalRefBipolar )
      {
         csr->Type = 1;
      }
   } else {
      switch ( gain )
      {
      case V_Neg10To10:
         csr->RefVol = 1;
         csr->Type = 1;
         break;
      case V_Neg5To5:
         csr->RefVol = 0;
         csr->Type = 1;
         break;
      case V_0To10:
         csr->RefVol = 1;
         break;
      case V_0To5:
      default:
         break;
      }
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DA_CONTROL_REG daCtrl = {0};
   int           i;

   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_fill_chan_csr(i, shared->AoChanGain[i], &daCtrl);
      AdxMemOutB(shared->BarMemBase[1], REG_DA_CH0_CONTROL + i * REG_STEP, daCtrl.Value);
   }

   AdxMemOutD(shared->BarMemBase[1], REG_DA_INTERRUPT_FLAG, 0xF);

   AdxMemOutD(shared->BarMemBase[1], REG_DA_RING_BUFFER_FLAG, 0);

   AdxMemOutD(shared->BarMemBase[1], REG_DA_READ_POINTER, 0);

   AdxMemOutD(shared->BarMemBase[1], REG_DA_MSI_CONTROL, 0);

   AdxMemOutD(shared->BarMemBase[1], REG_DA_INTERRUPT, 0);

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         AdxMemOutW(shared->BarMemBase[1], REG_DA_CH0_DATA + i * REG_STEP, shared->AoChanState[i]& AO_DATA_MASK);
         daq_trace(("AO Chan[%d], data= %d\n", i, shared->AoChanInitState[i]));
      }
      AdxMemOutB(shared->BarMemBase[1], REG_DA_TRIG_START, 1);
      AdxMemOutB(shared->BarMemBase[1], REG_DA_TRIG_START, 0);
   }
}

void daq_fao_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (faoStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   } else {
      faoStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

      AdxMemOutB(shared->BarMemBase[1], REG_DA_TRIG_START, 0);

      //Set DA Interrupt Enable register
      //The ConvEn and TrgEn bit must be set as 0 in SAO mode
      AdxMemOutD(shared->BarMemBase[1], REG_DA_INTERRUPT, 0);

      // send transfer stopped event if we haven't sent the event.
      if (!shared->IsEvtSignaled[KdxAoTransStopped])
      {
         shared->IsEvtSignaled[KdxAoTransStopped] = 1;
         daq_device_signal_event( daq_dev, KdxAoTransStopped);
      }

      shared->FaoStatus.WritePos = 0;
      if (shared->FaoStatus.AcqMode != DAQ_ACQ_INFINITE)
      {
         shared->FaoStatus.ReadPos = 0;
      }

      daq_device_signal_event(daq_dev,KdxAoStopped);
      wake_up_interruptible(&daq_dev->fao_queue);

      daq_trace(("AO RP=%d, WP=%d, WPRunback=%d\n", shared->FaoStatus.ReadPos, shared->FaoStatus.WritePos, shared->FaoStatus.WPRunBack));
      daq_trace(("<--FaoStopDataOutput\n"));
   }

   // release the resource for FAO operation
   if (cleanup) {
      daq_umem_unmap(&daq_dev->fao_buffer);

      spin_lock_irqsave(&daq_dev->fao_lock, flags);
      shared->FaoStatus.FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   }
}

static
void daq_ao_calc_section(DEVICE_SHARED *shared)
{
   FAO_CONFIG  *faoParam  = &shared->FaoParam;
   RING_BUFFER_STATUS *aoRingBufStatus = &shared->AoRingBufStatus;
   __u16       halfFifo = AI_FIFO_SIZE/2;

   if (faoParam->SectionSize >= halfFifo)
   {
      aoRingBufStatus->PPValue = halfFifo;
   }else
   {
      aoRingBufStatus->PPValue = faoParam->SectionSize;
   }

   daq_trace(("AO SampleCount=%d, SectionSize=%d,SectionReadyCount=%d PPValue is %d\n", faoParam->SampleCount, faoParam->SectionSize, faoStatus->SectionReadyCount, aoRingBufStatus->PPValue ));
}

static
void init_ao_ringbuffer(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   RING_BUFFER_STATUS *aoRingBufStatus = &shared->AoRingBufStatus;
   __u16         *data_buf = (__u16*)daq_dev->fao_buffer.kaddr;
   __u32         dataCount = AO_FIFO_SIZE;
   __u32         i;

   daq_ao_calc_section(shared);

   if ( faoStatus->BufLength < (AO_FIFO_SIZE) )
   {
      __u32 dataLeft;
      //Transfer the data from user buffer to FIFO
      for (i = 0; i < faoStatus->BufLength; ++i)
      {
         AdxMemOutW( shared->BarMemBase[2], AO_RING_BUFFER_OFFSET + i*4 + 2, data_buf[i]<<4 );
         faoStatus->ReadPos++;
         if ( ( i != 0 ) && ( ( i % shared->FaoParam.SectionSize ) == 0 ) )
         {
            if (!shared->IsEvtSignaled[KdxAoDataTransed])
            {
               shared->IsEvtSignaled[KdxAoDataTransed] = 1;
               daq_device_signal_event(daq_dev, KdxAoDataTransed);
            }
         }
      }

      shared->FaoStatus.ReadPos = 0;
      aoRingBufStatus->WritePointer = faoStatus->BufLength;

      //Fill the left FIFO space
      dataLeft = (AO_FIFO_SIZE) - faoStatus->BufLength;
      if ( shared->FaoStatus.AcqMode == FAO_MODE_INFINITE ) //Fill use the last data
      {
         while( dataLeft > 0 )
         {
            dataCount = dataLeft;
            if ( (shared->FaoStatus.ReadPos + dataCount) >= shared->FaoParam.SampleCount )
            {
               dataCount = shared->FaoParam.SampleCount - shared->FaoStatus.ReadPos;
               //This time do not clear the WPRunBack
            }

            if ( ( aoRingBufStatus->WritePointer + dataCount ) >= (AO_FIFO_SIZE) )
            {
               dataCount = ( (AO_FIFO_SIZE) - aoRingBufStatus->WritePointer );
            }

            for (i = 0; i < dataCount; ++i)
            {
               AdxMemOutW( shared->BarMemBase[2], AO_RING_BUFFER_OFFSET + (i + aoRingBufStatus->WritePointer)*4 + 2, data_buf[i + shared->FaoStatus.ReadPos]<<4 );
            }
            dataLeft -= dataCount;
            daq_trace(("UserBuf RP = %d, FIFO WP=%d, Count=%d, dataLeft=%d\n", shared->FaoStatus.ReadPos, aoRingBufStatus->WritePointer, dataCount, dataLeft));
            //Update the userBuffer RP
            shared->FaoStatus.ReadPos += dataCount;
            shared->FaoStatus.ReadPos %= (shared->FaoParam.SampleCount);

            aoRingBufStatus->WritePointer += dataCount;
            aoRingBufStatus->WritePointer %= AO_FIFO_SIZE;
         }
         aoRingBufStatus->WritePointer = 0;
      }
   shared->FaoStatus.DataLeft = 0;
   } else { //( faoStatus->UserBufLen > (AO_FIFO_SIZE) )
      for (i = 0; i < AO_FIFO_SIZE; ++i)
      {
         AdxMemOutW( shared->BarMemBase[2], AO_RING_BUFFER_OFFSET + i*4 + 2, data_buf[i]<<4 );
         if ( ( i != 0 ) && ( ( i % shared->FaoParam.SectionSize ) == 0 ) )
         {
            if (!shared->IsEvtSignaled[KdxAoDataTransed])
            {
               shared->IsEvtSignaled[KdxAoDataTransed] = 1;
               daq_device_signal_event(daq_dev, KdxAoDataTransed);
            }
         }
      }
      //Update the userBuffer RP
      shared->FaoStatus.ReadPos = AO_FIFO_SIZE;
      aoRingBufStatus->WritePointer = 0;
      shared->FaoStatus.DataLeft = faoStatus->BufLength - AO_FIFO_SIZE;
   }
   daq_trace(("UserBuf RP=%d, WP=%d, WPRunBack=%d; FIFO WP=%d\n", faoStatus->ReadPos, faoStatus->WritePos, faoStatus->WPRunBack, aoRingBufStatus->WritePointer));
}


static
int daq_fao_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
//   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;
   DA_MSI_CONTROL_REG daMsiCtrl = {0}; // Use continuous output operation mode, do not use the waveform output mode
   DA_MUX_REG daMux = {0};
   DA_INTERRUPT_REG daInt = {0};

   // Set DA Interrupt Enable register
   // The ConvEn and TrgEn bit must be set as 0 in SAO mode
   AdxMemOutD( shared->BarMemBase[1], REG_DA_INTERRUPT, 0 );

   // Clear DA interrupt Flag
   AdxMemOutD( shared->BarMemBase[1], REG_DA_INTERRUPT_FLAG, 0xF );

   // Clear DA Ring Buffer
   AdxMemOutD( shared->BarMemBase[1], REG_DA_RING_BUFFER_FLAG, 0 );

   // Reset DA ring buffer Read/Write pointer
   AdxMemOutD( shared->BarMemBase[1], REG_DA_READ_POINTER, 0 );

   // Set AO MSI control register
   daMsiCtrl.DaSyn = 1; // default enable the syn output
   if (  shared->FaoParam.TrigEdge == FallingEdge )
   {
      daMsiCtrl.DaTrgEdge = 1; // Falling
   }
   if ( shared->FaoParam.ConvClkSource != SigInternalClock )
   {
      daMsiCtrl.DaConv = 1; // Use external convert clock 
   }
   AdxMemOutD( shared->BarMemBase[1], REG_DA_MSI_CONTROL, daMsiCtrl.Value );

   // Set DA scan channel
   daMux.StartCh = shared->FaoParam.ChanStart;
   daMux.StopCh = (shared->FaoParam.ChanStart - 1 + shared->FaoParam.ChanCount) % AO_CHL_COUNT;
   AdxMemOutD( shared->BarMemBase[1], REG_DA_MUX, daMux.Value );

   // Set DA Pacer
   AdxMemOutD( shared->BarMemBase[1], REG_DA_CONV_CLK_DIVISOR, shared->FaoParam.PacerDivider );

   // Reset DA ring buffer Read/Write pointer
   AdxMemOutD( shared->BarMemBase[1], REG_DA_READ_POINTER, 0 );

   //Note: must wait enough time, for the hardware to stable
   //When switch the FAO to static mode, the hardware might still working in working state
   udelay(10);

   // Initialize the AORing Buffer and Calculate the SP to be filled into the REG_DA_SPECIFIC_POINTER
   init_ao_ringbuffer(daq_dev);
   // Set SP counter
   AdxMemOutW( shared->BarMemBase[1], REG_DA_PERIODIC_POINTER, shared->AoRingBufStatus.PPValue );


   // Set TrigSrc, internal or external
   // External trigger source have a enable gate, while the internal trigger source is always enabled
   // The HW logic is: AO_TRG = ((EXT_TRIG ^ DA_TRE) && TRIG_EN ) || INT_TRIG
   // Enable the EXt_TRIG if TrigSrc is set as external
   if ( ( shared->FaoParam.TrigAction != ActionNone ) && ( shared->FaoParam.TrigSource == SigExtDigTrigger0 ) )
   {
      daInt.TrgEn = 1;
   }
   daInt.ConvEn = 1;

   daInt.UnIntEn = 1;
   daInt.PpIntEn = 1;
   AdxMemOutD( shared->BarMemBase[1], REG_DA_INTERRUPT, daInt.Value );

   //
   // the next lines should be synchronized with interrupt
   if ( shared->FaoParam.TrigSource == SignalNone )
   {
      AdxMemOutB( shared->BarMemBase[1], REG_DA_TRIG_START, 1 );
   }

   // add the task to wait_queue for sync read
   if (faoStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fao_queue, faoStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}


int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }
   if (xbuf.SetWhich & AO_SET_EXTREFBI) {
      memcpy(&shared->AoExtRefBipolar, &xbuf.ExtRefBipolar, sizeof(shared->AoExtRefBipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      DA_CONTROL_REG chlCfg;
      __u32      i, ch, gains[AO_CHL_COUNT];

      if (unlikely(shared->FaoStatus.FnState == DAQ_FN_RUNNING)){
         return -EBUSY;
      }

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      for (i = 0; i < xbuf.ChanCount; ++i)
      {
         chlCfg.Value = AdxMemInD( shared->BarMemBase[1], REG_DA_CH0_CONTROL + i * REG_STEP );
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         daq_ao_fill_chan_csr(ch, gains[i], &chlCfg);
         shared->AoChanGain[ch] = gains[i];

         // Set AO channel configuration
         AdxMemOutD( shared->BarMemBase[1], REG_DA_CH0_CONTROL + i * REG_STEP, chlCfg.Value );
         daq_trace(("IoctlAoSetChanCfg, reg = 0x%x\n", chlCfg.Value));
      }
   }

   return 0;
}

int daq_ioctl_fao_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(shared->FaoStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaoParam           = xbuf;
      shared->FaoParam.ChanStart = xbuf.ChanStart & AO_CHL_MASK;
      shared->FaoParam.ChanCount = min(xbuf.ChanCount, (unsigned)AO_CHL_COUNT);
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fao_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long  flags;
   int            ret = 0;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   do{
      if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaoStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaoStatus, 0, sizeof(FAO_STATUS));
      shared->FaoStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaoStatus.AcqMode   = (__u32)arg;
      shared->FaoStatus.BufLength = shared->FaoParam.SampleCount;
      shared->FaoStatus.WPRunBack = 1; // I suppose the user had filled out the whole buffer.
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAoDataTransed);
   daq_device_clear_event(daq_dev, KdxAoUnderrun);
   daq_device_clear_event(daq_dev, KdxAoTransStopped);
   daq_device_clear_event(daq_dev, KdxAoStopped);

   ret = daq_fao_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fao_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!faoParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(faoStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faoStatus->FnState  = DAQ_FN_READY;
      faoStatus->BufLength= shared->FaoParam.SampleCount;
      faoStatus->WritePos = 0;
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      ret = daq_umem_map(arg, faoParam->SampleCount * AO_DATA_SIZE, 1, &daq_dev->fao_buffer);
   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fao_buffer);
      faoStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fao_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   if (arg & FAO_STOP_FREE_RES){
      daq_fao_stop_acquisition(daq_dev, 1);
      return 0;
   }

   if (arg & FAO_STOP_BREAK_NOW){
      daq_fao_stop_acquisition(daq_dev, 0);
      return 0;
   }

   if (shared->FaoStatus.AcqMode == DAQ_ACQ_INFINITE) {
      daq_fao_stop_acquisition(daq_dev, 0);
   }

   return 0;
}


