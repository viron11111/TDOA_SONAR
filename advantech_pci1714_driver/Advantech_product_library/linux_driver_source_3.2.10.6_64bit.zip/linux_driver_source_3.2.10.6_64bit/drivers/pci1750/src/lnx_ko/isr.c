/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

int daq_int_select_source(daq_device_t * daq_dev, int grp, int src, int edge, int eventKdx)
{
   DEV_INT_CSR csr;

   csr.Value = AdxIoInB(daq_dev->shared.IoBase, DR_INT_CSR) & (~DEV_INT_MASK);
   if (grp == 0) {
      if (csr.Grp0Mode == src) {
         return 0;
      }
      if (csr.Grp0Mode != INT_DISABLED) {
         return -EBUSY;
      }
      csr.Grp0Mode = src;
      csr.Grp0Edge = edge;
   } else {
      if (csr.Grp1Mode == src) {
         return 0;
      }
      if (csr.Grp1Mode != INT_DISABLED) {
         return -EBUSY;
      }
      csr.Grp1Mode = src;
      csr.Grp1Edge = edge;
   }
   if (eventKdx < KrnlSptedEventCount) {
      daq_dev->shared.IsEvtSignaled[eventKdx] = 0;
      daq_device_clear_event(daq_dev, eventKdx);
   }

   AdxIoOutB(daq_dev->shared.IoBase, DR_INT_CSR, csr.Value);

   return 0;
}

void daq_int_disable_source(daq_device_t * daq_dev, int grp, int src)
{
   DEV_INT_CSR csr;

    csr.Value = AdxIoInB(daq_dev->shared.IoBase, DR_INT_CSR) & (~DEV_INT_MASK);
    if (grp == 0) {
       if (csr.Grp0Mode != src || csr.Grp0Mode == INT_DISABLED) {
          return;
       }
       csr.Grp0Mode = INT_DISABLED;
       csr.Grp1Edge = TRIG_EDGE_FALLING;
    } else {
       if (csr.Grp1Mode != src || csr.Grp1Mode == INT_DISABLED) {
          return;
       }
       csr.Grp1Mode = INT_DISABLED;
       csr.Grp1Edge = TRIG_EDGE_FALLING;
    }

    AdxIoOutB(daq_dev->shared.IoBase, DR_INT_CSR, csr.Value);
}

// -----------------------------------------------------------------------------
static inline
void daq_int_snap_di_ports(__u32 ioBase, __u8 buffer[DIO_PORT_COUNT])
{
   buffer[0] = AdxIoInB(ioBase, DR_DI_PORTX(0));
   buffer[1] = AdxIoInB(ioBase, DR_DI_PORTX(1));
}

void daq_int_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   DEV_INT_CSR   csr;
   unsigned long flags;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   csr.Value = (__u8)shared->IntState;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // check interrupt state
   if (csr.Grp0Flag) {
      if (csr.Grp0Mode != INT_SRC_TIMER1) {
         daq_int_snap_di_ports(shared->IoBase, shared->DiSnap[0].State);
         if (!shared->IsEvtSignaled[KdxDiintChan0]) {
             shared->IsEvtSignaled[KdxDiintChan0] = 1;
             daq_device_signal_event(daq_dev, KdxDiintChan0);
          }
      } else {
         if (!shared->IsEvtSignaled[KdxCntTimer1]) {
             shared->IsEvtSignaled[KdxCntTimer1] = 1;
             daq_device_signal_event(daq_dev, KdxCntTimer1);
          }
      }
   }

   if (csr.Grp1Flag) {
      if (csr.Grp1Mode != INT_SRC_TIMER1) {
         daq_int_snap_di_ports(shared->IoBase, shared->DiSnap[1].State);
         if (!shared->IsEvtSignaled[KdxDiintChan8]) {
             shared->IsEvtSignaled[KdxDiintChan8] = 1;
             daq_device_signal_event(daq_dev, KdxDiintChan8);
          }
      } else {
         if (!shared->IsEvtSignaled[KdxCntTmnalCnt2]) {
             shared->IsEvtSignaled[KdxCntTmnalCnt2] = 1;
             daq_device_signal_event(daq_dev, KdxCntTmnalCnt2);
          }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u8 int_state = AdxIoInB(shared->IoBase, DR_INT_CSR);
   if (!(int_state & DEV_INT_MASK)) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   shared->IntState = int_state;
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->int_tasklet);

   // Clear interrupt
   AdxIoOutB(shared->IoBase, DR_INT_CSR, int_state);

   return IRQ_RETVAL(1);
}

