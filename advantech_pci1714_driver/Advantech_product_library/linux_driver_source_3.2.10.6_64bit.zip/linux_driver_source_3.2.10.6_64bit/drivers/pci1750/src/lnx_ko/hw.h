/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DR_DI_BASE         0
#define DR_DI_PORTX(x)     (DR_DI_BASE + x)

#define DR_DO_BASE         0
#define DR_DO_PORTX(x)     (DR_DO_BASE + x)

//#define DR_BID

#define INT_DISABLED          0
#define INT_SRC_DI            1
#define INT_SRC_DI_WITH_GATE  2
#define INT_SRC_TIMER1        3
#define INT_SRC_COUNTER2      3
#define TRIG_EDGE_RISING      1
#define TRIG_EDGE_FALLING     0

typedef union _DEV_INT_CSR{
   __u8 Value;
   struct{
      __u8 Grp0Mode : 2;
      __u8 Grp0Edge : 1;
      __u8 Grp0Flag : 1;
      __u8 Grp1Mode : 2;
      __u8 Grp1Edge : 1;
      __u8 Grp1Flag : 1;
   };
}DEV_INT_CSR;

#define DEV_INT_MASK   0x88
#define DR_INT_CSR     0x20

#define DR_CNTR0       0x18
#define DR_CNTR1       0x19
#define DR_CNTR2       0x1A
#define DR_CNTR_CTL    0x1B

#endif /* _KERNEL_MODULE_HW_H_ */
