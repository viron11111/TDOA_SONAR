//
// build_daq_fn.cpp : include all daq operation files for compiling.
//
#include "kdriver.h"

#include "cmn/hw.h"
#include "cmn/kshared.h"
#include "cmn/dev_fn.h"

#include "cmn/dev.c"
#include "cmn/ai.c"
#include "cmn/dio.c"
