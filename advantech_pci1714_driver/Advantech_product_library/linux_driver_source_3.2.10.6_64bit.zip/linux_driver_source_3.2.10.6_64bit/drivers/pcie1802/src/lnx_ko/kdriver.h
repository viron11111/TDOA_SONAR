/*
 * kdriver.h
 *
 *  Created on: 2015-06-10
 *      Author: 
 */

#ifndef _KERNEL_MODULE_H_
#define _KERNEL_MODULE_H_

#ifndef CONFIG_PCI
#  error "This driver needs to have PCI support."
#endif

#include <linux/pci.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/io.h>
#include <linux/workqueue.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <linux/delay.h>

#include <bdaqdef.h>
#include <biokernbase.h>

#include "ioctls_4.h"
#include "cmn/hw.h"
#include "cmn/kshared.h"

typedef struct _daq_file_ctx{
   struct list_head    list_entry;
   struct _daq_device *daq_dev;
   HANDLE              events[KEventCount];
   int                 write_access;
   int                 busy;
} daq_file_ctx_t;

typedef struct _daq_device
{
   daq_kshared_t         kshared;

   struct pci_dev       *pdev;
   struct cdev           cdev;
   unsigned char        *iomem_base[PCI_BAR_COUNT];       

   spinlock_t            dev_lock;
   struct tasklet_struct dev_tasklet;
   int                   remove_pending;
   struct list_head      file_ctx_list;
   int                   file_ctx_pool_size;
   daq_file_ctx_t        *file_ctx_pool;
   
   spinlock_t            fai_lock;
   wait_queue_head_t     fai_queue;
   daq_umem_t            fai_user_buf;
   daq_dmem_t            fai_ddma_buf;
   daq_dmem_t            fai_pdma_buf;
   daq_dmem_t            fai_tdma_buf;

   DEV_IF0_R             dev_if0;

} daq_device_t;


#define CVREGS  ((CARD_VER_R *)(daq_dev)->iomem_base[0])
#define IOREGS  ((IO_FUNC_R *)(daq_dev)->iomem_base[1])

/************************************************************************/
/* For compatible.                                                      */
/************************************************************************/
#define x_list_for_each_entry(pos, head, member, xtype) list_for_each_entry(pos, head, member)

#define x_event_set(handle)    daq_event_set(handle)
#define x_event_reset(handle)  daq_event_reset(handle)

#define x_dev_spin_lock(daq_dev,flags)          spin_lock_irqsave(&daq_dev->dev_lock, flags)
#define x_dev_spin_unlock(daq_dev,flags)        spin_unlock_irqrestore(&daq_dev->dev_lock, flags)

#define x_fai_spin_lock(daq_dev,flags)          spin_lock_irqsave(&daq_dev->fai_lock, flags);
#define x_fai_spin_unlock(daq_dev,flags)        spin_unlock_irqrestore(&daq_dev->fai_lock, flags)

#define x_irq_spin_lock(daq_dev,flags,in_isr)   spin_lock_irqsave(&daq_dev->dev_lock, flags)
#define x_irq_spin_unlock(daq_dev,flags,in_isr) spin_unlock_irqrestore(&daq_dev->dev_lock, flags)

#define x_fai_free_buffer(daq_dev)              lnx_fai_free_buffer(daq_dev)

static __inline void x_fai_complete_request(daq_device_t *daq_dev)
{
   wake_up_interruptible(&daq_dev->fai_queue);
}

/************************************************************************/
/* Functions                                                            */
/************************************************************************/
//
// init.c
//
void lnx_dev_cleanup(daq_device_t * daq_dev);

//
// fops.c
//
int  lnx_file_open(struct inode *in, struct file *fp);
int  lnx_file_close(struct inode *inode, struct file *filp);
int  lnx_file_mmap(struct file *filp, struct vm_area_struct *vma);
long lnx_file_ioctl(struct file *filp, unsigned int cmd, unsigned long um_arg);

void lnx_fai_free_buffer(daq_device_t *daq_dev);

//
// Device
//
int lnx_ioctl_dev_get_hw_info(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dev_get_drv_ver(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dev_get_location(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dev_reg_event(daq_device_t *daq_dev, daq_file_ctx_t *ctx, unsigned long um_arg);
int lnx_ioctl_dev_unreg_event(daq_device_t *daq_dev, daq_file_ctx_t *ctx, unsigned long um_arg);
int lnx_ioctl_dev_dbg_reg_in(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dev_dbg_reg_out(daq_device_t *daq_dev, unsigned long um_arg);

//
// AI
//
int lnx_ioctl_ai_set_chan(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_fai_exec(daq_device_t *daq_dev, unsigned long um_arg);

//
// DIO
//
int lnx_ioctl_dio_set_port(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dio_write_do_port(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dio_write_do_bit(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dio_set_int(daq_device_t *daq_dev, unsigned long um_arg);
int lnx_ioctl_dio_exec_di_snap(daq_device_t *daq_dev, unsigned long um_arg);

//
// isr.c
//
irqreturn_t lnx_interrupt_handler(int irq, void *dev_id);
void        lnx_interrupt_tasklet(unsigned long um_arg);

#endif /* _KERNEL_MODULE_H_ */
