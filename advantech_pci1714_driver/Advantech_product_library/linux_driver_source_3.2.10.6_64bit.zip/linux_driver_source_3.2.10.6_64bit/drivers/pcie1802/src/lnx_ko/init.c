/*
* init.c
*
*  Created on: 2015-06-10
*      Author: 
*/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/interrupt.h>

#include "kdriver.h"
#include "cmn/dev_fn.h"

// device supported
static struct pci_device_id dev_ids[] = {
   { PCI_DEVICE(ADVANTECH_VID, 0xE802) }, // PCIe-1802
   { PCI_DEVICE(ADVANTECH_VID, 0x0049) }, // PCIe-1802L
   { 0, }
};
MODULE_DEVICE_TABLE(pci, dev_ids);

/************************************************************************
* FILE OPERATIONS
************************************************************************/
static struct file_operations daq_fops = {
   .owner    = THIS_MODULE,
   .open     = lnx_file_open,
   .release  = lnx_file_close,
   .mmap     = lnx_file_mmap,
   .unlocked_ioctl = lnx_file_ioctl,
};

/************************************************************************
* sysfs support routines
************************************************************************/
#include "sysfs_helper_4.h"

// ------------------------------------------------------------------
// Device initialize/de-initailize
// ------------------------------------------------------------------
static void lnx_reserve_pages(void *ptr, unsigned size, int reserve)
{
   unsigned pages = PAGE_ALIGN(size);
   while (pages--) {
      if (reserve) {
         SetPageReserved(virt_to_page((unsigned long)ptr));
      } else {
         ClearPageReserved(virt_to_page((unsigned long)ptr));
      }
      ptr += PAGE_SIZE;
   }
}

static int __devinit lnx_dev_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
   dev_t          devid;
   daq_device_t  *daq_dev;
   daq_kshared_t *shared;
   struct device *sysfs_dev;
   size_t         mem_size;
   int            ret, res_idx;
   __u8           AID;

#define CHK_RESULT(_ok_, err, err_label)   if (!(_ok_)) { ret = err; goto err_label; }

   if ((ret = pci_enable_device(dev)) != 0) {
      daq_trace((KERN_ERR": pci_enable_device failed\n"));
      return ret;
   }
   pci_set_master(dev);   /* enable bus-master */

   // allocate private data structure
   mem_size = (sizeof(daq_device_t) + PAGE_SIZE - 1) & PAGE_MASK;
   daq_dev = (daq_device_t*)kzalloc(mem_size, GFP_KERNEL);
   CHK_RESULT(daq_dev, -ENOMEM, err_alloc_dev)

   // initialize the private data in the device
   shared                    = &daq_dev->kshared;
   shared->header.size       = sizeof(*shared);
   shared->header.dev_number = -1; // unknown
   shared->bus               = dev->bus->number;
   shared->slot              = PCI_SLOT(dev->devfn);
   shared->irq               = dev->irq;

   //Get product ID and hardware version
   switch (dev->device)
   {
   case 0x0049: shared->header.prod_id = BD_PCIE1802L; break;
   case 0xE802:
   default:     shared->header.prod_id = BD_PCIE1802;  break;
   }

   /* request IO resource */   
   for (res_idx = 0; res_idx < PCI_BAR_COUNT; ++res_idx) {
      /* request memory region*/
      shared->io_phy_base[res_idx] = dev->resource[res_idx].start & ~1UL;
      shared->io_length[res_idx]   = dev->resource[res_idx].end - shared->io_phy_base[res_idx] + 1;
      if (!request_mem_region(shared->io_phy_base[res_idx], shared->io_length[res_idx], DEV_NAME(shared))) {
         shared->io_phy_base[res_idx] = 0;
         CHK_RESULT(0, -EBUSY, err_no_res_mem);
      }

      /* mapping to memory space */
      daq_dev->iomem_base[res_idx] = ioremap(shared->io_phy_base[res_idx], shared->io_length[res_idx]);
      CHK_RESULT(daq_dev->iomem_base[res_idx], -EBUSY, err_no_res_mem);
   }

   /*test whether we got the memory resource in right order or not*/
   AID = CVREGS->AID;
   if (AID != 0xA5 && AID != 0x5A) {
      daq_trace((KERN_ERR "Bar order is wrong:1, aid = 0x%x\n", (unsigned int)AID));
      CHK_RESULT(0, -EINVAL, err_no_res_mem);
   }
   if ((__u8)~AID != CVREGS->AID) {
      daq_trace((KERN_ERR "Bar order is wrong:2\n"));
      CHK_RESULT(0, -EINVAL, err_no_res_mem);
   }

   /* request irq */
   ret = request_irq(shared->irq, (daq_irq_handler_t)lnx_interrupt_handler, IRQF_SHARED, DEV_NAME(shared), daq_dev);
   CHK_RESULT(ret == 0, ret, err_irq);

   /* initialize daq_dev structures*/
   spin_lock_init(&daq_dev->dev_lock);
   tasklet_init(&daq_dev->dev_tasklet, lnx_interrupt_tasklet, (unsigned long)daq_dev);

   INIT_LIST_HEAD(&daq_dev->file_ctx_list);
   daq_dev->file_ctx_pool_size = (mem_size - sizeof(daq_device_t)) / sizeof(daq_file_ctx_t);
   if (daq_dev->file_ctx_pool_size){
      daq_dev->file_ctx_pool = (daq_file_ctx_t *)(daq_dev + 1);
   } else {
      daq_dev->file_ctx_pool = NULL;
   }

   spin_lock_init(&daq_dev->fai_lock);
   init_waitqueue_head(&daq_dev->fai_queue);

   /* get device information */
   shared->board_id = CVREGS->BID;
   shared->pcb_ver  = CVREGS->PCB_VER;
   shared->pld_ver  = CVREGS->PLD_VER;
   shared->fw_ver   = CVREGS->FW_VER;

   daq_trace((KERN_INFO "BoardID: %x, PcbVer: %x, PldVer: %x, Fw: %x\n",\
      shared->board_id, shared->pcb_ver, shared->pld_ver, shared->fw_ver));

   /*Get dynamic device number*/
   devid = daq_devid_alloc();
   CHK_RESULT(devid > (dev_t)0, -ENOSPC, err_no_devid)

   /*register our device into kernel*/
   cdev_init(&daq_dev->cdev, &daq_fops);
   daq_dev->cdev.owner = THIS_MODULE;
   ret = cdev_add(&daq_dev->cdev, devid, 1);
   CHK_RESULT(ret == 0, ret, err_cdev_add)

   /* register our own device in sysfs, and this will cause udev to create corresponding device node */
   sysfs_dev = DAQ_SYSFS_INITIALIZE(devid, daq_dev);
   CHK_RESULT(!IS_ERR(sysfs_dev), PTR_ERR(sysfs_dev), err_sysfs_reg)

   // link the info into the other structures
   daq_dev->pdev = dev;
   pci_set_drvdata(dev, daq_dev);
   lnx_reserve_pages(&daq_dev->kshared, sizeof(daq_dev->kshared), 1);

   // initialize the device
   daq_dev_load_default_setting(daq_dev);
   daq_ai_initialize_hardware(daq_dev, 1);
   daq_dio_initialize_hardware(daq_dev, 1);

   // 
   ret = daq_dmem_alloc(&daq_dev->pdev->dev, AI_DATA_DMA_SIZE * AI_DATA_SIZE, &daq_dev->fai_ddma_buf);
   CHK_RESULT(ret == 0, ret, err_dma_buf)

   ret = daq_dmem_alloc(&daq_dev->pdev->dev, AI_WP_DMA_SIZE * AI_DATA_SIZE + AI_TRG_DMA_SIZE * sizeof(TRG_INFO_R), &daq_dev->fai_pdma_buf);
   CHK_RESULT(ret == 0, ret, err_dma_buf)

   daq_dev->fai_pdma_buf.size  = AI_WP_DMA_SIZE * AI_DATA_SIZE;
   daq_dev->fai_tdma_buf.size  = AI_TRG_DMA_SIZE * sizeof(TRG_INFO_R);
   daq_dev->fai_tdma_buf.kaddr = (uint8 *)daq_dev->fai_pdma_buf.kaddr + AI_WP_DMA_SIZE * AI_DATA_SIZE;
   daq_dev->fai_tdma_buf.daddr = daq_dev->fai_pdma_buf.daddr  + AI_WP_DMA_SIZE * AI_DATA_SIZE;

   // record the boot timestamp
   {
      struct timeval tv;

      shared->boot_tick = 0;
      IOREGS->TS_CNTH   = 0;

      do_gettimeofday(&tv);
      IOREGS->TS_CNTL   = 0;
      shared->boot_time = ((uint64)tv.tv_sec) * 1000 * 1000 + tv.tv_usec;
   }

   // Winning horn
   daq_trace((KERN_INFO "Add %s: major:%d, minor:%d\n", DEV_NAME(shared), MAJOR(devid), MINOR(devid)));
   daq_trace((KERN_INFO "dev base addr:[0x%p, %d], bid:%d\n", daq_dev->iomem_base[0], shared->io_length[0], shared->board_id));
   return 0;

err_dma_buf:
   if (daq_dev->fai_pdma_buf.kaddr) {
      daq_dev->fai_pdma_buf.size = AI_WP_DMA_SIZE * AI_DATA_SIZE + AI_TRG_DMA_SIZE * sizeof(TRG_INFO_R);
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fai_pdma_buf);
   }

   if (daq_dev->fai_ddma_buf.kaddr) {
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fai_ddma_buf); 
   }

   device_destroy(daq_class_get(), daq_dev->cdev.dev);

err_sysfs_reg:
   cdev_del(&daq_dev->cdev);

err_cdev_add:
   daq_devid_free(devid);

err_no_devid:
   free_irq(shared->irq, daq_dev);

err_irq:
err_no_res_mem:
   if (res_idx >= PCI_BAR_COUNT) { 
      --res_idx; 
   }

   for (; res_idx >= 0; --res_idx) {
      if (daq_dev->iomem_base[res_idx]) {
         iounmap(daq_dev->iomem_base[res_idx]);
      }
      if (shared->io_phy_base[res_idx]) {
         release_mem_region(shared->io_phy_base[res_idx], shared->io_length[res_idx]);
      }
   }

   kfree(daq_dev);

err_alloc_dev:
   pci_disable_device(dev);

   daq_trace((KERN_ERR "Add failed. error = %d\n", ret));
   return ret;
}

void lnx_dev_cleanup(daq_device_t * daq_dev)
{
   // delete dma buffer
   if (daq_dev->fai_pdma_buf.kaddr) {
      daq_dev->fai_pdma_buf.size = AI_WP_DMA_SIZE * AI_DATA_SIZE + AI_TRG_DMA_SIZE * sizeof(TRG_INFO_R);
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fai_pdma_buf);
   }

   if (daq_dev->fai_ddma_buf.kaddr) {
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fai_ddma_buf); 
   }

   // Delete device node under /dev
   cdev_del(&daq_dev->cdev);
   daq_devid_free(daq_dev->cdev.dev);
   device_destroy(daq_class_get(), daq_dev->cdev.dev);

   // Free the device information structure
   lnx_reserve_pages(&daq_dev->kshared, sizeof(daq_dev->kshared), 0);
   kfree(daq_dev);
}

static void __devexit lnx_dev_remove(struct pci_dev *dev)
{
   daq_device_t  *daq_dev = pci_get_drvdata(dev);
   daq_kshared_t *shared  = &daq_dev->kshared;
   int i;

   daq_trace((KERN_INFO"Device removed!\n"));

   free_irq(shared->irq, daq_dev);

   for (i = 0; i < PCI_BAR_COUNT; ++i) {
      iounmap(daq_dev->iomem_base[i]);
      release_mem_region(shared->io_phy_base[i], shared->io_length[i]);
   }

   pci_set_drvdata(dev, NULL);
   pci_disable_device(dev);

   {
      unsigned long flags;
      x_dev_spin_lock(daq_dev, flags);
      if (list_empty(&daq_dev->file_ctx_list)){
         x_dev_spin_unlock(daq_dev, flags);
         lnx_dev_cleanup(daq_dev);
      } else {
         daq_dev->remove_pending = 1;
         x_dev_spin_unlock(daq_dev, flags);
      }
   }
}

// ------------------------------------------------------------------
// Driver initialize/de-initailize
// ------------------------------------------------------------------
static struct pci_driver daq_driver = {
   .name     = DRV_NAME,
   .probe    = lnx_dev_probe,
   .remove   = __devexit_p(lnx_dev_remove),
   .id_table = dev_ids,
};

static int __init lnx_driver_init(void)
{
   return pci_register_driver(&daq_driver);
}

static void __exit lnx_driver_exit(void)
{
   pci_unregister_driver(&daq_driver);
}

module_init(lnx_driver_init);
module_exit(lnx_driver_exit);

MODULE_LICENSE("GPL");
