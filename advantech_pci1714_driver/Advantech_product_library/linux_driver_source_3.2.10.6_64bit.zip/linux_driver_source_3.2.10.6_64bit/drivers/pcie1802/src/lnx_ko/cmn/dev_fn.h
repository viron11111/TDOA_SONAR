#ifndef DAQNAVI_HW_ACCESS_H
#define DAQNAVI_HW_ACCESS_H

#ifdef __cplusplus
extern "C" {
#endif

// device 
void      daq_dev_load_default_setting(daq_device_t *daq_dev);
int       daq_dev_find_iomem_idx (daq_device_t *daq_dev, uint64 phy_addr);
void      daq_dev_signal_event   (daq_device_t *daq_dev, uint32 kdx);
void      daq_dev_clear_event    (daq_device_t *daq_dev, uint32 kdx);
int       daq_dev_is_event_active(daq_device_t *daq_dev, uint32 kdx);
ErrorCode daq_dev_dbg_reg_in     (daq_device_t *daq_dev, DBG_REG_IO *arg, uint8 *data);
ErrorCode daq_dev_dbg_reg_out    (daq_device_t *daq_dev, DBG_REG_IO *arg);

//
// AI
//
void      daq_ai_initialize_hardware(daq_device_t *daq_dev, int booting);
void      daq_ai_set_channel        (daq_device_t *daq_dev, AI_SET_CH *arg);
ErrorCode daq_fai_set_param         (daq_device_t *daq_dev, fai_config_t *arg);
ErrorCode daq_fai_start_acquisition (daq_device_t *daq_dev, uint32 acq_mode);
void      daq_fai_stop_acquisition  (daq_device_t *daq_dev, int cleanup);
void      daq_fai_update_rp_for_delay_to_stop(daq_kshared_t *shared, uint32 trg_src);

//
// DIO
//
void      daq_dio_initialize_hardware(daq_device_t *daq_dev, int booting);
ErrorCode daq_dio_set_port           (daq_device_t *daq_dev, DIO_SET_PORT *arg);
ErrorCode daq_dio_write_do_port      (daq_device_t *daq_dev, DIO_WRITE_PORT *arg);
ErrorCode daq_dio_write_do_bit       (daq_device_t *daq_dev, DIO_WRITE_BIT *arg);
ErrorCode daq_dio_set_int            (daq_device_t *daq_dev, DIO_SET_INT *arg);
ErrorCode daq_dio_exec_di_snap       (daq_device_t *daq_dev, DIO_EXEC_DISNAP *arg);

//
// ISR
//
static __inline 
uint8* daq_isr_dio_snap_di_port(daq_device_t *daq_dev, di_snap_t *snap)
{
   snap->state[0] = IOREGS->DI_DAT[0];
   return snap->state;
}

static __inline 
uint32 daq_isr_fai_calc_buf_state(fai_status_t *st, uint32 inc)
{
   // check running time st: overrun, data ready
   uint32 buf_state = 0;

   // check data ready and update write position
   if (st->wr_pos + inc >= st->buf_length) {
      buf_state  |= DAQ_IN_DATAREADY;
      st->wr_pos += inc;
      st->wr_pos %= st->buf_length;
      ++st->wp_run_back; 
   } else {
      if ((st->wr_pos % st->ov_sect_len) + inc >= st->ov_sect_len)  {
         buf_state |= DAQ_IN_DATAREADY;
      }
      st->wr_pos += inc;
   }

   // check overrun and buffer full
   if (st->wp_run_back) {
      int32 ov_cnt = st->wr_pos - st->rd_pos;

      buf_state |= DAQ_IN_BUF_FULL;

      if (st->wp_run_back > 1 || ov_cnt > 0) {
         buf_state |= DAQ_IN_BUF_OVERRUN;
         daq_trace(("DAQ_IN_BUF_OVERRUN -- wp_run_back: %d, wp: %d, rp: %d\n", st->wp_run_back, st->wr_pos, st->rd_pos));

         if (st->wp_run_back > 1) { 
            ov_cnt = st->buf_length;
         }
         st->ovrn_count  = ov_cnt;
         st->ovrn_offset = st->rd_pos;
      } 
   }

   return buf_state;
}

static __inline 
int daq_isr_fai_copy_data(daq_device_t *daq_dev, uint32 count, uint32 user_wp, uint32 rbuf_rp) 
{
   daq_kshared_t *shared     = &daq_dev->kshared;
   fai_status_t  *fai_status = &shared->fai_status;
   fai_record_t  *rec        = &shared->fai_status.records[shared->fai_status.rec_wp];

   uint32 *user_buf = (uint32 *)daq_dev->fai_user_buf.kaddr;
   uint32 *dma_buf  = (uint32 *)daq_dev->fai_ddma_buf.kaddr;
   uint32 start_pos = user_wp;

   while(count) {
      uint32 copied = count;
      if (copied > fai_status->buf_length - user_wp || copied > AI_DATA_DMA_SIZE - rbuf_rp) {
         copied = __min(fai_status->buf_length - user_wp, AI_DATA_DMA_SIZE - rbuf_rp);
      }

      memcpy(&user_buf[user_wp], &dma_buf[rbuf_rp], copied * AI_DATA_SIZE);

      count      -= copied;
      rec->wr_count += copied;
      user_wp     = (user_wp + copied) % fai_status->buf_length; 
      rbuf_rp     = (rbuf_rp + copied) & AI_DATA_DMA_MASK;      
   }

   {
      int    ret = 0;
      uint32 actual_sn = (user_buf[start_pos] >> 4) & 0xF;

      if (fai_status->prev_sn != -1 
         && ((fai_status->prev_sn + 1) % 0xD) != actual_sn) {
            ret =  DAQ_IN_CACHE_OVERFLOW;
            daq_trace(("DAQ_IN_CACHE_OVERFLOW -- prev sn: %d, new sn: %d\n", fai_status->prev_sn, actual_sn));
      }

      fai_status->prev_sn  = dma_buf[(rbuf_rp - 1) & AI_DATA_DMA_MASK] >> 4;
      fai_status->prev_sn &= 0xF;
      return ret;
   }
}

static __inline
void daq_isr_fai_update_record(daq_device_t *daq_dev) 
{
   fai_status_t *fai_status = &daq_dev->kshared.fai_status;
   fai_record_t *rec        = &fai_status->records[fai_status->rec_wp];
   TRG_INFO_R   *trg_buf    = (TRG_INFO_R *)daq_dev->fai_tdma_buf.kaddr;
   
   struct trg_buf_seg { TRG_INFO_R *start, *end; } segs[3];
   struct trg_buf_seg *seg_ptr = segs;

   uint32 fifo_wp;

   // pdma_buf[1] is trigger info write point, in samples(2 DWORD).;
   fifo_wp = ((uint32*)daq_dev->fai_pdma_buf.kaddr)[PDMA_TRIG_WP];    
   if (fifo_wp >= 64) {
      daq_trace(("**********error: tdma wp out of range\n"));
      fifo_wp &= 63;
   }
   if (fifo_wp == fai_status->tdma_wp) {
      return; // No trigger data
   }

   if (fifo_wp > fai_status->tdma_wp) {
      segs[0].start = &trg_buf[fai_status->tdma_wp];
      segs[0].end   = &trg_buf[fifo_wp];
      segs[1].start = NULL;
   } else {
      segs[0].start = &trg_buf[fai_status->tdma_wp];
      segs[0].end   = &trg_buf[AI_TRG_DMA_SIZE];
      segs[1].start = trg_buf;
      segs[1].end   = &trg_buf[fifo_wp];
      segs[2].start = NULL;
   }

   fai_status->tdma_wp = fifo_wp;

   for (; seg_ptr->start; ++seg_ptr) {

      TRG_INFO_R *p = seg_ptr->start;
      for (; p < seg_ptr->end; ++p) {
      
         if (p->TYPE == TRG_FN_START) {         
            rec->tmstmp_lo = p->TMSTMPL;
            rec->x_tmstmp  = p->TMSTMPH | FAI_REC_VALID;

            daq_trace(("------>start trigger, src: %d, timestamp[lo, hi] = [0x%x, 0x%x]\n", 
               p->SRC, rec->tmstmp_lo, rec->tmstmp_hi));

         } else if (p->TYPE == TRG_FN_STOP) {
            if (!rec->valid) {
               continue;
            }
            daq_trace(("------>stop trigger, src: %d, timestamp[lo, hi] = [0x%x, 0x%x]\n", 
               p->SRC, rec->tmstmp_lo, rec->tmstmp_hi));

            // close current record
            if (!rec->end) {
               ++fai_status->rec_count;
               rec->x_tmstmp |= FAI_REC_END;

               daq_fai_update_rp_for_delay_to_stop(&daq_dev->kshared, p->SRC);
            }

            // step to next record
            fai_status->rec_wp = (fai_status->rec_wp + 1) & FAI_REC_MASK;
            rec = &fai_status->records[fai_status->rec_wp];
            rec->x_tmstmp = 0;
            rec->rd_pos   = fai_status->wr_pos;
            rec->wr_count = 0;
            rec->rd_count = 0;

            // reset the data SN
            fai_status->prev_sn = -1;
         }
      }
   }
}

static __inline
int daq_interrupt_handler(daq_device_t *daq_dev)
{
   daq_kshared_t *shared = &daq_dev->kshared;

   uint32         fai_buf_state = 0;
   DEV_IF0_R      dev_if0;
   unsigned long  flags;
       
   dev_if0.xval = IOREGS->DEV_IF0.xval;
   if (!dev_if0.xval) {
      return 0;
   }

   // Clear interrupt
   IOREGS->DEV_IF0.xval = dev_if0.xval; 
   daq_trace(("----> INTERRUTP : 0x%x\n", dev_if0.xval));

   //
   // AI 
   //
   if ((dev_if0.xval & AI_INT_MASK) && shared->fai_status.fn_state == DAQ_FN_RUNNING) {
      /*if (dev_if0.AI_PC || dev_if0.AI_SC) {      
      }*/ 

      uint32 rb_wp   = ((uint32*)daq_dev->fai_pdma_buf.kaddr)[PDMA_DATA_WP] & AI_DATA_DMA_MASK;  
      uint32 rb_rp   = shared->fai_rb_status.RP;                                         
      uint32 user_wp = shared->fai_status.wr_pos;  

      fai_record_t *rec = &shared->fai_status.records[shared->fai_status.rec_wp];
      SW_TRG_R r_bkup;

      // DMA Buffer
      // |===========================================================|
      // 0           ^         ^                                     
      //             RP        WP
      //             |#########|Data to be Copied
      uint32 data_count =  (rb_wp >= rb_rp) ? (rb_wp - rb_rp) : (AI_DATA_DMA_SIZE + rb_wp - rb_rp);   

      // Finite Mode, only copy data till the end of the record
      if (shared->fai_status.rec_limit && data_count >= shared->fai_status.rec_limit - rec->wr_count) {
         data_count = shared->fai_status.rec_limit - rec->wr_count;

         // stop the conversion
         r_bkup.xval = IOREGS->AI_SWTRG.xval;
         IOREGS->AI_SWTRG.SWSTP = 1;
         IOREGS->AI_SWTRG.xval  = r_bkup.xval;
      }

      if (data_count) {
         fai_buf_state |= daq_isr_fai_copy_data(daq_dev, data_count, user_wp, rb_rp);
      }

      shared->fai_rb_status.RP = rb_wp;
      fai_buf_state |= daq_isr_fai_calc_buf_state(&shared->fai_status, data_count);

      daq_isr_fai_update_record(daq_dev);      
   }

   x_irq_spin_lock(daq_dev, flags, 1);
   daq_dev->dev_if0.xval |= dev_if0.xval;
   shared->fai_status.buf_state |= fai_buf_state;
   x_irq_spin_unlock(daq_dev, flags, 1);

   return 1;
}

static __inline
void daq_interrupt_tasklet(daq_device_t *daq_dev)
{
   daq_kshared_t *shared = &daq_dev->kshared;

   DEV_IF0_R      dev_if0;
   uint32         fai_buf_sta;
   uint32         fai_can_run;
   unsigned long  flags;

   x_irq_spin_lock(daq_dev, flags, 0);
   dev_if0.xval = daq_dev->dev_if0.xval;
   fai_buf_sta  = shared->fai_status.buf_state;

   daq_dev->dev_if0.xval = 0;
   shared->fai_status.buf_state = 0;
   x_irq_spin_unlock(daq_dev, flags, 0);

   if (dev_if0.xval & AI_INT_MASK) {

      fai_can_run = !shared->fai_param.rec_cycles || shared->fai_param.rec_cycles != shared->fai_status.rec_count;
      
      if (dev_if0.AI_CF) { // stop trigger received.
         if (!shared->event_signaled[KdxAiConvStopped]) {
            shared->event_signaled[KdxAiConvStopped] = 1;
            daq_dev_signal_event(daq_dev, KdxAiConvStopped);
         }

         if (fai_can_run) {
            // re-enable trigger
            IOREGS->AI_RETRGEN = 1;
            IOREGS->AI_RETRGEN = 0;

            // Start the next record if needed.
            IOREGS->AI_SWTRG.SWSTA = !!shared->fai_status.sw_start;
            daq_trace(("re-enable trigger, INT flag is: %x\n", dev_if0.xval));
         }
      }

      if ((fai_buf_sta & DAQ_IN_CACHE_OVERFLOW) 
         && !shared->event_signaled[KdxAiCacheOverflow]) {
         shared->event_signaled[KdxAiCacheOverflow] = 1;
         daq_dev_signal_event(daq_dev, KdxAiCacheOverflow);
      }

      if ((fai_buf_sta & DAQ_IN_BUF_OVERRUN) 
         && !shared->event_signaled[KdxAiOverrun]) {
         shared->event_signaled[KdxAiOverrun] = 1;
         daq_dev_signal_event(daq_dev, KdxAiOverrun);
      } 

      if ((fai_buf_sta & DAQ_IN_DATAREADY) 
         && !shared->event_signaled[KdxAiDataReady]) {
         shared->event_signaled[KdxAiDataReady] = 1;
         daq_dev_signal_event(daq_dev, KdxAiDataReady); daq_trace(("send data ready event\n"));
      }

      if (!fai_can_run) {
         daq_fai_stop_acquisition(daq_dev, 0);
      }
   }

   if (dev_if0.DI_p0B0) {
      daq_isr_dio_snap_di_port(daq_dev, &shared->di_snap[0]);
      if (!shared->event_signaled[KdxDiintChan0]) {
         shared->event_signaled[KdxDiintChan0] = 1;
         daq_dev_signal_event(daq_dev, KdxDiintChan0);
      }
   } 
}

#ifdef __cplusplus
}
#endif

#endif