#ifndef DAQNAVI4_KM_VERSION_H
#define DAQNAVI4_KM_VERSION_H

#undef  VER_PRODUCTVERSION
#undef  VER_PRODUCTVERSION_STR

#define VER_FILEVERSION             4,0,0,0
#define VER_FILEVERSION_STR         "4, 0, 0, 0"

#define VER_PRODUCTVERSION          4,0,0,0
#define VER_PRODUCTVERSION_STR      "4, 0, 0, 0"

#endif
