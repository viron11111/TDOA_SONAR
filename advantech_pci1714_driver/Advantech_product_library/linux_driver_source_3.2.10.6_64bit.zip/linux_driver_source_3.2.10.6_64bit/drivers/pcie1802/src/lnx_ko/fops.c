/*
 * fops.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"

#include "cmn/dev_fn.h"
#include "cmn/version.h"

static daq_file_ctx_t * lnx_file_alloc_ctx(daq_device_t *daq_dev)
{
   daq_file_ctx_t *ctx = NULL;
   unsigned long  flags;
   int i;

   if (likely(daq_dev->file_ctx_pool_size)){
      x_dev_spin_lock(daq_dev, flags);
      for (i = 0; i < daq_dev->file_ctx_pool_size; ++i){
         if (!daq_dev->file_ctx_pool[i].busy){
            ctx = &daq_dev->file_ctx_pool[i];
            ctx->busy = 1;
            break;
         }
      }
      x_dev_spin_unlock(daq_dev, flags);
   }

   if (ctx == NULL){
      ctx = (daq_file_ctx_t*)kzalloc(sizeof(daq_file_ctx_t), GFP_KERNEL);
   }

   if (ctx){
      INIT_LIST_HEAD(&ctx->list_entry);
      ctx->daq_dev = daq_dev;
   }

   return ctx;
}

static void lnx_file_free_ctx(daq_file_ctx_t *ctx)
{
   daq_device_t  *daq_dev = ctx->daq_dev;
   unsigned long flags;

   if (likely(daq_dev->file_ctx_pool_size
      && daq_dev->file_ctx_pool <= ctx
      && ctx < daq_dev->file_ctx_pool + daq_dev->file_ctx_pool_size)){
      x_dev_spin_lock(daq_dev, flags);
      ctx->busy = 0;
      x_dev_spin_unlock(daq_dev, flags);
   } else {
      kfree(ctx);
   }
}

void lnx_fai_free_buffer(daq_device_t *daq_dev)
{
   // user memory
   daq_umem_free(&daq_dev->fai_user_buf);

   // fn state
   daq_dev->kshared.fai_status.fn_state = DAQ_FN_IDLE;
}

//------------------------------------------------------------------------
// device Requests -------------------------------------------------------
//------------------------------------------------------------------------
int lnx_ioctl_dev_get_hw_info(daq_device_t *daq_dev, unsigned long um_arg)
{
   DEVICE_HWINFO hwinfo;
   hwinfo.DeviceNumber = daq_dev->kshared.header.dev_number;
   hwinfo.ProductId    = daq_dev->kshared.header.prod_id;
   hwinfo.BoardId      = daq_dev->kshared.board_id;
   hwinfo.BusSlot      = daq_dev->kshared.bus | (daq_dev->kshared.slot << 8);
   hwinfo.DriverSpec   = DRVSPEC_DN4;

   strncpy(hwinfo.DeviceName, DEV_NAME(&daq_dev->kshared), ARRAY_SIZE(hwinfo.DeviceName));
   strncpy(hwinfo.DeviceName, DRV_NAME,                    ARRAY_SIZE(hwinfo.DeviceName));

   if (unlikely(copy_to_user((void *)um_arg, &hwinfo, sizeof(hwinfo)))){
      return -EFAULT;
   }

   return 0;
}

int lnx_ioctl_dev_get_drv_ver(daq_device_t *daq_dev, unsigned long um_arg)
{
   if (unlikely(copy_to_user((void *)um_arg, VER_FILEVERSION_STR, sizeof(VER_FILEVERSION_STR)))){
      return -EFAULT;
   }

   return 0;
}

int lnx_ioctl_dev_get_location(daq_device_t *daq_dev, unsigned long um_arg)
{
   char loc[64];
   int  len;

   len = snprintf (loc, sizeof(64), "pci-%d-%d", daq_dev->kshared.bus, daq_dev->kshared.slot);
   if (unlikely(copy_to_user((void *)um_arg, loc, len + 1))){
      return -EFAULT;
   }

   return 0;
}

int lnx_ioctl_dev_reg_event(daq_device_t *daq_dev, daq_file_ctx_t *ctx, unsigned long um_arg)
{
   unsigned long flags;
   unsigned      kdx;
   uint32        event_id;
   HANDLE        event;

   if (unlikely(get_user(event_id, &((EVENT_INFO*)um_arg)->Id))){
      return -EFAULT;
   }

   kdx = kdxofEvent(event_id);
   if (likely(kdx < KEventCount)){
      event = ctx->events[kdx];
      if (event == NULL){
         event = daq_event_create();

         x_dev_spin_lock(daq_dev, flags);
         if (ctx->events[kdx] == NULL){
            ctx->events[kdx] = event;
         } else {
            daq_event_close(event);
            event = ctx->events[kdx];
         }
         x_dev_spin_unlock(daq_dev, flags);
      }

      put_user(event, &((EVENT_INFO*)um_arg)->Handle);
      return event != NULL ? 0 : -ENOMEM;
   }

   return -EINVAL;
}

int lnx_ioctl_dev_unreg_event(daq_device_t *daq_dev, daq_file_ctx_t *ctx, unsigned long um_arg)
{
   unsigned long flags;
   unsigned      kdx = kdxofEvent(um_arg);

   if (likely(kdx < KEventCount)){
      x_dev_spin_lock(daq_dev, flags);
      if (ctx->events[kdx] != NULL) {
         daq_event_close(ctx->events[kdx]);
         ctx->events[kdx] = NULL;
      }
      x_dev_spin_unlock(daq_dev, flags);
   }

   return 0;
}

int lnx_ioctl_dev_dbg_reg_in(daq_device_t *daq_dev, unsigned long um_arg)
{
   DBG_REG_IO arg;

   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }

   if (daq_dev_dbg_reg_in(daq_dev, &arg, (uint8*)&arg.Value) != Success) {
      return -EINVAL;
   }

   return put_user(arg.Value, &((DBG_REG_IO*)um_arg)->Value);
}

int lnx_ioctl_dev_dbg_reg_out(daq_device_t *daq_dev, unsigned long um_arg)
{
   DBG_REG_IO arg;

   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }

   if (daq_dev_dbg_reg_out(daq_dev, &arg) != Success){
      return -EINVAL;
   }

   return 0;
}

//------------------------------------------------------------------------
// AI Requests -----------------------------------------------------------
//------------------------------------------------------------------------
int lnx_ioctl_ai_set_chan(daq_device_t *daq_dev, unsigned long um_arg)
{
   unsigned char buffer[SIZEOF_VLST(AI_SET_CH, CHCfg, AI_CH_CNT_MAX)];
   AI_SET_CH *arg = (AI_SET_CH*)buffer;

   if (unlikely(daq_dev->kshared.fai_status.fn_state == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(arg, (void *)um_arg, sizeof(*arg)))){
      return -EFAULT;
   }
   if (unlikely(arg->PhyCHCount > AI_CH_CNT_MAX)) {
      return -EINVAL;
   }
   if (unlikely(copy_from_user(arg->CHCfg, ((AI_SET_CH*)um_arg)->CHCfg, arg->PhyCHCount * sizeof(AI_CH_CFG)))){
      return -EFAULT;
   }

   daq_ai_set_channel(daq_dev, arg);

   return 0;
}

int lnx_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long um_arg)
{
   fai_config_t arg;
   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }

   return daq_fai_set_param(daq_dev, &arg) == Success ? 0 : -EBUSY;
}

int lnx_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long um_arg)
{
   daq_kshared_t *shared     = &daq_dev->kshared;
   fai_config_t  *fai_param  = &shared->fai_param;
   fai_status_t  *fai_status = &shared->fai_status;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!fai_param->samp_count)) {
      return -EINVAL;
   }

   x_fai_spin_lock(daq_dev, flags);
   if (unlikely(fai_status->fn_state != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      fai_status->fn_state   = DAQ_FN_READY;
      fai_status->buf_length = fai_param->samp_count;
   }
   x_fai_spin_unlock(daq_dev, flags);

   if (unlikely(ret)){
      return ret;
   }

   ret = daq_umem_alloc(fai_param->samp_count * AI_DATA_SIZE, &daq_dev->fai_user_buf, 0);
   if (unlikely(ret)) {
      lnx_fai_free_buffer(daq_dev);
   }

   return ret;
}

int lnx_ioctl_fai_exec(daq_device_t *daq_dev, unsigned long um_arg)
{
   FAI_EXEC_ARG arg;
   ErrorCode ret = Success;

   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }
   
   switch(arg.Command)
   {
   case FAI_CMD_START:
      ret = daq_fai_start_acquisition(daq_dev, arg.AcqMode);
      if (ret == Success && arg.AcqMode == DAQ_ACQ_FINITE_SYNC) {
         return wait_event_interruptible(daq_dev->fai_queue, daq_dev->kshared.fai_status.fn_state != DAQ_FN_RUNNING);
      }
      break;
   case FAI_CMD_STOP:
      daq_fai_stop_acquisition(daq_dev, arg.StopFlag);    
      break;
   default:
      return -ENOTTY;
      break;
   }

   if(ret == Success) { return 0; } 
   return ret == ErrorFuncBusy ? -EBUSY : -EINVAL; 
}

//------------------------------------------------------------------------
// DIO Requests -----------------------------------------------------------
//------------------------------------------------------------------------
int lnx_ioctl_dio_set_port(daq_device_t *daq_dev, unsigned long um_arg)
{
   unsigned char buffer[sizeof(DIO_SET_PORT) + __max(sizeof(uint32), DIO_PORT_COUNT)];
   DIO_SET_PORT *arg = (DIO_SET_PORT*)buffer;

   if (unlikely(copy_from_user(arg, (void *)um_arg, sizeof(*arg)))){
      return -EFAULT;
   }
   if (arg->SetWhich == DIFLT_SET_BLKINTVL) {
      if (unlikely(copy_from_user(arg->Buffer, ((DIO_SET_PORT*)um_arg)->Buffer, sizeof(uint32)))){
         return -EFAULT;
      }
   } else {
      if (unlikely(arg->PortCount > DIO_PORT_COUNT)) {
         return -EINVAL;
      }
      if (unlikely(copy_from_user(arg->Buffer, ((DIO_SET_PORT*)um_arg)->Buffer, arg->PortCount))){
         return -EFAULT;
      }
   }
   
   return daq_dio_set_port(daq_dev, arg) == Success ? 0 : -ENOTTY;
}

int lnx_ioctl_dio_write_do_port(daq_device_t *daq_dev, unsigned long um_arg)
{
   uint8 xbuf[SIZEOF_VLST(DIO_WRITE_PORT, Data, DIO_PORT_COUNT)];
   DIO_WRITE_PORT *arg = (DIO_WRITE_PORT *)xbuf;
   if (unlikely(copy_from_user(arg, (void *)um_arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   return daq_dio_write_do_port(daq_dev, arg) == Success ? 0 : -EINVAL;
}

int lnx_ioctl_dio_write_do_bit(daq_device_t *daq_dev, unsigned long um_arg)
{
   DIO_WRITE_BIT arg;
   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }

   return daq_dio_write_do_bit(daq_dev, &arg) == Success ? 0 : -EINVAL;
}

int lnx_ioctl_dio_set_int(daq_device_t *daq_dev, unsigned long um_arg)
{
   unsigned char buffer[sizeof(DIO_SET_INT) + DI_SNAP_SRC_COUNT];
   DIO_SET_INT *arg = (DIO_SET_INT*)buffer;

   if (unlikely(copy_from_user(arg, (void *)um_arg, sizeof(*arg)))){
      return -EFAULT;
   }
   if (unlikely(arg->SrcCount > DI_SNAP_SRC_COUNT)) {
      return -EINVAL;
   }   
   if (unlikely(copy_from_user(arg->Buffer, ((DIO_SET_INT*)um_arg)->Buffer, arg->SrcCount))){
      return -EFAULT;
   }

   return daq_dio_set_int(daq_dev, arg) == Success ? 0 : -ENOTTY;
}

int lnx_ioctl_dio_exec_di_snap(daq_device_t *daq_dev, unsigned long um_arg)
{
   DIO_EXEC_DISNAP arg;
   if (unlikely(copy_from_user(&arg, (void *)um_arg, sizeof(arg)))){
      return -EFAULT;
   }

   return daq_dio_exec_di_snap(daq_dev, &arg) == Success ? 0 : -EINVAL;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
int lnx_file_open(struct inode *in, struct file *fp)
{
   daq_device_t   *daq_dev = container_of(in->i_cdev, daq_device_t, cdev);
   daq_file_ctx_t *ctx;
   unsigned long  flags;
   int            first_user, fmode_chk_ret = 0;

   if (unlikely(daq_dev->remove_pending)){
      return -ENODEV;
   }

   ctx = lnx_file_alloc_ctx(daq_dev);
   if (unlikely(ctx == NULL)){
      return -ENOMEM;
   }
   ctx->write_access = fp->f_mode & FMODE_WRITE;

   x_dev_spin_lock(daq_dev, flags);

   first_user = list_empty(&daq_dev->file_ctx_list);
   if (ctx->write_access){
      daq_file_ctx_t *curr;
      x_list_for_each_entry(curr, &daq_dev->file_ctx_list, list_entry, daq_file_ctx_t){
         if (curr->write_access) {
            fmode_chk_ret = -EPERM;
            break;
         }
      }
   }

   if (!fmode_chk_ret){
      list_add(&ctx->list_entry, &daq_dev->file_ctx_list);
      fp->private_data = ctx;
   }

   x_dev_spin_unlock(daq_dev, flags);

   if (fmode_chk_ret){
      lnx_file_free_ctx(ctx);
   }

   return fmode_chk_ret;
}

int lnx_file_close(struct inode *inode, struct file *filp)
{
   daq_file_ctx_t *ctx     = filp->private_data;
   daq_device_t   *daq_dev = ctx->daq_dev;
   unsigned long  flags;
   int            i, last_user;

   if (ctx->write_access) {
      daq_fai_stop_acquisition(daq_dev, 1);
   }

   x_dev_spin_lock(daq_dev, flags);
   list_del(&ctx->list_entry);
   last_user = list_empty(&daq_dev->file_ctx_list);
   x_dev_spin_unlock(daq_dev, flags);

   for (i = 0; i < KEventCount; ++i){
      if (ctx->events[i]){
         daq_event_close(ctx->events[i]);
         ctx->events[i] = NULL;
      }
   }

   lnx_file_free_ctx(ctx);

   if (last_user){
      if (daq_dev->remove_pending){
         lnx_dev_cleanup(daq_dev);
      }
   }

   return 0;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,6,23))
struct page * lnx_vma_nopage(struct vm_area_struct *vma, unsigned long address, int *type)
{
   daq_device_t *daq_dev = vma->vm_private_data;
   struct page     *page = NOPAGE_SIGBUS;
   unsigned long   pgoff = (address - vma->vm_start) >> PAGE_SHIFT;

   if (pgoff < daq_dev->fai_user_buf.nr_pages) {
      page = daq_dev->fai_user_buf.pages[pgoff];
      get_page(page);
   }

   return page;
}

static struct vm_operations_struct lnx_vm_ops = {
   .nopage = lnx_vma_nopage,
};
#else
static int lnx_vma_fault(struct vm_area_struct *vma, struct vm_fault *vmf)
{
   daq_device_t *daq_dev = vma->vm_private_data;
   unsigned long   pgoff = vmf->pgoff - vma->vm_pgoff;

   if (pgoff < daq_dev->fai_user_buf.nr_pages) {
      vmf->page = daq_dev->fai_user_buf.pages[pgoff];
      get_page(vmf->page);
      return 0;
   }

   return VM_FAULT_SIGBUS;
}

static struct vm_operations_struct lnx_vm_ops = {
   .fault = lnx_vma_fault,
};
#endif
int lnx_file_mmap(struct file *filp, struct vm_area_struct *vma)
{
   daq_device_t * daq_dev = ((daq_file_ctx_t *)filp->private_data)->daq_dev;

   if (vma->vm_pgoff == 0){
      if (vma->vm_end - vma->vm_start > PAGE_ALIGN(sizeof(daq_dev->kshared))) {
         return -EIO;
      }

      return remap_pfn_range(vma, vma->vm_start,
         virt_to_phys((void *)daq_dev) >> PAGE_SHIFT,
         vma->vm_end - vma->vm_start, vma->vm_page_prot);
   } else if (vma->vm_pgoff == 1024 * 1024 >> PAGE_SHIFT) {
      if (remap_pfn_range(vma, vma->vm_start,
         daq_dev->kshared.io_phy_base[1] >> PAGE_SHIFT,
         PAGE_SIZE, vma->vm_page_prot)){
            return -EAGAIN;
      }

      if (remap_pfn_range(vma, vma->vm_start + PAGE_SIZE,
         daq_dev->kshared.io_phy_base[3] >> PAGE_SHIFT,
         FLASH_MAP_SIZE, vma->vm_page_prot)){
            return -EAGAIN;
      }

      return 0;
   } else {
      if (!daq_dev->fai_user_buf.nr_pages) {
         return -EIO;
      }
      vma->vm_ops    = &lnx_vm_ops;
      vma->vm_flags |= VM_RESERVED;
      vma->vm_private_data = daq_dev;
      return 0;
   }
}

long lnx_file_ioctl(struct file *filp, unsigned int cmd, unsigned long um_arg)
{
   daq_file_ctx_t *ctx     = filp->private_data;
   daq_device_t   *daq_dev = ctx->daq_dev;
   int             ret     = 0;

   switch(cmd)
   {
   //******************************************************************************************
   // IOCTL for device operation                                                              *
   //******************************************************************************************
   case IOCTL_DEV_REGISTER_EVENT:
      ret = lnx_ioctl_dev_reg_event(daq_dev, ctx, um_arg);
      break;
   case IOCTL_DEV_UNREGISTER_EVENT:
      ret = lnx_ioctl_dev_unreg_event(daq_dev, ctx, um_arg);
      break;
   case IOCTL_DEV_TRIGGER_EVENT:
      {
         uint32 kdx = kdxofEvent((uint32)um_arg);
         if (kdx != -1) {
            daq_dev_signal_event(daq_dev, kdx); 
         } else {
            ret = -EINVAL;
         }
      }
      break;
   case IOCTL_DEV_GET_LOCATION:
      ret = lnx_ioctl_dev_get_location(daq_dev, um_arg);
      break;
   case IOCTL_DEV_DBG_REG_IN:
      ret = lnx_ioctl_dev_dbg_reg_in(daq_dev, um_arg);
      break;
   case IOCTL_DEV_DBG_REG_OUT:
      ret = lnx_ioctl_dev_dbg_reg_out(daq_dev, um_arg);
      break;
   case IOCTL_DEV_GET_DRV_VER:
      ret = lnx_ioctl_dev_get_drv_ver(daq_dev, um_arg);
      break;
   case IOCTL_DEV_GET_HWINFO: // Get HW INFO
      ret = lnx_ioctl_dev_get_hw_info(daq_dev, um_arg);
      break;

   //******************************************************************************************
   // IOCTL for AI operation                                                                 *
   //******************************************************************************************
   case IOCTL_AI_SET_CH:
      ret = lnx_ioctl_ai_set_chan(daq_dev, um_arg);
      break;
   case IOCTL_FAI_SET_PARAM:
      ret = lnx_ioctl_fai_set_param(daq_dev, um_arg);
      break;
   case IOCTL_FAI_SET_BUFFER:
      ret = lnx_ioctl_fai_set_buffer(daq_dev, um_arg);
      break;
   case IOCTL_FAI_EXEC:
      ret = lnx_ioctl_fai_exec(daq_dev, um_arg);
      break;

   //******************************************************************************************
   // IOCTL for DIO operation                                                                 *
   //******************************************************************************************
   case IOCTL_DIO_SET_PORT:
      ret = lnx_ioctl_dio_set_port(daq_dev, um_arg);
      break;
   case IOCTL_DIO_WRITE_DO_PORT:
      ret = lnx_ioctl_dio_write_do_port(daq_dev, um_arg);
      break;
   case IOCTL_DIO_WRITE_DO_BIT:
      ret = lnx_ioctl_dio_write_do_bit(daq_dev, um_arg);
      break;
   case IOCTL_DIO_SET_INT:
      ret = lnx_ioctl_dio_set_int(daq_dev, um_arg);
      break;
   case IOCTL_DIO_EXEC_DISNAP:
      ret = lnx_ioctl_dio_exec_di_snap(daq_dev, um_arg);
      break;

   default:
      ret = -ENOTTY;
      break;
   }

   return ret;
}
