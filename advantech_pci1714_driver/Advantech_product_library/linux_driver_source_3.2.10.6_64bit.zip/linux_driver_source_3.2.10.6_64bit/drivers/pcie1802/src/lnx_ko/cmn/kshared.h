// Note: 
//    This file is shared between kernel mode driver and user mode
// driver. So the definition must be consistent in both drivers. 

#ifndef DAQNAVI_KM_SHARED_H
#define DAQNAVI_KM_SHARED_H

//----------------------------------------------------------------------
// Common definition
#define ADVANTECH_VID            0x13fe
#define DEV_ID(kshr)             ((kshr)->header.prod_id == BD_PCIE1802 ? 0xE802 : 0x0049)

#define DRV_NAME                 "bio1802"
#define DRV_NAME_W              L"bio1802"

#define DEV_NAME(kshr)           ((kshr)->header.prod_id == BD_PCIE1802 ? "PCIE-1802" : "PCIE-1802L")
#define DEV_NAME_W(kshr)         ((kshr)->header.prod_id == BD_PCIE1802 ? L"PCIE-1802" : L"PCIE-1802L")

//----------------------------------------------------------------------
// AI definition
#define AI_CH_CNT_MAX            8
#define AI_CH_COUNT(kshr)        ((kshr)->header.prod_id == BD_PCIE1802 ? 8 : 4)
#define AI_CH_MASK(kshr)         ((kshr)->header.prod_id == BD_PCIE1802 ? 0x7 : 0x3)
#define AI_RES_IN_BIT            24
#define AI_DATA_SIZE             sizeof(uint32)
#define AI_DATA_MASK             ((uint32)0xFFFFFF00UL)
#define AI_SCL_TBL_RES           32

#define AI_MAX_PACER             (216*1000)        // 216KHz
#define AI_MIN_PACER             (100)

#define MAX_VAL_32BIT            ((uint32)0xFFFFFFFFUL)  

#define AI_DATA_DMA_SIZE         8192
#define AI_DATA_DMA_MASK         (AI_DATA_DMA_SIZE - 1)
#define AI_WP_DMA_SIZE           16
#define AI_WP_DMA_MASK           (AI_WP_DMA_SIZE - 1)
#define AI_TRG_DMA_SIZE          128
#define AI_TRG_DMA_MASK          (AI_TRG_DMA_SIZE - 1)

#define AI_TRIG_COUNT            2
#define AI_TRIG_HYS_INDEX_MAX    1.0
#define AI_TRIG_HYS_INDEX_STEP   16777215

#define IS_DELAY_TO_STOP_TRIG(faiParam) \
     (  ((faiParam).trigger[0].source != SignalNone && (faiParam).trigger[0].action == DelayToStop) \
     || ((faiParam).trigger[1].source != SignalNone && (faiParam).trigger[1].action == DelayToStop))

#define FAI_REC_SIZE             1024
#define FAI_REC_MASK             (FAI_REC_SIZE - 1)

#define TM_STMP_STEP             (1.0/25000000)  // 40ns

//----------------------------------------------------------------------
// DIO definition
#define DI_CH_COUNT              1
#define DO_CH_COUNT              2
#define DIO_PORT_COUNT           1
#define CH_PER_PORT              8

#define DI_INT_SRC_COUNT         1
#define DI_SNAP_SRC_COUNT        DI_INT_SRC_COUNT

#define DI_FLT_SRC_COUNT         1
#define DI_FLT_SMPL_INTVL_US     1        // Di filter sampling interval: 1us
#define DI_FLT_SMPL_INTVL_MS     1000     // Di filter sampling interval: 1ms
#define DI_FLT_SMPL_INTVL_USMS   0.001    // Di filter sampling interval: 0.001ms
#define DI_FLT_TIME_RANGE_MIN    1
#define DI_FLT_TIME_RANGE_MAX    255


//
// Kernel driver supported user notification event type.
typedef enum _KRNL_EVENT_IDX {
   // Device event
   KdxDevPropChged = 0,

   // AI event
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KdxAiConvStopped,

   // DIO event
   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDiEnd      = KdxDiintChan0,

   KEventCount
} KRNL_EVENT_IDX;

// Helper function used to map a user mode event type to kernel event index.
static __inline 
uint32 kdxofEvent(uint32 eventType)
{
   uint32 kdx;
   switch (eventType)
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;

   //AI Interrupt
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   case EvtBufferedAiConvStopped:   kdx = KdxAiConvStopped;   break;

   //DI Interrupt
   case EvtDiintChannel000:         kdx = KdxDiintChan0;      break;
   
   // not supported user event type
   default:                         kdx = -1;                 break; 
   }
   return kdx; 
}

typedef struct _sai_config {
   double  conv_clk_rate;     // clock rate per channel. Note: don't touch this field in kernel driver. 
   uint32  conv_clk_src;      // A/D conversion clock source. 
   uint32  samp_mode;         // ADC Sample Mode
   uint32  dds_tuning;        // DDS Tuning word
   uint32  deci_selector;     // ADC Decimation Selector
} sai_config_t;

typedef struct _trg_config {
   uint32  action;            // What will the device do when trigger occur, the device support DelayToStart, DelayToStop
   uint32  source;            // the trigger source
   uint32  edge;              // the valid source edge, Rising, Falling
   uint32  delay_count;       // the delay count of sample clock
   uint32  level_bin;         // The binary type of trigger level
   uint32  hyst_idx_bin;      // The binary type of trigger Hysteresis

   // The float type trigger level & Hysteresis, to save the user config
   double  level;             
   double  hyst_idx;         
} trg_config_t;

typedef struct _fai_config {
   // Data input Mode
   uint32  xfer_mode;               // transfer mode: INT vs DMA

   // channels to scan.
   uint32  phy_ch_start;            // Physical channel number of the start channel
   uint32  log_ch_count;            // logical channel count
   uint32  phy_ch_enabled;          // bit-mapped field, enabled channels

   // pacer & clock for AI sampling.
   uint32  conv_clk_src;            // A/D conversion clock source. 
   double  conv_clk_rate;           // clock rate per channel. Note: don't touch this field in kernel driver. 
   uint32  samp_mode;               // ADC Sample Mode
   uint32  dds_tuning;              // DDS Tuning Word
   uint32  deci_selector;           // ADC Decimation Selector

   // buffer setting
   uint32  sect_length;             // Ready date count when we send an AI 'data ready event'.
   uint32  sect_count;              // section count of the data buffer
   uint32  rec_cycles;              // record cycles 
   uint32  samp_count;              // total samples count the user wanted in finite acquisition or the user buffer
                                    // size in infinite acquisition.
   // trigger setting
   trg_config_t trigger[AI_TRIG_COUNT];

} fai_config_t;

#define FAI_REC_VALID   (0x1 << 26)
#define FAI_REC_END     (0x1 << 27)
typedef struct _fai_record {
   uint32 tmstmp_lo;
   union {
      uint32 x_tmstmp;
      struct {
         uint32 tmstmp_hi : 24;
         uint32 resv1     : 2;
         uint32 valid     : 1;
         uint32 end       : 1;
      };
   };
   uint32 rd_pos;                 // an index into user buffer the user should begin reading from.
   uint32 rd_count;
   uint32 wr_count;
} fai_record_t;

typedef struct _fai_status {
   uint32  acq_mode;              // FAI acquisition mode: sync, async, infinite, etc.
   uint32  fn_state;              // FAI running state: Idle, Ready, Running, Stopped.
   uint32  buf_state;             // FAI buffer status: buffer full, overrun, data ready.
   uint32  buf_length;            // sample count of the user buffer.

   uint32  ov_sect_len;           // overall section length
   uint32  sw_start;              // Need SW start trigger or not.
   uint32  prev_sn;               // serial number of the last data

   uint32  wr_pos;                // an index into user buffer the new data will be written to.
   uint32  rd_pos;                // moved to fai_record_t, as it should be a record variable
   uint32  wp_run_back;           // a non-zero value indicates how many times the 'wr_pos' run back to the buffer head.
   uint32  ovrn_offset;
   uint32  ovrn_count;

   // record status
   uint32  rec_limit;             // limitation of one record. 
   uint32  rec_count;             // record count totally generated.
   uint32  rec_rp;
   uint32  rec_wp;
   uint32  tdma_wp;
   fai_record_t records[FAI_REC_SIZE];

} fai_status_t;

// For FAI & FAO Ring Buffer status
typedef struct _fai_rb_status {
   uint32  SC;   // Section count 
   uint32  PP;   // Used By both
   uint32  RP;   // The last data position to copy to user buffer
} fai_rb_status_t;

typedef struct _di_snap {
   uint8 start;
   uint8 count;
   uint8 state[DIO_PORT_COUNT];
} di_snap_t;

typedef struct _daq_kshared {
   // ----------------------------------------------------------------------
   // Note: the 'header' must be the first field in the structure
   // ----------------------------------------------------------------------
   kshr_header  header;

   // HW Information	
   uint32       subsystem_id;    // Used to identify the variant of the HW which has more difference. 
   uint32	    board_id;	      // Board dip switch number for the device
   uint16	    bus;		         // PCI Bus number
   uint16	    slot;	         // PCI Slot number
   uint32       pcb_ver;         // PCB Version
   uint32       pld_ver;         // Programmable Logic Device Version
   uint32       fw_ver;          // Firmware version
   uint32       irq;             // interrupt number. 
   uint64       io_phy_base[PCI_BAR_COUNT]; 
   uint32       io_length[PCI_BAR_COUNT];      
   uint64       boot_tick;       // device startup tick in device timestamp 
   uint64       boot_time;       // device startup time since the Epoch (00:00:00 UTC, January 1, 1970), measured in microseconds.

   // AI setting 
   uint8        ai_ch_sctype[AI_CH_CNT_MAX];
   uint8        ai_ch_gain[AI_CH_CNT_MAX];
   uint8        ai_ch_cpl[AI_CH_CNT_MAX];
   uint8        ai_ch_iepe[AI_CH_CNT_MAX];
   uint32       ai_log_ch_count;

   // SAI configuration
   sai_config_t sai_param;

   // FAI configuration & Status
   fai_config_t     fai_param;     // parameters for FAI operation.
   fai_status_t     fai_status;    // status of FAI operation.
   fai_rb_status_t  fai_rb_status;  // status of AI ring buffer 

   // DIO Setting
   uint8          di_port_inverse[DIO_PORT_COUNT];
   uint8          do_port_state[DIO_PORT_COUNT];        // For Do port read-back(used when DO channel is freeze).
   uint8          diint_trig_edge[DI_INT_SRC_COUNT];
   uint8          diflt_ch_enabled [DI_FLT_SRC_COUNT];  // DI 'digital filter' enabled channels.
   uint32         diflt_blk_time;                       // DI 'digital filter' time range.
   di_snap_t      di_snap[DI_SNAP_SRC_COUNT];

   // Each element represent a cleanable event's status:
   // 0 -- the event had not been signaled or had been cleared, so we can signal it now if necessary.
   // 1 -- the event had been signaled and the user haven't cleared it, don't signal the event again.
   int32          event_signaled[KEventCount]; 

} daq_kshared_t;

#endif
