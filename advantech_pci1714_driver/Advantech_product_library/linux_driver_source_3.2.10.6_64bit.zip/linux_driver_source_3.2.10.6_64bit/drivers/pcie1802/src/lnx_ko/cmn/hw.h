#ifndef DAQNAVI_HW_DEFINE_H
#define DAQNAVI_HW_DEFINE_H

#define PCI_BAR_COUNT            4    
#define FW_PAGE_SIZE             4096
#define FW_NORMAL_SIZE           2048*1024 // 2048KB
#define FPGA_NORMAL_START        0x200000
#define FPGA_FACTORY_START       0x000000

#define FLASH_MAP_SIZE           (FW_PAGE_SIZE * 2)
#define FLASH_DELAY_IN_2us       1

#define INTERNAL_CLOCK           0x0
#define EXTERNAL_CLOCK           0x1

#define AI_INT_MASK              0x00000007
#define DI_INT_MASK              0x00010000

#define AC_EN_NONE               0           //Disable all channel
#define AC_VREF_5000mV           0           //Set voltage source to 5000mv
#define AC_VREF_4902mV           1           //Set voltage source to 4902mv
#define AC_VREF_1961mV           2           //Set voltage source to 1961mv
#define AC_VREF_980mV            3           //Set voltage source to 980mv
#define AC_VREF_490mV            4           //Set voltage source to 490mv
#define AC_VREF_196mV            5           //Set voltage source to 196mv
#define AC_VREF_0mV              6           //Set voltage source to 0mv
#define AC_VREF_DISABLE          7           //Set voltage source as disabled
#define AC_GAIN_COUNT_MAX        7

#define AC_CMD_LD_TO_RAM         0x70
#define AC_CMD_ST_TO_EEPROM      0x71
#define AC_CMD_WR_VREF           0x20
#define AC_CMD_RD_VREF           0xA0

#define AC_CMD_WR_OFFSET_BASE    0x00
#define AC_CMD_RD_OFFSET_BASE    0x80
#define AC_CMD_WR_GAIN_BASE      0x01
#define AC_CMD_RD_GAIN_BASE      0x81
#define AC_CMD_STEP              0x02

#define AC_CMD_WR_OFFSET(ch)     (AC_CMD_WR_OFFSET_BASE + ch * AC_CMD_STEP)
#define AC_CMD_RD_OFFSET(ch)     (AC_CMD_RD_OFFSET_BASE + ch * AC_CMD_STEP)
#define AC_CMD_WR_GAIN(ch)       (AC_CMD_WR_GAIN_BASE + ch * AC_CMD_STEP)
#define AC_CMD_RD_GAIN(ch)       (AC_CMD_RD_GAIN_BASE + ch * AC_CMD_STEP)

#define AC_DATA_CLEAR            0x00

#define AC_GAIN_INIT             0x800000
#define AC_OFFSET_INIT           0x800000
#define AC_OFFSET_MASK           0xFFFF0
#define AC_OFFSET_SHIFT          0x4
#define AC_SAMPLING_COUNT        1000

#define AI_CH_SCAN_EN            1
#define AI_CH_PSEDIF_EN          1
#define AI_CH_DC_COUPLED         1
#define AI_CH_IEPE_10mA          1           

#define ADC_SMOD_NORMAL          0
#define ADC_SMOD_X2              1
#define ADC_SMOD_X4              2

#define ADC_DFLT_RSPN_CLASSIC    0
#define ADC_DFLT_RSPN_LOWDELAY   1

#define DDS_ACMOD_NOP            0
#define DDS_ACMOD_UPD_OUTCLK     1
#define DDS_ACMOD_WR_REG         2 
#define DDS_ACMOD_UPD_ALL        3

#define TRG_FN_DISABLED          0
#define TRG_FN_START             1
#define TRG_FN_STOP              2       
#define TRG_FN_TMSTAMP           3   

#define TRG_EDGE_RISING          0    
#define TRG_EDGE_FALLING         1       

#define ANATRG_SRC_AIx(x)        (x)

#define TRG_OUTSRC_DISABLED      0
#define TRG_OUTSRC_DTRG0         2       
#define TRG_OUTSRC_DTRG1         3       
#define TRG_OUTSRC_ATRG0         4       
#define TRG_OUTSRC_ATRG1         5       
#define TRG_OUTSRC_SWSTA         6       
#define TRG_OUTSRC_SWSTP         7       

#define PDMA_DATA_WP             0
#define PDMA_TRIG_WP             1

#define FPGA_CMD_READ            1
#define FPGA_CMD_WRITE           2
#define FPGA_CMD_ERASE           3

//################################################################
// Common Type Information Registers (BAR0)

typedef struct CARD_VER_R {
   volatile uint8  BID     : 4;
            uint8  resv;
   volatile uint8  AID;
   volatile uint8  BARH    : 4;
   volatile uint32 PCB_VER;
   volatile uint32 PLD_VER;
   volatile uint32 FW_VER;
} CARD_VER_R;

//################################################################
// Common Type Control Registers (BAR1)
typedef union DEV_IF0_R {
   volatile uint32 xval;

   struct {
   //------------------
   volatile uint8 AI_PC   : 1;
   volatile uint8 AI_SC   : 1;
   volatile uint8 AI_CF   : 1;

   //------------------
            uint8 resv0;

   //------------------
   volatile uint8 DI_p0B0 : 1;

   //------------------
            uint8 resv1;
   };
} DEV_IF0_R;

typedef struct AC_CTL_R {
   volatile uint8  KLS;
   volatile uint8  AC_VREF;
   volatile uint16 AC_EN;
   volatile uint16 AC_DAT;
   volatile uint8  AC_CMD;
   volatile uint8  AC_BUSY;
} AC_CTL_R;

typedef union AI_CH_R {
   volatile uint8 xval;

   struct {
      volatile uint8 EN     : 1;
      volatile uint8 PSEDIF : 1;
      volatile uint8 CPLING : 1;
      volatile uint8 GAIN   : 3;
   };
} AI_CH_R;

typedef union AI_CH_IEPE_R {
   volatile uint8 xval;

   struct {
      volatile uint8 EN     : 1;
      volatile uint8 CURR   : 1;
   };
} AI_CH_IEPE_R;

typedef union DDS_CTL_R {
   volatile uint32 xval;

   struct {
      volatile uint8 PHASE   : 5;
      volatile uint8 PODWN   : 1;
               uint8 resv0[2];
      volatile uint8 RESET   : 1;
      volatile uint8 ACMOD   : 2;
               uint8 resv1   : 4;
      volatile uint8 BUSY    : 1;
   };
} DDS_CTL_R;

typedef union ADC_CTL_R {
   volatile uint32 xval;

   struct {
      volatile uint8 DECI : 5;
               uint8 resv0[2];
      volatile uint8 SMOD : 2;
      volatile uint8 DFLT : 1;
   };
} ADC_CTL_R;

typedef union DIGI_TRG_R {
   volatile uint8 xval;
   struct {   
   volatile uint8 FN   : 2;
            uint8 resv : 1;
   volatile uint8 EDG  : 1;
   volatile uint8 FDRM : 1;
   };
} DIGI_TRG_R;

typedef union ANA_TRG_R {
   volatile uint8 xval;
   struct {   
   volatile uint8 FN  : 2;
            uint8 resv: 1;
   volatile uint8 EDG : 1;
   volatile uint8 SRC : 4;
   };
} ANA_TRG_R;

typedef union SW_TRG_R {
   volatile uint32 xval;

   struct {
   volatile uint8 SWSTA   : 1;
            uint8 resv0   : 3;
   volatile uint8 SWSTP   : 1;

            uint8 resv1;

   volatile uint8 TOUT0SRC;
   volatile uint8 TOUT1SRC;
   };
} SW_TRG_R;

typedef struct TRG_INFO_R {
   volatile uint32 TMSTMPL;
   volatile uint32 TMSTMPH : 24;
   volatile uint32 TYPE    : 2;
   volatile uint32 resv    : 2;
   volatile uint32 SRC     : 4;
} TRG_INFO_R;

typedef union AI_IE_R {
   volatile uint32 xval;

   struct {
   volatile uint8 PC : 1;
   volatile uint8 SC : 1;
   volatile uint8 CF : 1;
   };
} AI_IE_R;

typedef union AI_CHFAULT_R {
   volatile uint8 xval;
   struct {   
   volatile uint8 IOV   : 1;
   volatile uint8 GOV   : 1;
   volatile uint8 DOVF  : 1;
            uint8 resv  : 1;
   volatile uint8 IEPEOPN : 1;
   volatile uint8 IEPESHT : 1;
   };
} AI_CHFAULT_R;

typedef union TEDS_CHSEL_R {
   volatile uint32 xval;
   struct {   
      volatile uint8 CH   : 4;
               uint8 resv : 3;
      volatile uint8 EN   : 1;
   };
} TEDS_CHSEL_R;

typedef union TEDS_CTL_R {
   volatile uint32 xval;
   struct {   
      volatile uint16 ADDR;

      volatile uint8  RCMD  : 3;
               uint8  resv0 : 1;
      volatile uint8  MCMD  : 2;
               uint8  resv1 : 1;
      volatile uint8  START : 1;

               uint8  resv2 : 7;
      volatile uint8  BUSY  : 1;
   };
} TEDS_CTL_R;

typedef struct DIO_CTL_R {
   volatile uint8 B0IE    : 1;
            uint8 resv0[3];

   volatile uint8 B0REDG  : 1;
   volatile uint8 B0FEDG  : 1;
            uint8 resv1[2];
   volatile uint8 B0DFEN  : 1;

   volatile uint8 DFDUR;
            uint8 resv2[3];
} DIO_CTL_R;

typedef struct IO_FUNC_R {
         DEV_IF0_R  DEV_IF0;
            uint32  resv0[15];

   //-------------------------------------------
          AC_CTL_R  ACC;
            uint32  resv1[46];

   //-------------------------------------------
   volatile uint32  AI_DDMAADRL;
   volatile uint32  AI_DDMAADRH;
   volatile uint32  AI_DDMASIZE;
   volatile uint32  AI_DDMAWPOS;

   volatile uint32  AI_PDMAADRL;
   volatile uint32  AI_PDMAADRH;

   volatile uint32  AI_TDMAADRL;
   volatile uint32  AI_TDMAADRH;
   volatile uint32  AI_TDMASIZE;
   volatile uint32  AI_TDMAWPOS;

   volatile uint32  AI_DMAEN;
   volatile uint32  AI_FIFOCLR;

           AI_CH_R  AI_CH[16];
      AI_CH_IEPE_R  AI_CHIEPE[16];
            uint32  resv2[16];

   volatile uint32  REF_CLKSRC;
   volatile uint32  DDS_TUNING;
         DDS_CTL_R  DDS_CTL;
         ADC_CTL_R  ADC_CTL;

   volatile uint32  AI_CHDAT[16];
        DIGI_TRG_R  AI_DTRG[2];
         ANA_TRG_R  AI_ATRG[2];
          SW_TRG_R  AI_SWTRG;

   volatile uint32  TS_CNTL;
   volatile uint32  TS_CNTH;
   volatile uint32  AI_DTRG0DNUM;
   volatile uint32  AI_DTRG0DCNT;
   volatile uint32  AI_DTRG1DNUM;
   volatile uint32  AI_DTRG1DCNT;
   volatile uint32  AI_ATRG0DNUM;
   volatile uint32  AI_ATRG0DCNT;
   volatile uint32  AI_ATRG1DNUM;
   volatile uint32  AI_ATRG1DCNT;
   volatile uint32  AI_ATRG0THRD;
   volatile uint32  AI_ATRG0HYST;
   volatile uint32  AI_ATRG1THRD;
   volatile uint32  AI_ATRG1HYST;
        TRG_INFO_R  AI_TRGINFO;
   volatile uint32  AI_RETRGEN;
            uint32  resv4[1];

           AI_IE_R  AI_IE;
            uint32  resv5[3];

   volatile uint32  AI_PNUM; 
   volatile uint32  AI_PCNT;
   volatile uint32  AI_SNUM;
   volatile uint32  AI_SCNT;

      AI_CHFAULT_R  AI_CHFAULT[16];

      TEDS_CHSEL_R  TEDS_CHSEL;
        TEDS_CTL_R  TEDS_CTL;
   volatile uint32  TEDS_RIDL; 
   volatile uint32  TEDS_RIDH; 
            uint32  resv6[36];

   //-------------------------------------------
    volatile uint8  DI_DAT[1];
             uint8  resv7[3];
    volatile uint8  DO_DAT[1];
             uint8  resv8[3];
       DIO_CTL_R    DIO_CTL;

} IO_FUNC_R;

//################################################################
// Common Type FPGA Flash R/W Registers (BAR3)
typedef union FPGA_CTL_R {
   volatile uint32 xval;
   struct{
      volatile uint8 ARM   : 1;
               uint8 resv0 : 3;
      volatile uint8 CMD   : 2;
               uint8 resv1 : 1;
      volatile uint8 CRCM  : 1;
   };
} FPGA_CTL_R;

typedef struct FPGA_FUNC_R {
        FPGA_CTL_R CTL;
   volatile uint32 ADDR;
   volatile uint32 LEN;
   volatile uint32 CRC;
   volatile uint8  DATA[FW_PAGE_SIZE];
} FPGA_FUNC_R;

//################################################################
// Others

typedef struct DEV_MEM_BAR {
   DECL_64COMPAT(uint8 *, Bar1);
   DECL_64COMPAT(uint8 *, Bar3);
} DEV_MEM_BAR, *PDEV_MEM_BAR;

#endif
