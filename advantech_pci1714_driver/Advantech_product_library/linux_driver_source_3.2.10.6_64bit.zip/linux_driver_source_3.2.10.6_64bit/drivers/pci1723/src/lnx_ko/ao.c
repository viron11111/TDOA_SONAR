/*
 * ao.c
 *
 *  Created on: 2016-08
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static inline
void daq_ao_set_chan_gain(DEVICE_SHARED *shared, unsigned chan, unsigned gain)
{
   AO_CHL_CSR csr = {0};
   switch (gain)
   {
   default:
   case V_Neg10To10: csr.GAIN = GAIN_Neg10To10; break;
   case mA_0To20:    csr.GAIN = GAIN_mA_0To20;  break;
   case mA_4To20:    csr.GAIN = GAIN_mA_4To20;  break;
   }
   csr.CHAN = chan;
   csr.MODE = CALI_MODE_SELF;

   AdxIoOutW(shared->IoBase, DR_AO_CHCSR, csr.Value);
   AdxIoOutW(shared->IoBase, DR_AO_CHGTYPE_STROBE, 0);
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int           i;

   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_set_chan_gain(shared, i, shared->AoChanGain[i]);
   }

   // enable synchronized output
   AdxIoOutW(shared->IoBase, DR_AO_SYNC_CTL, 0x1);

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         AdxIoOutW(shared->IoBase, DR_AO_CHDATA(i), shared->AoChanState[i] & AO_DATA_MASK);
      }

      // strobe the synchronized output
      AdxIoOutW(shared->IoBase, DR_AO_SYNC_STROBE, 0);
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      __u32 i, ch, gains[AO_CHL_COUNT];

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
         daq_ao_set_chan_gain(shared, ch, gains[i]);
      }
   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }

   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   AdxIoOutW(shared->IoBase, DR_AO_RESET_STROBE, 0x1);

   for(i = 0; i < xbuf.ChanCount; ++i)
   {
      ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
      if (AdxIoInW(shared->IoBase, DR_AO_CHDATA(ch)) != data[i]) {
         AdxIoOutW(shared->IoBase, DR_AO_CHDATA(ch), data[i]);
      }
   }

   // strobe the synchronized output
   AdxIoOutW(shared->IoBase, DR_AO_SYNC_STROBE, 0);

   return 0;
}
