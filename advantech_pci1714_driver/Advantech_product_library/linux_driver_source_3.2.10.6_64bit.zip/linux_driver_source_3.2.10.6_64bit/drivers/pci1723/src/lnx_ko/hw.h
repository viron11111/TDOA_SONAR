/*
 * hw.h
 *
 *  Created on: 2016-08
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AO Data
#define DR_AO_DATA_BASE   0x0
#define DR_AO_CHDATA(ch)  (DR_AO_DATA_BASE + ch * AO_DATA_SIZE)

#define DR_BID            0x10

#define GAIN_Neg10To10    0
#define GAIN_mA_0To20     2
#define GAIN_mA_4To20     3
#define CALI_MODE_SELF    1 

typedef union _AO_CHL_CSR{
   __u16 Value;
   struct{
      __u16 CHAN      : 3; 
      __u16 __resved0 : 1; 
      __u16 GAIN      : 2; 
      __u16 __resved1 : 2; 
      __u16 MODE      : 1; 
   };
} AO_CHL_CSR;

#define DR_AO_CHCSR       0x14

#define DR_AO_SYNC_CTL       0x12
#define DR_AO_SYNC_STROBE    0x20
#define DR_AO_RESET_STROBE   0x22
#define DR_AO_CHGTYPE_STROBE 0x26

#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _DIO_CSR {
   __u16 Value;
   struct{
      __u16 DIR_DIO0 : 1;
      __u16 DIR_DIO1 : 1;
   };
} DIO_CSR;
#define DR_DIO_CSR      0x1A

#define DR_DIO_DATA     0x1C


#endif /* _KERNEL_MODULE_HW_H_ */
