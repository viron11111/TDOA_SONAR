/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

static
int daq_cntr_can_share(__u32 cntr_ctl, __u32 new_op)
{
   if (cntr_ctl != CNTR_OP_IDLE) {
      if(cntr_ctl & new_op) {
         return 0;
      }

      cntr_ctl |= new_op;
      if (cntr_ctl & (CNTR_OP_ONESHOT | CNTR_OP_TIMERPULSE | CNTR_OP_PWMOUT)) {
         return 0;
      }
   }
   return 1;
}

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;
   CNTR_CTL_REG   cntr_ctl;
   CNTR_CFG_REG1  cntr_cfg1;
   CNTR_CFG_REG2  cntr_cfg2;

   while (count--) {

      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (daq_cntr_can_share(shared->CntrState[start].CntrCtrl, CNTR_OP_EVENTCOUNT)) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantEventCount;
         shared->CntrState[start].CntrCtrl |= CNTR_OP_EVENTCOUNT;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      //------------------------------------
      cntr_cfg2.Value = 0;
      cntr_cfg2.CRI   = CNTR_CRI_ENABLE;
      cntr_cfg2.COE   = CNTR_COE_DISABLE;
      if (shared->CntrConfig.EcGateEnabled[start]) {
         cntr_cfg2.GM = CNTR_GM_LAVELMODE;
         cntr_cfg2.GateSrc = CNTR_GS_EXNTERNAL;
      } 

      if (shared->CntrConfig.EcGatePolarity[start] == Negative) { 
         cntr_cfg2.GP = CNTR_GP_FALLING;
      }

      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE2, start), cntr_cfg2.Value);

      //------------------------------------
      cntr_cfg1.Value = 0;
      cntr_cfg1.ClkSrc = CNTR_CS_EXNTERNAL;
      if (shared->CntrConfig.EcClkPolarity[start] == Negative) {
         cntr_cfg1.ClkPolarity = CNTR_CP_FALLING;
      }

      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE1, start), cntr_cfg1.Value);

      //------------------------------------
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTR_LOAD_BASE, start), CNTR_MAX_VAL);

      //------------------------------------
      cntr_ctl.Value = 0;
      cntr_ctl.ARM   = CNTR_ARM_START;
      if (shared->CntrConfig.ClkFltEnabled[start]) {
         cntr_ctl.CDFE = CNTR_COFE_ENABLE;
         cntr_ctl.CDF = (__u8)shared->CntrConfig.ClkFltTime[start];
      }

      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCTL_X(REG_CNTRCTL_BASE, start), cntr_ctl.Value);

      ++start;
      start %= shared->Feature.CntrChanCount;
   }

   return 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   CNTR_CTL_REG  cntr_ctl;
   CNTR_CFG_REG1 cntr_cfg1;
   CNTR_CFG_REG2 cntr_cfg2;

   while (count--) {

      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (daq_cntr_can_share(shared->CntrState[start].CntrCtrl, CNTR_OP_FREQMETER)) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantFreqMeter;
         shared->CntrState[start].CntrCtrl |= CNTR_OP_FREQMETER;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      //------------------------------------
      cntr_cfg2.Value = 0;
      cntr_cfg2.CRI   = CNTR_CRI_ENABLE;
      cntr_cfg2.COE   = CNTR_COE_DISABLE;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE2, start), cntr_cfg2.Value);

      //------------------------------------
      cntr_cfg1.Value = 0;
      cntr_cfg1.ClkSrc    = CNTR_CS_EXNTERNAL;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE1, start), cntr_cfg1.Value);

      //------------------------------------
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTR_LOAD_BASE, start), CNTR_MAX_VAL);

      //------------------------------------
      cntr_ctl.Value = 0;
      cntr_ctl.ARM   = CNTR_ARM_START;
      if (shared->CntrConfig.ClkFltEnabled[start]) {
         cntr_ctl.CDFE = CNTR_COFE_ENABLE;
         cntr_ctl.CDF = (__u8)shared->CntrConfig.ClkFltTime[start];
      }
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCTL_X(REG_CNTRCTL_BASE, start), cntr_ctl.Value);

      ++start;
      start %= shared->Feature.CntrChanCount;
   }

   return 0;
}

static
int daq_cntr_start_pw_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   CNTR_CTL_REG  cntr_ctl;
   CNTR_CFG_REG1 cntr_cfg1;
   CNTR_CFG_REG2 cntr_cfg2;

   while (count--) {

      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (daq_cntr_can_share(shared->CntrState[start].CntrCtrl, CNTR_OP_PWMIN)) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantPwmIn;
         shared->CntrState[start].CntrCtrl |= CNTR_OP_PWMIN;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      //------------------------------------
      cntr_cfg2.Value = 0;
      cntr_cfg2.CRI   = CNTR_CRI_ENABLE;
      cntr_cfg2.COE   = CNTR_COE_DISABLE;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE2, start), cntr_cfg2.Value);

      //------------------------------------
      cntr_cfg1.Value = 0;
      cntr_cfg1.ClkSrc    = CNTR_CS_EXNTERNAL;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE1, start), cntr_cfg1.Value);

      //------------------------------------
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTR_LOAD_BASE, start), CNTR_MAX_VAL);

      //------------------------------------
      cntr_ctl.Value = 0;
      cntr_ctl.ARM   = CNTR_ARM_START;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCTL_X(REG_CNTRCTL_BASE, start), cntr_ctl.Value);

      ++start;
      start %= shared->Feature.CntrChanCount;
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_CTL_REG  cntr_ctl;
   CNTR_CFG_REG2 cntr_cfg;

   while (count--) {

      cntr_ctl.Value = 0;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCTL_X(REG_CNTRCTL_BASE, start), cntr_ctl.Value);

      cntr_ctl.CTR = 1;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCTL_X(REG_CNTRCTL_BASE, start), cntr_ctl.Value);

      cntr_cfg.Value = AdxMemInD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE2, start));
      cntr_cfg.INTE  = CNTR_INTE_DISABLE;
      AdxMemOutD(daq_dev->virt_base[1], REG_CNTRCFG_X(REG_CNTRCFG_BASE2, start), cntr_cfg.Value);

      AdxMemOutB(daq_dev->virt_base[1], REG_CNTRFLG_BASE, REG_CNTRFLG_X(start));

      shared->CntrState[start].Operation = CNTR_OP_IDLE;
      shared->CntrState[start].CntrCtrl  = CNTR_OP_IDLE;

      ++start;
      start %= shared->Feature.CntrChanCount;
   }
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= shared->Feature.CntrChanCount) {
      return -EINVAL;
   }

   if (cntr.Count > shared->Feature.CntrChanCount - cntr.Start) {
      cntr.Count = shared->Feature.CntrChanCount - cntr.Start;
   }

   switch (cntr.PropID)
   {
   //
   case CFG_EcClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.EcGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= daq_dev->shared.Feature.CntrChanCount 
      || cntr.Count > daq_dev->shared.Feature.CntrChanCount){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmIn:
      return daq_cntr_start_pw_measure(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_READ  cntr;
   CNTR_VALUE vals[CNTR_CHL_COUNT_MAX];
   CNTR_VALUE *curr = vals;
   
   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= daq_dev->shared.Feature.CntrChanCount
      || cntr.Count > daq_dev->shared.Feature.CntrChanCount){
      return -EINVAL;
   }

   while (cntr.Count--) {
      curr->Value   = AdxMemInD(daq_dev->virt_base[1], REG_CNTRVAL_X(REG_CNTRVAL_BASE1, cntr.Start));
      curr->CanRead = 1;

      ++curr;
      ++cntr.Start;
      cntr.Start %= daq_dev->shared.Feature.CntrChanCount;
   }

   if (unlikely(copy_to_user(cntr.Value, vals, (curr - vals) * sizeof(CNTR_VALUE)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= daq_dev->shared.Feature.CntrChanCount 
      || cntr.Count > daq_dev->shared.Feature.CntrChanCount){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
