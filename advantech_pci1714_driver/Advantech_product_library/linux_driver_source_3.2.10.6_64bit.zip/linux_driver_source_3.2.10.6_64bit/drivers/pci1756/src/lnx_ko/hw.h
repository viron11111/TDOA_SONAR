/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define PCI_DEVICE_ADDR_BAR 1

#define DR_DI_BASE         0
#define DR_DI_PORTX(x)     (DR_DI_BASE + x)

#define DR_DO_BASE         4
#define DR_DO_PORTX(x)     (DR_DO_BASE + x)

#define DR_BID             0x10

#define DI_INT_EN          (1 << 1)
#define TRIG_EDGE_RISING   (1 << 2)
#define TRIG_EDGE_FALLING  (0 << 2)

#define DI_INT_MASK        0x8  // bit 3 of each CSR
#define DI_INT_CSR_LEN     2
#define CT_INT_MASK        0x1  // bit 3 of each CSR

#define DR_DI_INT_CSR_BASE 0x8
#define DR_DI_INT_CSR(x)  (DR_DI_INT_CSR_BASE + (x * DI_INT_CSR_LEN))

#define DR_CHFreCSR        0x12

// Counter register control&status
#define DR_CT_MODE         0xC // Counter mode register
#define DR_CT_RESET        0xE // Counter reset register
#define DR_CT_READ         0x14 // Counter read value register
#define DR_CT_CSR          0x16 // Counter interrupt status register
#define DR_CT_WRITE        0x18 // Counter set value register

#endif /* _KERNEL_MODULE_HW_H_ */
