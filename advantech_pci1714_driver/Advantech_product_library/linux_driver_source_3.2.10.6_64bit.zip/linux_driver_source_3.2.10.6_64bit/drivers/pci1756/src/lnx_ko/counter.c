/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE *cntr;
   unsigned long flags;
   COUNTER_CONTROL_REG ctrlMode;
   __u16 ctrlValue;

   // Only Counter0 support Event Count
   if (start != 0 || count != 1) {
      return -EINVAL;
   }

   cntr = &shared->CntrState;
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (  cntr->Operation != CNTR_IDLE
      && cntr->Operation != InstantEventCount) {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   cntr->Operation = InstantEventCount;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxIoOutW(shared->IoBase, DR_CT_WRITE, 0xff); // set counter initial value

   ctrlMode.Value = 0;
   if (shared->CntrConfig.EcGateEnabled[0] == Enable) {
      if (shared->CntrConfig.EcGatePolarity[0] == Negative) {
         ctrlMode.CGATE = 0X2;
      } else {
         ctrlMode.CGATE = 0x1;
      }
   } else {
      ctrlMode.CGATE = 0X3;
   }

   ctrlMode.Interrupt = 0;
   ctrlMode.ClkSource = 0x0;
   ctrlMode.OutputControl = 0x2;
   ctrlValue = ctrlMode.Value;
   AdxIoOutW(shared->IoBase, DR_CT_MODE, ctrlValue);
   //TimerStart code
   shared->CntrChkTimerOwner = 1;
   schedule_delayed_work(&daq_dev->cntr_fm_work, 1);

   return 0;
}

static
int daq_cntr_start_timer_pulse( daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   COUNTER_CONTROL_REG ctrlMode;
   __u16 ctrlValue;

   //only counter 1 support Timer/Pulse output
   if (start != 0 || count != 1){
      return -EINVAL;
   }

   cntr = &shared->CntrState;
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (  cntr->Operation != CNTR_IDLE
      && cntr->Operation != TimerPulse) {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   cntr->Operation = TimerPulse;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxIoOutW(shared->IoBase, DR_CT_WRITE, shared->CntrConfig.TmrDivisor[0]); // set counter initial value

   ctrlMode.Value = 0;
   if(shared->CntrConfig.EcGateEnabled[0] == Enable) {
      if (shared->CntrConfig.EcGatePolarity[0] == Negative) {
         ctrlMode.CGATE = 0X2;
      } else {
         ctrlMode.CGATE = 0x1;
      }
   } else {
      ctrlMode.CGATE = 0X3;
   }
   ctrlMode.Interrupt = 0X1;
   ctrlMode.ClkSource = 0x1;
   ctrlMode.OutputControl = 0x2;
   ctrlValue = ctrlMode.Value;
   AdxIoOutW(shared->IoBase, DR_CT_MODE, ctrlValue);

   shared->IsEvtSignaled[KdxCntTimer0] = 0;
   return 0;
}


static inline
void daq_cntr_update_ec_state(CNTR_STATE *cntr, I825X_STATUS hw_st, __u32 hw_val, __s64 *tm_stamp)
{
   if (cntr->CanRead && cntr->PrevVal < hw_val){
      ++cntr->Overflow;
   }
   cntr->CanRead   = !hw_st.Null;
   cntr->PrevVal = hw_val;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_update_state_work_func(struct work_struct *work)
{
   daq_device_t    *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, cntr_fm_work);
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   I825X_STATUS    hw_st    = {0};
   struct timespec tm_now;
   __s64           tm_now_ns;
   __u32           hw_val,active = shared->CntrChkTimerOwner;

   getnstimeofday(&tm_now);
   tm_now_ns = timespec_to_ns(&tm_now);
   if(active & 0x1)
   {
	   hw_val = AdxIoInW(shared->IoBase, DR_CT_READ);
	   daq_cntr_update_ec_state(&shared->CntrState, hw_st, hw_val, &tm_now_ns);
   }
   if(shared->CntrChkTimerOwner)
   {
	   schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(CNTR_CHK_PERIOD_NS / 1000000L));
   }
}


//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   shared->CntrState.Operation = CNTR_IDLE;
   shared->CntrChkTimerOwner = 0;
   shared->CntrState.Overflow = 0;
   AdxIoOutW(shared->IoBase, DR_CT_MODE, 0x00);
   AdxIoOutW(shared->IoBase, DR_CT_RESET, 0x00);
   AdxIoOutW(shared->IoBase, DR_CT_CSR, 0x00);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void          *dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_EcGateEnabledOfCounters:
         dataPtr = &shared->CntrConfig.EcGateEnabled[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_EcGatePolarityOfCounters:
         dataPtr = &shared->CntrConfig.EcGatePolarity[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_ChipClkSourceOfCounters:
         dataPtr = &shared->CntrConfig.ChipClkSourceSource[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_ChipOperationModeOfCounters:
         dataPtr = &shared->CntrConfig.ChipOperationMode[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_ChipLoadValueOfCounters:
         dataPtr = &shared->CntrConfig.ChipLoadValue[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
         // for timer pulse
      case CFG_TmrFrequencyOfCounters:
         dataPtr = &shared->CntrConfig.TmrDivisor[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_TmrGateEnabledOfCounters:
         dataPtr = &shared->CntrConfig.TmrGateEnabled[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
      case CFG_TmrGatePolarityOfCounters:
         dataPtr = &shared->CntrConfig.TmrGatePolarity[cntr.Start];
         valLen  = sizeof(__u32) * cntr.Count;
         break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   I825X_STATUS   hw_st   = {0};
   CNTR_VALUE     ecVal;
   CNTR_READ      cntr;
   __u32          outLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   ecVal.Value = AdxIoInW(shared->IoBase, DR_CT_READ);
   daq_cntr_update_ec_state(&shared->CntrState, hw_st, ecVal.Value, 0);
   ecVal.Overflow = (__u16)shared->CntrState.Overflow;
   outLen = sizeof(CNTR_VALUE);

   return copy_to_user(cntr.Value, &ecVal, outLen);
}

int daq_ioctl_cntr_start(daq_file_ctx_t *file_ctx, unsigned long arg)
{
   daq_device_t *daq_dev = file_ctx->daq_dev;
   CNTR_START cntr;

   int ret = 0;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
   switch(cntr.Operation)
   {
   case InstantEventCount:
      ret = daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
      break;
   case TimerPulse:
      ret = daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
      break;
   default:
      return -ENOSYS;
   }

   if (!ret) {
      file_ctx->used_resource |= CT_X(0);
   }

   return ret;
}

int daq_ioctl_cntr_reset(daq_file_ctx_t *file_ctx, unsigned long arg)
{
   daq_device_t *daq_dev = file_ctx->daq_dev;
   CNTR_RESET cntr;
   unsigned used_res;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   used_res = daq_device_count_used_resource(daq_dev);
   if (!(used_res & CT_X(0))) {
      daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);
   }

   return 0;
}
