/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1756
#define DEVICE_ID_MIC3756     0x3756
#define DEVICE_PID    BD_PCI1756
#define DEVICE_PID_MIC3756 BD_MIC3756
#define DEVICE_NAME   "PCI-1756"
#define DEVICE_NAME_MIC3756 "MIC-3756"
#define DRIVER_NAME   "bio1756"

#define DEVICE_NAME_FROM_PID(pid) \
   (pid == BD_PCI1756 ? "PCI-1756" : "MIC-3756")

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT		   4 // 4 isolated DI, 4 isolated DO,
#define DIO_CHL_COUNT         (DIO_PORT_COUNT * 8)
#define DI_INT_SRC_COUNT      2  // CH#[0, 16]
#define DI_SNAP_SRC_COUNT     DI_INT_SRC_COUNT

// for Counter const parameter
#define CNTR_CHL_COUNT        1
#define CNTR_TIMER_PULSE_MAX_FREQ   ( 500 * 1000 ) // isolation pin, so it is slowly
#define CNTR_TIMER_PULSE_MIN_FREQ   0.2

#define CNTR_RES_IN_BIT          16
#define CNTR_CLK_BASE               (1 * 500 * 1000)									//500k

#define CNTR_CHK_PERIOD_MS       5                                        // using a 5ms timer for overflow check and freq measure

#define CNTR_TIMER_PULSE_MAX_DIV    0xffff
#define CNTR_TIMER_PULSE_MIN_DIV    0x1

#define CNTR_IDLE                0

#define DEF_TMR_FREQ             10
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             65535
#define CNTR_TIMER_PULSE_MAX_FREQ   ( 500 * 1000 ) // isolation pin, so it is slowly
#define CNTR_TIMER_PULSE_MIN_FREQ   0.2

#define CNTR_RBUF_DEPTH          16                                       // using a 2^n to avoid using '%'(mod) calculation.
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)                     // the mask of 'POS' of counter ring-buffer
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10

// CNTR default values
#define DEF_CNTR_CHIP_CLKSRC    SigInternalClock
#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_TMR_GATE_ENABLE     0
#define DEF_CNTR_TMR_GATE_POLARITY_RISING    1

#define  DI_INT_X(n) (1 << n)
#define  CT_X(n)     ((1 << DI_SNAP_SRC_COUNT) << n)

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDiintChan16,
   KdxDiEnd = KdxDiintChan16,
   KdxCntTimer0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   case EvtDiintChannel000: kdx = KdxDiintChan0;   break;
   case EvtDiintChannel016: kdx = KdxDiintChan16;   break;
   case EvtCntTimer0:       kdx = KdxCntTimer0;  break;
   default: kdx = -1; break;
   }
   return kdx;
}


// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP
{
   __u8 Start;
   __u8 Count;
   __u8 State[DIO_PORT_COUNT];
} DI_SNAP;

//------------------------------------------------------------
// For counter parameter
//------------------------------------------------------------
enum _GATE_MODE
{
   NoGate    = 0X0,
   LevelMode = 0X1,
   EdgeMode  = 0X2,
   EdgeRetriggerMode = 0X3,
} ;

#define  Negative  0
#define  Positive  1
#define  Disable  0
#define  Enable  1

typedef struct _CNTR_CONFIG
{
   // To simplify the operation of property access,
   // the structure is defined as following.
   // Primal counter
	__u32  ChipClkSourceSource[ CNTR_CHL_COUNT ];    // the clock source is selected by jumper, not software
	__u32  ChipOperationMode[ CNTR_CHL_COUNT ];
	__u32  ChipLoadValue[ CNTR_CHL_COUNT ];
   //================================
   // event count
	__u32  EcGatePolarity[ CNTR_CHL_COUNT ];
	__u32  EcGateEnabled[ CNTR_CHL_COUNT ];
	__u32  GateSrc[CNTR_CHL_COUNT];
   // Timer/Pulse
	__u32  TmrDivisor[CNTR_CHL_COUNT]; // Timer/Pulse frequency, in counter divisor
	__u32  TmrGatePolarity[ CNTR_CHL_COUNT ];
	__u32  TmrGateEnabled[ CNTR_CHL_COUNT ];

} CNTR_CONFIG;

typedef union _COUNTER_CONTROL_REG{
	__u32 Value;
   struct{
		__u32 CGATE         : 2; //Counter Gate Control
		__u32 Interrupt     : 1; //Counter Interrupt Enable
		__u32 ClkSource     : 1; //Counter Clock Source Control
		__u32 OutputControl : 2; //Counter Output Control
		__u32 Reserved1     : 2;
		__u32 Reserved2     : 8;
		__u32 Reserved3     : 8;
   };

}COUNTER_CONTROL_REG;


typedef struct _CNTR_STATE
{
   __u32        Operation;                   // the operation the counter is running
   __u32        CanRead;                     // whether the counter can be read or not.

   // event counting running time state ------------------------------------------------
   __u32     Overflow;  // overflow count of the counter. for event count.

   // frequency measurement running time state------------------------------------------
   __u32     CheckPeriod;   // period to check the counter status & value, in 100ns unit.
   __u32     PrevVal;       // the previous counter value in raw format.
   __u32     SummedValue;   // accumulated counter value. for freq measurement mainly.
   __s64     PrevTime;      // the previous timestamp, in 100ns unit.
   __u64 TotalTime;     // elapsed time for counting up to the 'Summed' value, in 100ns unit.

   struct  {  // using a ring-buffer to accumulate the counter value
	   __u32  Head;        // data position of the oldest data
      __u32  Tail;        // data position of the latest data.

      // for data alignment, these two field are defined separately.
      __u32 CntrDelta[CNTR_RBUF_DEPTH];  // the difference of counter value with the previous one.
      __u32  TimeDelta[CNTR_RBUF_DEPTH];  // the timestamp of the counter value, in 100ns unit.
   };
}CNTR_STATE;
typedef struct _CNTR_STATE* PCNTR_STATE;
#define CNTR_CHL_COUNT_MAX		1


typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number

   // HW Information
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   IoBase;
   __u32   IoLength;
   __u32   Irq;
   __u32   InitOnLoad;
   __u32   DoFreezeEnabled;

   // --------------------------------------------------------
   __u8    DoPortState[DIO_PORT_COUNT];
   __u8    DiintTrigEdge[DI_INT_SRC_COUNT];
   DI_SNAP DiSnap[DI_SNAP_SRC_COUNT];

   // ---------------------------------------------------------
   CNTR_CONFIG  CntrConfig;
   CNTR_STATE   CntrState;
   __u32        CntrChkTimerOwner;  // bit-mapped field indicates who owns the WDFTIMER for counter

   // ---------------------------------------------------------
   __u32   IntState;
   __u32   IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
