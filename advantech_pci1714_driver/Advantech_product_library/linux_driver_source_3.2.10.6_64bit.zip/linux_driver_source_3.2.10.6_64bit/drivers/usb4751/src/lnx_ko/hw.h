/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// DIO port group configuration register
#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _DIO_GRP_CTRL_REG {
   __u32 Value;
   struct {
      __u8 PCLowDir : 1;  // Port C lower bits:  0 -- output, 1 -- input
      __u8 PBDir    : 1;  // Port B:             0 -- output, 1 -- input
      __u8 Reserved : 1;
      __u8 PCHighDir: 1;  // Port C higher bits: 0 -- output, 1 -- input
      __u8 PADir    : 1;  // Port A:             0 -- output, 1 -- input
      __u8 Reserved2: 3;
   };
} DIO_GRP_CTRL_REG;

// interrupt control & status register
#define INT_DISABLED          0
#define INT_SRC_DI            1
#define INT_SRC_DI_WITH_GATE  2

#define TRIG_EDGE_RISING      0  // rising edge. note: this is the device specified value.
#define TRIG_EDGE_FALLING     1  // falling edge. note: this is the device specified value.

// USB HW Event type: 0 for SYS event, 1 for DI0, and 2 for DI8.
enum FW_EVENT_TYPE {
   FWEvtDIIntr16 = 0,
   FWEvtDIIntr40 = 1,
   FWEVT_TYPE_COUNT
};

//
// EEPROM Address definition
typedef enum _EE_ADDR {
   EEAddrDioGrp0Mode      = 0x4,    // Group 0 Mode (definition is same with 1751 Register)
   EEAddrDioGrp1Mode      = 0x5,    // Group 1 Mode (definition is same with 1751 Register)
   EEAddrDioGrp0PoSMode   = 0x6,    // Group 0 Power-On Mode (definition is same with 1751 Register)
   EEAddrDioGrp1PoSMode   = 0x7,    // Group 1 Power-On Mode (definition is same with 1751 Register)
   EEAddrDoPresetValStart = 0x8,    // Port  Power-On Value
   EEAddrDioPC0IntMode    = 0x22,   // Port0 Interrupt Mode(0:Disable, 1: PC00, 2: Pc00 with gate PC04)
   EEAddrDioPC1IntMode    = 0x23,   // Port1 Interrupt Mode(0:Disable,1PC10 2 Pc10 with gate PC14)
   EEAddrDioPC0TrigMode   = 0x24,   // Port0 Edge Mode( 0: Rising, 1:Falling )
   EEAddrDioPC1TrigMode   = 0x25    // Port1 Edge Mode(0:Rising 1:Falling)
} EE_ADDR;

typedef struct _EE_WRITE {
   __u16 Data;
   __u16 Addr;
} EE_WRITE;


typedef struct _EVENT_DATA {
   __u8 EventType;
   __u8 PortData[DIO_PORT_COUNT_MAX];
} EVENT_DATA;

#define MAX_EVT_NUM_IN_FIFO 9
typedef struct _FW_EVENT_FIFO {
   __u8       EventCount;
   EVENT_DATA EventData[MAX_EVT_NUM_IN_FIFO];
} FW_EVENT_FIFO;


#endif /* _KERNEL_MODULE_HW_H_ */
