/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x1809
#define DEVICE_ID  	 0x4751
#define DRIVER_NAME   "bio4751"

 #define DEVICE_NAME_FROM_PID(pid) \
   (pid == BD_USB4751 ? "USB-4751" : "USB-4751L")

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT_MAX     6
#define DIO_CHL_COUNT_MAX      (DIO_PORT_COUNT_MAX * 8)

#define DIO_PORT_COUNT(pid)    (pid == BD_USB4751 ? 6 : 3)
#define DIO_CHL_COUNT(pid)     (DIO_PORT_COUNT(pid) * 8)

#define DI_INT_SRC_COUNT_MAX    2  // CH#016 & CH#040
#define DI_INT_SRC_CTL_MASK     0x0303
#define DI_INT_SRC_COUNT(pid)   (pid == BD_USB4751 ? 2 : 1)

#define DI_SNAP_SRC_COUNT_MAX   DI_INT_SRC_COUNT_MAX
#define DI_SNAP_SRC_COUNT(pid)  DI_INT_SRC_COUNT(pid)

#define CNTR_CHL_COUNT           2
#define CNTR_RES_IN_BIT          24
#define CNTR_DATA_SIZE           sizeof(__u32)
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             ((0x1 << CNTR_RES_IN_BIT) - 1)
#define CNTR_IDLE                0

#define FREQHI                   0
#define FREQLO                   1

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan16  = KdxDiBegin,
   KdxDiintChan40,
   KdxDiEnd        = KdxDiintChan40,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   case EvtDiintChannel016: kdx = KdxDiintChan16; break;
   case EvtDiintChannel040: kdx = KdxDiintChan40; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        0

// DIO default values
#define DEF_DIO_PORT_DIR        Input
#define DEF_DO_STATE            0x0
#define DEF_DI_INT_TRIGEDGE     RisingEdge
#define DEF_DI_INT_GATECTRL     0

// -----------------------------------------------------
// macros the daqusb.h needed
// -----------------------------------------------------
#define  MAX_COUNTER_PARA        3

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG {
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE {
   __u8 State[DIO_PORT_COUNT_MAX];
} DI_SNAP_STATE;

typedef struct _CNTR_CONFIG {
   __u32 TmrDivisor[CNTR_CHL_COUNT];
   __u32 PoHiDivisor[CNTR_CHL_COUNT];
   __u32 PoLoDivisor[CNTR_CHL_COUNT];
} CNTR_CONFIG;

typedef struct _CNTR_STATE {
   __u32 Operation;
} CNTR_STATE;

typedef struct _DEVICE_SHARED {
   __u32          Size;           // Size of the structure
   __u32          ProductId;      // Device Type
   __u32          DeviceNumber;   // Zero-based device number

   // HW Information
   __u32          BoardId;        // Board dip switch number for the device
   __u32          InitOnLoad;

   // --------------------------------------------------------
   __u8           DioPortDir[DIO_PORT_COUNT_MAX];
   __u8           DiintTrigEdge[DI_INT_SRC_COUNT_MAX];
   __u8           DiintGateCtrl[DI_INT_SRC_COUNT_MAX];
   __u8           DoPortState[DIO_PORT_COUNT_MAX];

   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_COUNT_MAX];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_COUNT_MAX];

   // ---------------------------------------------------------
   __u32          CntrBaseClk;
   CNTR_CONFIG    CntrConfig;
   CNTR_STATE     CntrState[CNTR_CHL_COUNT];

   // ---------------------------------------------------------
   __u32          IntCsr;
   __u32          IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
