/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: rocky
 */
#include "kdriver.h"

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         memset(cntr, 0, sizeof(CNTR_STATE));
         cntr->Operation = InstantEventCount;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_event_count(daq_dev, start);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
         break;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   CNTR_STATE      *cntr;
   unsigned long   flags;
   int             ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         memset(cntr, 0, sizeof(CNTR_STATE));
         cntr->Operation = InstantFreqMeter;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_freq_measure(daq_dev, start);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
         break;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_timer_pulse( daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         cntr->Operation = TimerPulse;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_timer_pulse(daq_dev, start, shared->CntrConfig.TmrDivisor[start]);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
         break;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

static
int daq_cntr_start_pw_modulate(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_STATE    *cntr;
   unsigned long flags;
   int           ret = 0;

   while (count--) {
      cntr = &shared->CntrState[start];
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (cntr->Operation == CNTR_IDLE) {
         cntr->Operation = InstantPwmOut;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ret = daq_usb_cntr_start_pw_modulate(daq_dev, start,
            shared->CntrConfig.PoHiDivisor[start],
            shared->CntrConfig.PoLoDivisor[start]);
      if (ret < 0) {
         cntr->Operation = CNTR_IDLE;
      }

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return ret < 0 ? ret : 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   while (count--) {
      if (shared->CntrState[start].Operation != CNTR_IDLE) {
         shared->CntrState[start].Operation = CNTR_IDLE;
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_usb_cntr_reset(daq_dev, start);
         spin_lock_irqsave(&daq_dev->dev_lock, flags);
      }
      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_TmrFrequencyOfCounters:
      dataPtr = &shared->CntrConfig.TmrDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoHiPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoHiDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoLoPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoLoDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmOut:
      return daq_cntr_start_pw_modulate(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   struct timespec dummy;
   CNTR_READ       cntr;
   int             i, ret;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   if (cntr.Operation == InstantFreqMeter) {
      BioUsbFrequencyRead_RX rx[CNTR_CHL_COUNT];

      for (i = 0; i < cntr.Count; ++i) {
         ret = daq_usb_cntr_read_freq_measure(daq_dev, cntr.Start, &rx[i]);
         if (ret < 0){
            return ret;
         }
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }

      if (unlikely(copy_to_user(cntr.Value, rx, cntr.Count * sizeof(BioUsbFrequencyRead_RX)))){
         return -EFAULT;
      }
   } else {
      CNTR_VALUE  vals[CNTR_CHL_COUNT];

      for (i = 0; i < cntr.Count; ++i) {
         ret = daq_usb_cntr_read_event_count(daq_dev, cntr.Start, &vals[i].Value, &dummy);
         if (ret < 0){
            return ret;
         }
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }

      if (unlikely(copy_to_user(cntr.Value, vals, cntr.Count * sizeof(CNTR_VALUE)))){
         return -EFAULT;
      }
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
